from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd


# ---------------------------------------------------------------------------
# Paths and Figure Configuration
# ---------------------------------------------------------------------------

# Set the project and output paths.
PROJECT_ROOT = Path(__file__).resolve().parents[1]

SUMMARY_PATH = (
    PROJECT_ROOT
    / "data"
    / "reports"
    / "results_summary.csv"
)

FIGURE_DIRECTORY = (
    PROJECT_ROOT
    / "figures"
)

PNG_PATH = (
    FIGURE_DIRECTORY
    / "figure_5_1_model_comparison.png"
)

PDF_PATH = (
    FIGURE_DIRECTORY
    / "figure_5_1_model_comparison.pdf"
)

# Set the model display order.
MODEL_ORDER = [
    "Clinical Cox",
    "Extended Cox",
    "Clinical MTLR",
    "Extended MTLR",
    "Extended MTLR + X-CAL",
    "MTLR X-CAL Ensemble",
]


# ---------------------------------------------------------------------------
# Result Loading
# ---------------------------------------------------------------------------

# Load and validate the model comparison results.
def load_results() -> pd.DataFrame:
    if not SUMMARY_PATH.exists():
        raise FileNotFoundError(
            f"Results summary not found: {SUMMARY_PATH}"
        )

    results = pd.read_csv(
        SUMMARY_PATH
    )

    # Set the columns required for the comparison figure.
    required_columns = {
        "model",
        "validation_concordance_index",
        "difference_from_clinical_cox",
    }

    missing_columns = (
        required_columns
        - set(results.columns)
    )

    # Check that all required columns are available.
    if missing_columns:
        raise ValueError(
            "Results summary is missing columns: "
            f"{sorted(missing_columns)}"
        )

    # Order the results by model.
    results = (
        results.set_index("model")
        .reindex(MODEL_ORDER)
        .reset_index()
    )

    # Check that each model has a validation C-index.
    if results[
        "validation_concordance_index"
    ].isna().any():
        missing_models = results.loc[
            results[
                "validation_concordance_index"
            ].isna(),
            "model",
        ].tolist()

        raise ValueError(
            "Missing validation C-index for: "
            f"{missing_models}"
        )

    return results


# ---------------------------------------------------------------------------
# Figure Generation
# ---------------------------------------------------------------------------

# Create the model comparison figure.
def create_figure(
    results: pd.DataFrame,
) -> None:
    # Create the figure output directory.
    FIGURE_DIRECTORY.mkdir(
        parents=True,
        exist_ok=True,
    )

    figure, axis = plt.subplots(
        figsize=(10, 6.5)
    )

    # Set the bar colours for each model.
    BAR_COLOURS = [
        "#7F7F7F",  # Clinical Cox
        "#4C78A8",  # Extended Cox
        "#7F7F7F",  # Clinical MTLR
        "#4C78A8",  # Extended MTLR
        "#54A24B",  # X-CAL
        "#B279A2",  # Ensemble
    ]

    # Create the model comparison bars.
    bars = axis.barh(
        results["model"],
        results["validation_concordance_index"],
        color=BAR_COLOURS,
    )

    axis.invert_yaxis()

    # Set the figure labels.
    axis.set_title(
        "Comparison of validation discrimination across successive prognostic models",
        pad=14,
        fontweight="bold",
    )

    axis.set_xlabel(
        "Harrell's concordance index"
    )

    axis.set_ylabel("")

    axis.grid(
        axis="x",
        alpha=0.25,
    )

    axis.set_axisbelow(True)

    # Add the C-index and baseline difference labels.
    for bar, (_, row) in zip(
            bars,
            results.iterrows(),
    ):
        value = row["validation_concordance_index"]
        improvement = row["difference_from_clinical_cox"]

        if row["model"] == "Clinical Cox":
            label = (
                f"{value:.3f}\n(Baseline)"
            )
        elif improvement >= 0:
            label = (
                f"{value:.3f}\n(+{improvement:.3f})"
            )
        else:
            label = (
                f"{value:.3f}\n({improvement:.3f})"
            )

        axis.text(
            value + 0.0005,
            bar.get_y() + bar.get_height() / 2,
            label,
            va="center",
            fontsize=9,
        )

    figure.tight_layout()

    # Save the figure as PNG and PDF.
    figure.savefig(
        PNG_PATH,
        dpi=300,
        bbox_inches="tight",
    )

    figure.savefig(
        PDF_PATH,
        bbox_inches="tight",
    )

    plt.close(figure)


# ---------------------------------------------------------------------------
# Script Entry Point
# ---------------------------------------------------------------------------

# Generate the model comparison figure.
def main() -> None:
    results = load_results()

    create_figure(
        results
    )

    print("Figure 5.1 generated.")
    print(f"PNG saved to: {PNG_PATH}")
    print(f"PDF saved to: {PDF_PATH}")


if __name__ == "__main__":
    main()