from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd

from matplotlib.axes import Axes
from matplotlib.container import BarContainer


# ---------------------------------------------------------------------------
# Paths and Figure Configuration
# ---------------------------------------------------------------------------

# Set the project and output paths.
PROJECT_ROOT = Path(__file__).resolve().parents[1]

SUMMARY_PATH = (
    PROJECT_ROOT
    / "data"
    / "reports"
    / "results_summary.csv"
)

FIGURE_DIRECTORY = (
    PROJECT_ROOT
    / "figures"
)

PNG_PATH = (
    FIGURE_DIRECTORY
    / "figure_5_2_calibration_comparison.png"
)

PDF_PATH = (
    FIGURE_DIRECTORY
    / "figure_5_2_calibration_comparison.pdf"
)

# Set the model display order.
MODEL_ORDER = [
    "Extended MTLR",
    "Extended MTLR + X-CAL",
    "MTLR X-CAL Ensemble",
]

# Set the bar colours for each model.
BAR_COLOURS = [
    "#4C78A8",
    "#54A24B",
    "#B279A2",
]


# ---------------------------------------------------------------------------
# Result Loading
# ---------------------------------------------------------------------------

# Load and validate the model comparison results.
def load_results() -> pd.DataFrame:
    if not SUMMARY_PATH.exists():
        raise FileNotFoundError(
            f"Results summary not found: {SUMMARY_PATH}"
        )

    results = pd.read_csv(
        SUMMARY_PATH
    )

    # Set the columns required for the comparison figure.
    required_columns = {
        "model",
        "validation_concordance_index",
        "validation_integrated_brier_score",
        "adjusted_d_calibration_chi_square",
    }

    missing_columns = (
        required_columns
        - set(results.columns)
    )

    # Check that all required columns are available.
    if missing_columns:
        raise ValueError(
            "Results summary is missing columns: "
            f"{sorted(missing_columns)}"
        )

    # Order the results by model.
    results = (
        results.set_index("model")
        .reindex(MODEL_ORDER)
        .reset_index()
    )

    # Check that the comparison metrics are complete.
    if results[
        [
            "validation_concordance_index",
            "validation_integrated_brier_score",
            "adjusted_d_calibration_chi_square",
        ]
    ].isna().any().any():
        raise ValueError(
            "One or more calibration-comparison metrics are missing."
        )

    return results


# ---------------------------------------------------------------------------
# Figure Helpers
# ---------------------------------------------------------------------------

# Add metric values beside the horizontal bars.
def add_value_labels(
    axis: Axes,
    bars: BarContainer,
    values: pd.Series,
    decimal_places: int,
) -> None:
    for bar, value in zip(
        bars,
        values,
    ):
        axis.text(
            value,
            bar.get_y() + bar.get_height() / 2.0,
            f" {value:.{decimal_places}f}",
            va="center",
            fontsize=9,
        )


# ---------------------------------------------------------------------------
# Figure Generation
# ---------------------------------------------------------------------------

# Create and save the calibration comparison figure.
def create_figure(
    results: pd.DataFrame,
) -> None:
    # Create the figure output directory.
    FIGURE_DIRECTORY.mkdir(
        parents=True,
        exist_ok=True,
    )

    # Create the three metric panels.
    figure, axes = plt.subplots(
        nrows=1,
        ncols=3,
        figsize=(13.5, 5.2),
        sharey=True,
    )

    # Set the display configuration for each metric.
    metric_definitions = [
        (
            "validation_concordance_index",
            "Harrell's C-index",
            "Higher is better",
            3,
            (0.64, 0.68),
        ),
        (
            "validation_integrated_brier_score",
            "Integrated Brier Score",
            "Lower is better",
            4,
            (0.158, 0.166),
        ),
        (
            "adjusted_d_calibration_chi_square",
            "Adjusted D-calibration χ²",
            "Lower is better",
            3,
            (0.0, 13.5),
        ),
    ]

    # Create each metric panel.
    for axis, (
        column,
        title,
        direction,
        decimal_places,
        x_limits,
    ) in zip(
        axes,
        metric_definitions,
    ):
        bars = axis.barh(
            results["model"],
            results[column],
            color=BAR_COLOURS,
        )

        axis.invert_yaxis()

        axis.set_title(
            f"{title}\n{direction}",
            fontsize=11,
            fontweight="bold",
            pad=10,
        )

        axis.set_xlim(
            *x_limits
        )

        axis.grid(
            axis="x",
            alpha=0.25,
        )

        axis.set_axisbelow(True)
        axis.set_ylabel("")

        add_value_labels(
            axis=axis,
            bars=bars,
            values=results[column],
            decimal_places=decimal_places,
        )

    # Set the figure title and layout.
    figure.suptitle(
        "Impact of X-CAL on discrimination and calibration",
        fontsize=14,
        fontweight="bold",
        y=1.02,
    )

    figure.tight_layout()

    # Save the figure as PNG and PDF.
    figure.savefig(
        PNG_PATH,
        dpi=300,
        bbox_inches="tight",
    )

    figure.savefig(
        PDF_PATH,
        bbox_inches="tight",
    )

    plt.close(
        figure
    )


# ---------------------------------------------------------------------------
# Script Entry Point
# ---------------------------------------------------------------------------

# Generate the calibration comparison figure.
def main() -> None:
    results = load_results()

    create_figure(
        results
    )

    print("Figure 5.2 generated.")
    print(f"PNG saved to: {PNG_PATH}")
    print(f"PDF saved to: {PDF_PATH}")


if __name__ == "__main__":
    main()