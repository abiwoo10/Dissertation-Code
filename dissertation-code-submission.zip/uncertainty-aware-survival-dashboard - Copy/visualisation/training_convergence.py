from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np

from ml.mtlr_model import MTLRModel


# ---------------------------------------------------------------------------
# Paths and Figure Configuration
# ---------------------------------------------------------------------------

# Set the project and output paths.
PROJECT_ROOT = Path(__file__).resolve().parents[1]

MODEL_PATH = (
    PROJECT_ROOT
    / "models"
    / "trained"
    / "mtlr_extended_xcal.pkl"
)

FIGURE_DIRECTORY = (
    PROJECT_ROOT
    / "figures"
)

PNG_PATH = (
    FIGURE_DIRECTORY
    / "figure_5_5_training_convergence.png"
)

PDF_PATH = (
    FIGURE_DIRECTORY
    / "figure_5_5_training_convergence.pdf"
)

# Set the figure colours.
TRAINING_COLOUR = "#4C78A8"
VALIDATION_COLOUR = "#54A24B"
BEST_EPOCH_COLOUR = "#B279A2"


# ---------------------------------------------------------------------------
# Model Loading
# ---------------------------------------------------------------------------

# Load and validate the X-CAL MTLR model.
def load_model() -> MTLRModel:
    if not MODEL_PATH.exists():
        raise FileNotFoundError(
            f"X-CAL model not found: {MODEL_PATH}"
        )

    # Load the trained model.
    model = MTLRModel.load(
        MODEL_PATH
    )

    # Check that the training loss history is available.
    if not model.training_losses:
        raise ValueError(
            "The model does not contain training-loss history."
        )

    # Check that the validation loss history is available.
    if not model.validation_losses:
        raise ValueError(
            "The model does not contain validation-loss history."
        )

    # Check that the best epoch is available.
    if model.best_epoch is None:
        raise ValueError(
            "The model does not contain a best epoch."
        )

    return model


# ---------------------------------------------------------------------------
# Figure Generation
# ---------------------------------------------------------------------------

# Create the training convergence figure.
def create_figure(
    model: MTLRModel,
) -> None:
    # Create the figure output directory.
    FIGURE_DIRECTORY.mkdir(
        parents=True,
        exist_ok=True,
    )

    # Convert the training and validation losses to arrays.
    training_losses = np.asarray(
        model.training_losses,
        dtype=float,
    )

    validation_losses = np.asarray(
        model.validation_losses,
        dtype=float,
    )

    # Create the epoch numbers for each loss history.
    training_epochs = np.arange(
        1,
        len(training_losses) + 1,
    )

    validation_epochs = np.arange(
        1,
        len(validation_losses) + 1,
    )

    # Best epoch is stored using one-based epoch numbering.
    best_epoch_number = int(
        model.best_epoch
    )

    # Get the validation loss at the best epoch.
    best_validation_loss = float(
        validation_losses[
            model.best_epoch - 1
        ]
    )

    figure, axis = plt.subplots(
        figsize=(10.5, 6.2)
    )

    # Plot the training and validation objectives.
    axis.plot(
        training_epochs,
        training_losses,
        linewidth=2.0,
        color=TRAINING_COLOUR,
        label="Training objective",
    )

    axis.plot(
        validation_epochs,
        validation_losses,
        linewidth=2.0,
        color=VALIDATION_COLOUR,
        label="Validation objective",
    )

    # Mark the best validation epoch.
    axis.axvline(
        best_epoch_number,
        linestyle="--",
        linewidth=1.6,
        color=BEST_EPOCH_COLOUR,
        label=(
            f"Best validation epoch "
            f"({best_epoch_number})"
        ),
    )

    axis.scatter(
        best_epoch_number,
        best_validation_loss,
        s=65,
        color=BEST_EPOCH_COLOUR,
        zorder=4,
    )

    axis.annotate(
        (
            f"Best validation objective\n"
            f"{best_validation_loss:.4f}"
        ),
        xy=(
            best_epoch_number,
            best_validation_loss,
        ),
        xytext=(
            14,
            18,
        ),
        textcoords="offset points",
        fontsize=9,
        arrowprops={
            "arrowstyle": "->",
            "linewidth": 0.9,
            "color": BEST_EPOCH_COLOUR,
        },
        bbox={
            "boxstyle": "round,pad=0.35",
            "facecolor": "white",
            "edgecolor": "0.75",
            "alpha": 0.92,
        },
    )

    # Set the figure labels.
    axis.set_title(
        "Training convergence of the X-CAL-regularised extended MTLR",
        fontsize=14,
        fontweight="bold",
        pad=14,
    )

    axis.set_xlabel(
        "Training epoch"
    )

    axis.set_ylabel(
        "Combined optimisation objective"
    )

    axis.grid(
        alpha=0.22,
    )

    axis.set_axisbelow(True)

    axis.legend(
        loc="upper right",
        frameon=True,
    )

    # Create the training summary.
    summary_text = (
        f"Maximum epochs: {model.epochs}\n"
        f"Epochs completed: {len(training_losses)}\n"
        f"Stopped early: {model.stopped_early}\n"
        f"Patience: {model.patience}"
    )

    # Add the training summary to the figure.
    axis.text(
        0.98,
        0.60,
        summary_text,
        transform=axis.transAxes,
        ha="right",
        va="top",
        fontsize=9,
        bbox={
            "boxstyle": "round,pad=0.45",
            "facecolor": "white",
            "edgecolor": "0.75",
            "alpha": 0.92,
        },
    )

    figure.tight_layout()

    # Save the figure as PNG and PDF.
    figure.savefig(
        PNG_PATH,
        dpi=300,
        bbox_inches="tight",
    )

    figure.savefig(
        PDF_PATH,
        bbox_inches="tight",
    )

    plt.close(
        figure
    )


# ---------------------------------------------------------------------------
# Script Entry Point
# ---------------------------------------------------------------------------

# Generate the training convergence figure.
def main() -> None:
    model = load_model()

    create_figure(
        model
    )

    print("Figure 5.5 generated.")
    print(
        "Epochs completed: "
        f"{len(model.training_losses)}"
    )
    print(
        "Best epoch: "
        f"{int(model.best_epoch)}"
    )
    print(
        "Best validation objective: "
        f"{model.validation_losses[model.best_epoch - 1]:.4f}"
    )
    print(
        "Stopped early: "
        f"{model.stopped_early}"
    )
    print(f"PNG saved to: {PNG_PATH}")
    print(f"PDF saved to: {PDF_PATH}")


if __name__ == "__main__":
    main()