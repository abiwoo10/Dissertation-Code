from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from ml.ensemble_model import MTLREnsembleModel
from ml.preprocessing import prepare_model_dataset
from ml.prognosis import (
    calculate_uncertainty_thresholds,
    create_patient_prognosis,
)


# ---------------------------------------------------------------------------
# Paths and Figure Configuration
# ---------------------------------------------------------------------------

# Set the project and output paths.
PROJECT_ROOT = Path(__file__).resolve().parents[1]

ENSEMBLE_PATH = (
    PROJECT_ROOT
    / "models"
    / "trained"
    / "mtlr_xcal_ensemble.pkl"
)

FIGURE_DIRECTORY = (
    PROJECT_ROOT
    / "figures"
)

PNG_PATH = (
    FIGURE_DIRECTORY
    / "figure_5_4_example_patient_prognosis.png"
)

PDF_PATH = (
    FIGURE_DIRECTORY
    / "figure_5_4_example_patient_prognosis.pdf"
)

# Set the prediction times and prognosis horizons.
PREDICTION_TIMES = np.arange(
    6.0,
    241.0,
    6.0,
).tolist()

HORIZONS = [
    12.0,
    36.0,
    60.0,
]

# Set the figure colours.
ENSEMBLE_COLOUR = "#B279A2"
HORIZON_COLOUR = "#4C78A8"


# ---------------------------------------------------------------------------
# Patient Selection
# ---------------------------------------------------------------------------

# Select the patient closest to the median ensemble disagreement.
def select_representative_patient(
    uncertainty: pd.Series,
) -> object:
    if uncertainty.empty:
        raise ValueError(
            "Uncertainty series must not be empty."
        )

    # Calculate the median ensemble disagreement.
    median_uncertainty = float(
        uncertainty.median()
    )

    # Calculate each patient's distance from the median.
    distance_from_median = (
        uncertainty
        - median_uncertainty
    ).abs()

    return distance_from_median.idxmin()


# ---------------------------------------------------------------------------
# Figure Generation
# ---------------------------------------------------------------------------

# Create the example patient prognosis figure.
def create_figure() -> None:
    if not ENSEMBLE_PATH.exists():
        raise FileNotFoundError(
            f"Ensemble model not found: {ENSEMBLE_PATH}"
        )

    # Prepare the extended model dataset.
    dataset = prepare_model_dataset(
        model_type="extended",
        test_size=0.20,
        validation_size=0.20,
        random_state=42,
    )

    # Load the trained ensemble model.
    ensemble = MTLREnsembleModel.load(
        ENSEMBLE_PATH
    )

    # Generate predictions for the validation set.
    validation_prediction = ensemble.predict_survival(
        X=dataset.X_validation,
        time_points=PREDICTION_TIMES,
    )

    if validation_prediction.uncertainty is None:
        raise RuntimeError(
            "Ensemble prediction does not contain uncertainty."
        )

    # Calculate the validation uncertainty thresholds.
    thresholds = calculate_uncertainty_thresholds(
        validation_prediction
    )

    # Select the representative patient.
    patient_index = select_representative_patient(
        validation_prediction.uncertainty
    )

    patient_features = dataset.X_validation.loc[
        [patient_index]
    ]

    # Generate the selected patient's survival prediction.
    patient_prediction = ensemble.predict_survival(
        X=patient_features,
        time_points=PREDICTION_TIMES,
    )

    # Create the selected patient's prognosis.
    prognosis = create_patient_prognosis(
        prediction=patient_prediction,
        patient_index=patient_index,
        uncertainty_thresholds=thresholds,
    )

    if (
        patient_prediction.lower_confidence is None
        or patient_prediction.upper_confidence is None
    ):
        raise RuntimeError(
            "Ensemble prediction does not contain disagreement bounds."
        )

    # Extract the survival curve and disagreement bounds.
    times = np.asarray(
        prognosis.survival_curve.index,
        dtype=float,
    )

    mean_survival = prognosis.survival_curve.to_numpy(
        dtype=float
    )

    lower_survival = (
        patient_prediction.lower_confidence.loc[
            patient_index,
            times,
        ].to_numpy(dtype=float)
    )

    upper_survival = (
        patient_prediction.upper_confidence.loc[
            patient_index,
            times,
        ].to_numpy(dtype=float)
    )

    # Create the figure output directory.
    FIGURE_DIRECTORY.mkdir(
        parents=True,
        exist_ok=True,
    )

    figure, axis = plt.subplots(
        figsize=(10.5, 6.5)
    )

    # Plot the ensemble disagreement bounds.
    axis.fill_between(
        times,
        lower_survival,
        upper_survival,
        alpha=0.22,
        color=ENSEMBLE_COLOUR,
        label="Ensemble disagreement",
    )

    # Plot the predicted survival distribution.
    axis.plot(
        times,
        mean_survival,
        linewidth=2.5,
        color=ENSEMBLE_COLOUR,
        label="Predicted survival distribution",
    )

    # Set the survival probabilities for each prognosis horizon.
    horizon_values = {
        12.0: prognosis.one_year_survival,
        36.0: prognosis.three_year_survival,
        60.0: prognosis.five_year_survival,
    }

    # Add each prognosis horizon to the figure.
    for horizon in HORIZONS:
        probability = horizon_values[horizon]

        axis.scatter(
            horizon,
            probability,
            s=55,
            color=HORIZON_COLOUR,
            zorder=3,
        )

        axis.axvline(
            horizon,
            linestyle="--",
            linewidth=1.0,
            alpha=0.35,
            color=HORIZON_COLOUR,
        )

        axis.annotate(
            f"{horizon:.0f} months\n{probability * 100:.1f}%",
            xy=(
                horizon,
                probability,
            ),
            xytext=(
                9,
                -32,
            ),
            textcoords="offset points",
            fontsize=9,
            ha="left",
            arrowprops={
                "arrowstyle": "-",
                "linewidth": 0.8,
                "color": HORIZON_COLOUR,
            },
        )

    # Set the figure labels and display limits.
    axis.set_title(
        "Example patient-specific survival distribution and model disagreement",
        fontsize=14,
        fontweight="bold",
        pad=14,
    )

    axis.set_xlabel(
        "Time since diagnosis (months)"
    )

    axis.set_ylabel(
        "Predicted survival probability"
    )

    axis.set_xlim(
        0.0,
        max(times),
    )

    axis.set_ylim(
        0.0,
        1.02,
    )

    axis.grid(
        alpha=0.22,
    )

    axis.set_axisbelow(True)

    axis.legend(
        loc="lower left",
        frameon=True,
    )

    # Create the model disagreement summary.
    summary_text = (
        f"{prognosis.model_disagreement_label}\n"
        f"Overall disagreement: {prognosis.uncertainty:.4f}"
    )

    # Add the model disagreement summary to the figure.
    axis.text(
        0.98,
        0.97,
        summary_text,
        transform=axis.transAxes,
        ha="right",
        va="top",
        fontsize=9,
        bbox={
            "boxstyle": "round,pad=0.45",
            "facecolor": "white",
            "edgecolor": "0.75",
            "alpha": 0.92,
        },
    )

    figure.tight_layout()

    # Save the figure as PNG and PDF.
    figure.savefig(
        PNG_PATH,
        dpi=300,
        bbox_inches="tight",
    )

    figure.savefig(
        PDF_PATH,
        bbox_inches="tight",
    )

    plt.close(
        figure
    )

    print("Figure 5.4 generated.")
    print(f"Selected patient index: {patient_index}")
    print(
        "Disagreement label: "
        f"{prognosis.model_disagreement_label}"
    )
    print(
        "Overall disagreement: "
        f"{prognosis.uncertainty:.4f}"
    )
    print(
        "1-year survival: "
        f"{prognosis.one_year_survival:.3f}"
    )
    print(
        "3-year survival: "
        f"{prognosis.three_year_survival:.3f}"
    )
    print(
        "5-year survival: "
        f"{prognosis.five_year_survival:.3f}"
    )
    print(f"PNG saved to: {PNG_PATH}")
    print(f"PDF saved to: {PDF_PATH}")


# ---------------------------------------------------------------------------
# Script Entry Point
# ---------------------------------------------------------------------------

# Generate the example patient prognosis figure.
def main() -> None:
    create_figure()


if __name__ == "__main__":
    main()