from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt
from lifelines import KaplanMeierFitter


# Save the Kaplan-Meier overall survival figure.
def save_kaplan_meier_plot(
    estimator: KaplanMeierFitter,
    output_path: Path,
    *,
    show_censors: bool = False,
) -> None:
    # Create the output directory.
    output_path.parent.mkdir(parents=True, exist_ok=True)

    # Create the survival plot.
    figure, axis = plt.subplots(figsize=(9, 6))

    estimator.plot_survival_function(
        ax=axis,
        ci_show=True,
        show_censors=show_censors,
        censor_styles={"marker": "|"},
    )

    # Set the figure labels and display limits.
    axis.set_title("Overall Survival in the METABRIC Cohort")
    axis.set_xlabel("Time since diagnosis (months)")
    axis.set_ylabel("Estimated survival probability")
    axis.set_xlim(left=0.0)
    axis.set_ylim(0.0, 1.02)
    axis.grid(visible=True, alpha=0.25)

    figure.tight_layout()

    # Save the figure.
    figure.savefig(
        output_path,
        dpi=300,
        bbox_inches="tight",
    )

    plt.close(figure)