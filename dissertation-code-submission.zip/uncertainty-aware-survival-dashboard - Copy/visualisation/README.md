calibration_comparison.py/
Generates a three-panel figure comparing validation C-index, Integrated 
Brier Score, and adjusted D-calibration across the extended MTLR models.

example_patient_prognosis.py/
Generates an example patient-specific survival distribution figure 
showing predicted survival probabilities and ensemble disagreement.

generate_results_summary.py/
Combines model metadata and calibration results into a ranked validation 
results summary used by the visualisation scripts.

model_comparison.py/
Generates a figure comparing validation C-index across the Cox, MTLR, 
X-CAL, and ensemble models.

survival_plots.py/
Provides a plotting function for saving the Kaplan-Meier overall 
survival curve.

training_convergence.py/
Generates a figure showing the training and validation objective 
histories of the X-CAL-regularised extended MTLR model.

uncertainty_error_relationship.py/
Generates a three-panel figure examining the relationship between ensemble 
disagreement and absolute prediction error at the 1-, 3-, and 5-year 
prediction horizons.