from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.stats import spearmanr

from ml.ensemble_model import MTLREnsembleModel
from ml.preprocessing import prepare_model_dataset
from ml.prediction import SurvivalPrediction

from matplotlib.axes import Axes


# ---------------------------------------------------------------------------
# Paths and Figure Configuration
# ---------------------------------------------------------------------------

# Set the project and output paths.
PROJECT_ROOT = Path(__file__).resolve().parents[1]

ENSEMBLE_PATH = (
    PROJECT_ROOT
    / "models"
    / "trained"
    / "mtlr_xcal_ensemble.pkl"
)

FIGURE_DIRECTORY = (
    PROJECT_ROOT
    / "figures"
)

PNG_PATH = (
    FIGURE_DIRECTORY
    / "figure_5_3_uncertainty_error_relationship.png"
)

PDF_PATH = (
    FIGURE_DIRECTORY
    / "figure_5_3_uncertainty_error_relationship.pdf"
)

# Set the prediction horizons.
HORIZONS = [
    12.0,
    36.0,
    60.0,
]

# Set the figure colours.
POINT_COLOUR = "#4C78A8"
LINE_COLOUR = "#54A24B"


# ---------------------------------------------------------------------------
# Horizon Outcomes
# ---------------------------------------------------------------------------

# Create the known survival outcomes at a prediction horizon.
def observed_survival_at_horizon(
    duration: pd.Series,
    event: pd.Series,
    horizon: float,
) -> tuple[np.ndarray, np.ndarray]:
    duration_values = duration.to_numpy(
        dtype=float
    )

    event_values = event.to_numpy(
        dtype=bool
    )

    # Identify deaths on or before the prediction horizon.
    death_before_horizon = (
        event_values
        & (duration_values <= horizon)
    )

    # Identify patients observed beyond the prediction horizon.
    known_alive_at_horizon = (
        duration_values > horizon
    )

    # Identify patients with known outcomes at the prediction horizon.
    known_mask = (
        death_before_horizon
        | known_alive_at_horizon
    )

    # Set the binary survival outcomes.
    outcomes = np.where(
        death_before_horizon,
        0.0,
        1.0,
    )

    return outcomes, known_mask


# ---------------------------------------------------------------------------
# Horizon Calculations
# ---------------------------------------------------------------------------

# Calculate disagreement and absolute error at a prediction horizon.
def calculate_horizon_values(
    member_predictions: list[SurvivalPrediction],
    duration: pd.Series,
    event: pd.Series,
    horizon: float,
) -> tuple[
    np.ndarray,
    np.ndarray,
    float,
    float,
    int,
]:
    # Combine the ensemble member survival probabilities.
    member_probabilities = np.stack(
        [
            prediction.survival_curve[
                float(horizon)
            ].to_numpy(dtype=float)
            for prediction in member_predictions
        ],
        axis=0,
    )

    # Calculate the mean survival probability.
    mean_probability = member_probabilities.mean(
        axis=0
    )

    # Calculate the ensemble disagreement.
    disagreement = member_probabilities.std(
        axis=0,
        ddof=0,
    )

    # Get the observed survival outcomes.
    outcomes, known_mask = (
        observed_survival_at_horizon(
            duration=duration,
            event=event,
            horizon=horizon,
        )
    )

    # Select patients with known outcomes.
    known_probabilities = mean_probability[
        known_mask
    ]

    known_disagreement = disagreement[
        known_mask
    ]

    known_outcomes = outcomes[
        known_mask
    ]

    # Calculate the absolute prediction error.
    absolute_error = np.abs(
        known_probabilities
        - known_outcomes
    )

    # Calculate the Spearman correlation.
    correlation, p_value = spearmanr(
        known_disagreement,
        absolute_error,
    )

    return (
        known_disagreement,
        absolute_error,
        float(correlation),
        float(p_value),
        int(known_mask.sum()),
    )


# ---------------------------------------------------------------------------
# Figure Helpers
# ---------------------------------------------------------------------------

# Add the linear trend line.
def add_trend_line(
    axis: Axes,
    disagreement: np.ndarray,
    absolute_error: np.ndarray,
) -> None:
    if len(np.unique(disagreement)) < 2:
        return

    # Fit the linear trend line.
    coefficients = np.polyfit(
        disagreement,
        absolute_error,
        deg=1,
    )

    # Create the disagreement values for the trend line.
    x_values = np.linspace(
        disagreement.min(),
        disagreement.max(),
        100,
    )

    # Calculate the corresponding error values.
    y_values = np.polyval(
        coefficients,
        x_values,
    )

    axis.plot(
        x_values,
        y_values,
        color=LINE_COLOUR,
        linewidth=2.0,
        label="Linear trend",
    )


# Format the p-value for the figure.
def format_p_value(
    p_value: float,
) -> str:
    if p_value < 0.001:
        return "p < 0.001"

    return f"p = {p_value:.3f}"


# ---------------------------------------------------------------------------
# Figure Generation
# ---------------------------------------------------------------------------

# Create the uncertainty-error relationship figure.
def create_figure() -> None:
    if not ENSEMBLE_PATH.exists():
        raise FileNotFoundError(
            f"Ensemble model not found: {ENSEMBLE_PATH}"
        )

    # Prepare the extended model dataset.
    dataset = prepare_model_dataset(
        model_type="extended",
        test_size=0.20,
        validation_size=0.20,
        random_state=42,
    )

    # Load the trained ensemble model.
    ensemble = MTLREnsembleModel.load(
        ENSEMBLE_PATH
    )

    # Generate predictions from each ensemble member.
    member_predictions = [
        member.predict_survival(
            X=dataset.X_validation,
            time_points=HORIZONS,
        )
        for member in ensemble.members
    ]

    # Create the figure output directory.
    FIGURE_DIRECTORY.mkdir(
        parents=True,
        exist_ok=True,
    )

    # Create the three prediction horizon panels.
    figure, axes = plt.subplots(
        nrows=1,
        ncols=3,
        figsize=(14.5, 5.0),
        sharey=True,
    )

    # Create the uncertainty-error plot for each horizon.
    for axis, horizon in zip(
        axes,
        HORIZONS,
    ):
        (
            disagreement,
            absolute_error,
            correlation,
            p_value,
            patient_count,
        ) = calculate_horizon_values(
            member_predictions=member_predictions,
            duration=dataset.duration_validation,
            event=dataset.event_validation,
            horizon=horizon,
        )

        # Plot disagreement against absolute error.
        axis.scatter(
            disagreement,
            absolute_error,
            alpha=0.55,
            s=24,
            color=POINT_COLOUR,
            edgecolors="none",
        )

        add_trend_line(
            axis=axis,
            disagreement=disagreement,
            absolute_error=absolute_error,
        )

        axis.set_title(
            f"{horizon:.0f}-month horizon",
            fontsize=12,
            fontweight="bold",
            pad=10,
        )

        axis.set_xlabel(
            "Mean ensemble disagreement"
        )

        axis.grid(
            alpha=0.22,
        )

        axis.set_axisbelow(True)

        # Create the horizon results annotation.
        annotation = (
            f"Spearman ρ = {correlation:.3f}\n"
            f"{format_p_value(p_value)}\n"
            f"n = {patient_count}"
        )

        # Add the horizon results to the figure.
        axis.text(
            0.04,
            0.96,
            annotation,
            transform=axis.transAxes,
            va="top",
            ha="left",
            fontsize=9,
            bbox={
                "boxstyle": "round,pad=0.35",
                "facecolor": "white",
                "edgecolor": "0.75",
                "alpha": 0.9,
            },
        )

    # Set the figure labels.
    axes[0].set_ylabel(
        "Absolute survival probability error"
    )

    figure.suptitle(
        "Relationship between ensemble disagreement and prediction error",
        fontsize=14,
        fontweight="bold",
        y=1.02,
    )

    figure.tight_layout()

    # Save the figure as PNG and PDF.
    figure.savefig(
        PNG_PATH,
        dpi=300,
        bbox_inches="tight",
    )

    figure.savefig(
        PDF_PATH,
        bbox_inches="tight",
    )

    plt.close(
        figure
    )


# ---------------------------------------------------------------------------
# Script Entry Point
# ---------------------------------------------------------------------------

# Generate the uncertainty-error relationship figure.
def main() -> None:
    create_figure()

    print("Figure 5.3 generated.")
    print(f"PNG saved to: {PNG_PATH}")
    print(f"PDF saved to: {PDF_PATH}")


if __name__ == "__main__":
    main()