from __future__ import annotations

import json
from pathlib import Path

import pandas as pd


# ---------------------------------------------------------------------------
# Paths and Model Configuration
# ---------------------------------------------------------------------------

# Set the project and results paths.
PROJECT_ROOT = Path(__file__).resolve().parents[1]

METADATA_DIRECTORY = (
    PROJECT_ROOT
    / "models"
    / "metadata"
)

CALIBRATION_REPORT_PATH = (
    PROJECT_ROOT
    / "data"
    / "reports"
    / "mtlr_calibration_comparison.json"
)

OUTPUT_PATH = (
    PROJECT_ROOT
    / "data"
    / "reports"
    / "results_summary.csv"
)

# Set the model configurations included in the results summary.
MODEL_CONFIGURATIONS = [
    {
        "model_key": "clinical_cox",
        "model": "Clinical Cox",
        "model_family": "Cox proportional hazards",
        "feature_set": "Clinical",
        "metadata_file": "cox_clinical.json",
    },
    {
        "model_key": "extended_cox",
        "model": "Extended Cox",
        "model_family": "Cox proportional hazards",
        "feature_set": "Extended",
        "metadata_file": "cox_extended.json",
    },
    {
        "model_key": "clinical_mtlr",
        "model": "Clinical MTLR",
        "model_family": "MTLR",
        "feature_set": "Clinical",
        "metadata_file": "mtlr_clinical.json",
    },
    {
        "model_key": "extended_mtlr",
        "model": "Extended MTLR",
        "model_family": "MTLR",
        "feature_set": "Extended",
        "metadata_file": "mtlr_extended.json",
    },
    {
        "model_key": "extended_mtlr_xcal",
        "model": "Extended MTLR + X-CAL",
        "model_family": "MTLR + X-CAL",
        "feature_set": "Extended",
        "metadata_file": "mtlr_extended_xcal.json",
    },
    {
        "model_key": "mtlr_xcal_ensemble",
        "model": "MTLR X-CAL Ensemble",
        "model_family": "Deep ensemble",
        "feature_set": "Extended",
        "metadata_file": "mtlr_xcal_ensemble.json",
    },
]


# ---------------------------------------------------------------------------
# Result Loading
# ---------------------------------------------------------------------------

# Load a JSON results file.
def load_json(path: Path) -> dict[str, object]:
    if not path.exists():
        raise FileNotFoundError(
            f"Required results file not found: {path}"
        )

    with path.open(
        "r",
        encoding="utf-8",
    ) as input_file:
        return json.load(input_file)


# Load the optional calibration metrics.
def optional_calibration_metrics(
) -> dict[str, dict[str, float | None]]:
    if not CALIBRATION_REPORT_PATH.exists():
        return {}

    report = load_json(
        CALIBRATION_REPORT_PATH
    )

    models = report.get("models")

    if not isinstance(models, dict):
        return {}

    output: dict[str, dict[str, float]] = {}

    # Map the calibration report entries to the model keys.
    mapping = {
        "uncalibrated": "extended_mtlr",
        "xcal": "extended_mtlr_xcal",
    }

    # Extract the available calibration metrics for each model.
    for report_key, model_key in mapping.items():
        model_result = models.get(report_key)

        if not isinstance(model_result, dict):
            continue

        adjusted = model_result.get(
            "adjusted_d_calibration"
        )

        output[model_key] = {
            "validation_integrated_brier_score": (
                model_result.get(
                    "validation_integrated_brier_score"
                )
            ),
            "adjusted_d_calibration_chi_square": (
                adjusted.get("chi_square_statistic")
                if isinstance(adjusted, dict)
                else None
            ),
            "adjusted_d_calibration_p_value": (
                adjusted.get("p_value")
                if isinstance(adjusted, dict)
                else None
            ),
        }

    return output


# ---------------------------------------------------------------------------
# Results Summary
# ---------------------------------------------------------------------------

# Build the validation results summary.
def build_results_summary() -> pd.DataFrame:
    calibration_metrics = (
        optional_calibration_metrics()
    )

    rows: list[dict[str, object]] = []

    # Load the results for each model configuration.
    for configuration in MODEL_CONFIGURATIONS:
        metadata_path = (
            METADATA_DIRECTORY
            / configuration["metadata_file"]
        )

        metadata = load_json(
            metadata_path
        )

        model_key = str(
            configuration["model_key"]
        )

        extra_metrics = calibration_metrics.get(
            model_key,
            {},
        )

        adjusted_calibration = metadata.get(
            "adjusted_d_calibration"
        )

        # Add the model results to the summary rows.
        rows.append(
            {
                "model_key": model_key,
                "model": configuration["model"],
                "model_family": (
                    configuration["model_family"]
                ),
                "feature_set": configuration["feature_set"],
                "transformed_feature_count": metadata.get(
                    "transformed_feature_count"
                ),
                "validation_concordance_index": metadata.get(
                    "validation_concordance_index"
                ),
                "validation_integrated_brier_score": (
                    extra_metrics.get(
                        "validation_integrated_brier_score",
                        metadata.get(
                            "validation_integrated_brier_score"
                        ),
                    )
                ),
                "adjusted_d_calibration_chi_square": (
                    extra_metrics.get(
                        "adjusted_d_calibration_chi_square",
                        (
                            adjusted_calibration.get(
                                "chi_square_statistic"
                            )
                            if isinstance(
                                adjusted_calibration,
                                dict,
                            )
                            else None
                        ),
                    )
                ),
                "adjusted_d_calibration_p_value": (
                    extra_metrics.get(
                        "adjusted_d_calibration_p_value",
                        (
                            adjusted_calibration.get(
                                "p_value"
                            )
                            if isinstance(
                                adjusted_calibration,
                                dict,
                            )
                            else None
                        ),
                    )
                ),
                "training_rows": metadata.get(
                    "training_rows"
                ),
                "validation_rows": metadata.get(
                    "validation_rows"
                ),
                "test_rows": metadata.get(
                    "test_rows"
                ),
            }
        )

    # Create the results summary dataframe.
    summary = pd.DataFrame(
        rows
    )

    # Check that each model has a validation C-index.
    if summary[
        "validation_concordance_index"
    ].isna().any():
        missing_models = summary.loc[
            summary[
                "validation_concordance_index"
            ].isna(),
            "model",
        ].tolist()

        raise ValueError(
            "Missing validation C-index for: "
            f"{missing_models}"
        )

    # Get the Clinical Cox validation C-index.
    clinical_cox_c_index = float(
        summary.loc[
            summary["model_key"] == "clinical_cox",
            "validation_concordance_index",
        ].iloc[0]
    )

    # Calculate the difference from the Clinical Cox model.
    summary[
        "difference_from_clinical_cox"
    ] = (
        summary[
            "validation_concordance_index"
        ].astype(float)
        - clinical_cox_c_index
    )

    # Rank the models by validation C-index.
    summary = summary.sort_values(
        "validation_concordance_index",
        ascending=False,
    ).reset_index(drop=True)

    summary.insert(
        0,
        "rank",
        range(
            1,
            len(summary) + 1,
        ),
    )

    return summary


# ---------------------------------------------------------------------------
# Script Entry Point
# ---------------------------------------------------------------------------

# Generate and save the validation results summary.
def main() -> None:
    summary = build_results_summary()

    # Create the output directory.
    OUTPUT_PATH.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    # Save the results summary.
    summary.to_csv(
        OUTPUT_PATH,
        index=False,
    )

    # Set the columns displayed in the console.
    display_columns = [
        "rank",
        "model",
        "model_family",
        "feature_set",
        "validation_concordance_index",
        "difference_from_clinical_cox",
        "validation_integrated_brier_score",
        "adjusted_d_calibration_chi_square",
    ]

    print("Master validation results summary")
    print("-" * 110)

    print(
        summary[
            display_columns
        ].to_string(
            index=False,
            na_rep="—",
            formatters={
                "validation_concordance_index": (
                    lambda value: f"{value:.3f}"
                ),
                "difference_from_clinical_cox": (
                    lambda value: f"{value:+.3f}"
                ),
                "validation_integrated_brier_score": (
                    lambda value: f"{value:.4f}"
                ),
                "adjusted_d_calibration_chi_square": (
                    lambda value: f"{value:.3f}"
                ),
            },
        )
    )

    print(
        f"\nSummary saved to: {OUTPUT_PATH}"
    )


if __name__ == "__main__":
    main()