import io
import tarfile
from pathlib import Path

import numpy as np
import pandas as pd
import pytest
from sklearn.compose import ColumnTransformer

from ml.data_loading import (
    prepare_raw_model_data,
)
from ml.feature_config import (
    CLINICAL_FEATURES,
)
from ml.preprocessing import (
    DatasetSplit,
    TransformedDatasetSplit,
    build_feature_transformer,
    load_feature_transformer,
    prepare_model_dataset,
    save_feature_transformer,
    split_model_data,
    transform_dataset_split,
    transform_raw_features,
)


# ---------------------------------------------------------------------------
# Test Archive Helper
# ---------------------------------------------------------------------------

# Add a text file to the test archive.
def add_text_file(
    archive: tarfile.TarFile,
    filename: str,
    content: str,
) -> None:
    encoded = content.encode("utf-8")
    info = tarfile.TarInfo(name=filename)
    info.size = len(encoded)

    archive.addfile(info, io.BytesIO(encoded))


# ---------------------------------------------------------------------------
# Dataset Split Tests
# ---------------------------------------------------------------------------

# Check the training, validation, and test dataset split.
def test_split_model_data() -> None:
    row_count = 100

    X = pd.DataFrame(
        {
            "AGE_AT_DIAGNOSIS": range(row_count),
        }
    )

    duration = pd.Series(
        [float(value + 1) for value in range(row_count)]
    )

    event = pd.Series(
        [0, 1] * 50
    )

    result = split_model_data(
        X,
        duration,
        event,
        test_size=0.20,
        validation_size=0.20,
        random_state=42,
    )

    assert isinstance(result, DatasetSplit)

    assert len(result.X_train) == 60
    assert len(result.X_validation) == 20
    assert len(result.X_test) == 20

    assert len(result.duration_train) == 60
    assert len(result.event_train) == 60

    assert result.event_train.mean() == pytest.approx(0.5)
    assert result.event_validation.mean() == pytest.approx(0.5)
    assert result.event_test.mean() == pytest.approx(0.5)


# Check that the dataset split is reproducible.
def test_split_model_data_is_reproducible() -> None:
    X = pd.DataFrame(
        {
            "AGE_AT_DIAGNOSIS": range(40),
        }
    )

    duration = pd.Series(range(1, 41))
    event = pd.Series([0, 1] * 20)

    first = split_model_data(
        X,
        duration,
        event,
        random_state=42,
    )

    second = split_model_data(
        X,
        duration,
        event,
        random_state=42,
    )

    pd.testing.assert_frame_equal(
        first.X_train,
        second.X_train,
    )

    pd.testing.assert_series_equal(
        first.event_test,
        second.event_test,
    )


# Check that dataset splitting rejects inputs with different lengths.
def test_split_model_data_rejects_inconsistent_lengths() -> None:
    X = pd.DataFrame(
        {
            "AGE_AT_DIAGNOSIS": [50, 60],
        }
    )

    duration = pd.Series([12.0])
    event = pd.Series([0, 1])

    with pytest.raises(
        ValueError,
        match="same number of rows",
    ):
        split_model_data(X, duration, event)


# Check that invalid dataset split sizes are rejected.
def test_split_model_data_rejects_invalid_sizes() -> None:
    X = pd.DataFrame(
        {
            "AGE_AT_DIAGNOSIS": range(20),
        }
    )

    duration = pd.Series(range(1, 21))
    event = pd.Series([0, 1] * 10)

    with pytest.raises(
        ValueError,
        match="sum to less than 1",
    ):
        split_model_data(
            X,
            duration,
            event,
            test_size=0.60,
            validation_size=0.40,
        )


# ---------------------------------------------------------------------------
# Test Raw Dataset Split
# ---------------------------------------------------------------------------

# Create the raw dataset split used by the transformation tests.
def make_raw_dataset_split() -> DatasetSplit:
    X_train = pd.DataFrame(
        {
            "AGE_AT_DIAGNOSIS": [40.0, 50.0, None, 70.0],
            "CELLULARITY": ["High", "Moderate", "High", None],
            "LYMPH_NODES_EXAMINED_POSITIVE": [0.0, 1.0, 2.0, None],
            "ER_STATUS": ["Positive", "Negative", "Positive", "Positive"],
            "HER2_STATUS": ["Negative", "Negative", "Positive", "Negative"],
            "PR_STATUS": ["Positive", "Negative", "Positive", None],
            "GRADE": [1.0, 2.0, 3.0, 2.0],
            "TUMOR_SIZE": [10.0, 20.0, 30.0, None],
            "TUMOR_STAGE": [1.0, 2.0, 3.0, 2.0],
            "INFERRED_MENOPAUSAL_STATE": [
                "Pre",
                "Post",
                "Post",
                "Post",
            ],
            "HISTOLOGICAL_SUBTYPE": [
                "Ductal/NST",
                "Lobular",
                "Ductal/NST",
                "Lobular",
            ],
        }
    )

    X_validation = X_train.iloc[[0, 1]].copy()
    X_validation.loc[0, "CELLULARITY"] = "Unknown category"

    X_test = X_train.iloc[[2, 3]].copy()

    return DatasetSplit(
        X_train=X_train,
        X_validation=X_validation,
        X_test=X_test,
        duration_train=pd.Series([12.0, 24.0, 36.0, 48.0]),
        duration_validation=pd.Series([15.0, 30.0]),
        duration_test=pd.Series([20.0, 40.0]),
        event_train=pd.Series([0, 1, 0, 1]),
        event_validation=pd.Series([0, 1]),
        event_test=pd.Series([1, 0]),
    )


# ---------------------------------------------------------------------------
# Feature Transformation Tests
# ---------------------------------------------------------------------------

# Check that the feature transformer is created.
def test_build_feature_transformer() -> None:
    transformer = build_feature_transformer("clinical")

    assert isinstance(transformer, ColumnTransformer)


# Check the transformed training, validation, and test datasets.
def test_transform_dataset_split() -> None:
    raw_split = make_raw_dataset_split()

    result = transform_dataset_split(
        raw_split,
        model_type="clinical",
    )

    assert isinstance(result, TransformedDatasetSplit)

    assert len(result.X_train) == 4
    assert len(result.X_validation) == 2
    assert len(result.X_test) == 2

    assert result.X_train.columns.tolist() == (
        result.X_validation.columns.tolist()
    )

    assert result.X_train.columns.tolist() == (
        result.X_test.columns.tolist()
    )

    assert not result.X_train.isna().any().any()
    assert not result.X_validation.isna().any().any()
    assert not result.X_test.isna().any().any()


# Check that dataset transformation preserves the survival targets.
def test_transform_dataset_split_preserves_targets() -> None:
    raw_split = make_raw_dataset_split()

    result = transform_dataset_split(raw_split)

    pd.testing.assert_series_equal(
        result.duration_train,
        raw_split.duration_train,
    )

    pd.testing.assert_series_equal(
        result.event_test,
        raw_split.event_test,
    )


# Check that an unknown model type is rejected.
def test_build_feature_transformer_rejects_unknown_model() -> None:
    with pytest.raises(
        ValueError,
        match="model_type must be",
    ):
        build_feature_transformer("unknown")


# ---------------------------------------------------------------------------
# Model Dataset Preparation Tests
# ---------------------------------------------------------------------------

# Check model dataset preparation from a synthetic METABRIC archive.
def test_prepare_model_dataset_end_to_end(
    tmp_path: Path,
) -> None:
    archive_path = tmp_path / "synthetic_metabric.tar.gz"

    patient_rows = [
        ["P1", 12, "0:LIVING"],
        ["P2", 24, "1:DECEASED"],
        ["P3", 36, "0:LIVING"],
        ["P4", 48, "1:DECEASED"],
        ["P5", 60, "0:LIVING"],
        ["P6", 72, "1:DECEASED"],
        ["P7", 84, "0:LIVING"],
        ["P8", 96, "1:DECEASED"],
        ["P9", 108, "0:LIVING"],
        ["P10", 120, "1:DECEASED"],
        ["P11", 132, "0:LIVING"],
        ["P12", 144, "1:DECEASED"],
        ["P13", 156, "0:LIVING"],
        ["P14", 168, "1:DECEASED"],
        ["P15", 180, "0:LIVING"],
        ["P16", 192, "1:DECEASED"],
        ["P17", 204, "0:LIVING"],
        ["P18", 216, "1:DECEASED"],
        ["P19", 228, "0:LIVING"],
        ["P20", 240, "1:DECEASED"],
    ]

    patient_content = (
        "# synthetic patient table\n"
        "PATIENT_ID\tOS_MONTHS\tOS_STATUS\n"
        + "\n".join(
            "\t".join(map(str, row))
            for row in patient_rows
        )
        + "\n"
    )

    sample_columns = [
        "PATIENT_ID",
        "SAMPLE_ID",
        *CLINICAL_FEATURES,
        "INTCLUST",
        "TMB_NONSYNONYMOUS",
    ]

    sample_rows = []

    # Create the synthetic sample rows.
    for index in range(1, 21):
        sample_rows.append(
            [
                f"P{index}",
                f"S{index}",
                40 + index,
                "High" if index % 2 == 0 else "Moderate",
                index % 4,
                "Positive" if index % 2 == 0 else "Negative",
                "Negative",
                "Positive" if index % 3 == 0 else "Negative",
                (index % 3) + 1,
                10 + index,
                (index % 3) + 1,
                "Post" if index > 10 else "Pre",
                "Ductal/NST" if index % 2 == 0 else "Lobular",
                "4ER+" if index % 2 == 0 else "3",
                float(index) / 2,
            ]
        )

    sample_content = (
        "# synthetic sample table\n"
        + "\t".join(sample_columns)
        + "\n"
        + "\n".join(
            "\t".join(map(str, row))
            for row in sample_rows
        )
        + "\n"
    )

    # Create the synthetic METABRIC archive.
    with tarfile.open(archive_path, mode="w:gz") as archive:
        add_text_file(
            archive,
            "study/data_clinical_patient.txt",
            patient_content,
        )

        add_text_file(
            archive,
            "study/data_clinical_sample.txt",
            sample_content,
        )

    # Prepare the extended model dataset.
    result = prepare_model_dataset(
        archive_path=archive_path,
        model_type="extended",
        test_size=0.20,
        validation_size=0.20,
        random_state=42,
    )

    # Check the prepared dataset.
    assert isinstance(result, TransformedDatasetSplit)

    assert len(result.X_train) == 12
    assert len(result.X_validation) == 4
    assert len(result.X_test) == 4

    assert not result.X_train.isna().any().any()
    assert not result.X_validation.isna().any().any()
    assert not result.X_test.isna().any().any()

    assert result.X_train.columns.tolist() == (
        result.X_validation.columns.tolist()
    )

    assert result.X_train.columns.tolist() == (
        result.X_test.columns.tolist()
    )

    assert len(result.duration_train) == 12
    assert len(result.event_test) == 4


# ---------------------------------------------------------------------------
# Feature Transformer Persistence Tests
# ---------------------------------------------------------------------------

# Check that a saved feature transformer can be loaded with matching output.
def test_save_and_load_feature_transformer(
    tmp_path: Path,
) -> None:
    dataset = prepare_model_dataset(
        model_type="extended",
        test_size=0.20,
        validation_size=0.20,
        random_state=42,
    )

    path = (
        tmp_path
        / "extended_preprocessor.joblib"
    )

    save_feature_transformer(
        transformer=dataset.transformer,
        path=path,
    )

    loaded = load_feature_transformer(
        path
    )

    original = transform_raw_features(
        X=prepare_raw_model_data(
            model_type="extended"
        )[0].iloc[[0]],
        transformer=dataset.transformer,
    )

    restored = transform_raw_features(
        X=prepare_raw_model_data(
            model_type="extended"
        )[0].iloc[[0]],
        transformer=loaded,
    )

    assert (
        original.columns.tolist()
        == restored.columns.tolist()
    )

    np.testing.assert_allclose(
        original.to_numpy(),
        restored.to_numpy(),
    )


# Check that an unfitted feature transformer cannot be saved.
def test_save_rejects_unfitted_transformer(
    tmp_path: Path,
) -> None:
    transformer = build_feature_transformer(
        model_type="extended"
    )

    with pytest.raises(
        ValueError,
        match="unfitted",
    ):
        save_feature_transformer(
            transformer,
            tmp_path / "unfitted.joblib",
        )


# Check that loading a missing feature transformer is rejected.
def test_load_rejects_missing_transformer(
    tmp_path: Path,
) -> None:
    with pytest.raises(
        FileNotFoundError,
        match="Feature transformer not found",
    ):
        load_feature_transformer(
            tmp_path / "missing.joblib"
        )