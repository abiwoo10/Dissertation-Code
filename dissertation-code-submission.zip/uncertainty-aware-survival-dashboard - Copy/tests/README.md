test_api.py/
Tests the FastAPI application configuration and basic API behaviour.

test_api_endpoints.py/
Tests the API endpoints and their responses for valid, invalid, and 
unavailable prediction requests.

test_audit_metabric.py/
Tests the METABRIC dataset auditing functions and their validation 
behaviour.

test_cox_model.py/
Tests Cox model training, survival prediction, validation, and model 
persistence.

test_data_loading.py/
Tests loading and validating the METABRIC dataset and survival outcome data.

test_ensemble_model.py/
Tests MTLR ensemble prediction, model disagreement calculations, and 
model persistence.

test_evaluation.py/
Tests the survival model evaluation functions and calculated performance 
metrics.

test_generate_metabric_dictionary.py/
Tests the generation and structure of the METABRIC data dictionary.

test_kaplan_meier.py/
Tests Kaplan-Meier fitting and the resulting survival estimates.

test_mtlr_model.py/
Tests MTLR model training, survival prediction, validation, and model 
persistence.

test_prediction_service.py/
Tests the prediction service, including patient feature conversion, 
uncertainty thresholds, and prognosis response generation.

test_preprocessing.py/
Tests dataset preparation, feature preprocessing, transformations, and 
preprocessing pipeline behaviour.

test_prognosis.py/
Tests patient-level prognosis generation, median survival estimation, 
and model disagreement outputs.

test_xcal.py/
Tests the X-CAL loss and its supporting soft-membership calculations, 
including censoring and gradient support.