import io
import tarfile
from pathlib import Path

import pandas as pd
import pytest

from ml.data_loading import (
    create_survival_target,
    load_metabric_clinical_tables,
    merge_clinical_tables,
    prepare_raw_model_data,
    select_model_data,
)
from ml.feature_config import (
    CLINICAL_FEATURES,
    EXTENDED_FEATURES,
)


# ---------------------------------------------------------------------------
# Test Archive Helpers
# ---------------------------------------------------------------------------

# Add a text file to the test archive.
def add_text_file(
    archive: tarfile.TarFile,
    filename: str,
    content: str,
) -> None:
    encoded = content.encode("utf-8")
    info = tarfile.TarInfo(name=filename)
    info.size = len(encoded)

    archive.addfile(info, io.BytesIO(encoded))


# ---------------------------------------------------------------------------
# Clinical Table Loading Tests
# ---------------------------------------------------------------------------

# Check that the patient and sample clinical tables are loaded.
def test_load_metabric_clinical_tables(tmp_path: Path) -> None:
    archive_path = tmp_path / "synthetic_metabric.tar.gz"

    patient_content = """# synthetic patient table
PATIENT_ID\tOS_MONTHS\tOS_STATUS
P1\t12\t0:LIVING
P2\t24\t1:DECEASED
"""

    sample_content = """# synthetic sample table
PATIENT_ID\tSAMPLE_ID\tER_STATUS
P1\tS1\tPositive
P2\tS2\tNegative
"""

    # Create the synthetic METABRIC archive.
    with tarfile.open(archive_path, mode="w:gz") as archive:
        add_text_file(
            archive,
            "study/data_clinical_patient.txt",
            patient_content,
        )

        add_text_file(
            archive,
            "study/data_clinical_sample.txt",
            sample_content,
        )

    # Load the clinical tables from the archive.
    patient_df, sample_df = load_metabric_clinical_tables(
        archive_path
    )

    # Check the loaded clinical tables.
    assert len(patient_df) == 2
    assert len(sample_df) == 2
    assert "PATIENT_ID" in patient_df.columns
    assert "SAMPLE_ID" in sample_df.columns
    assert "ER_STATUS" in sample_df.columns


# ---------------------------------------------------------------------------
# Clinical Table Merge Tests
# ---------------------------------------------------------------------------

# Check that the patient and sample clinical tables are merged.
def test_merge_clinical_tables() -> None:
    patient_df = pd.DataFrame(
        {
            "PATIENT_ID": ["P1", "P2"],
            "OS_MONTHS": [12.0, 24.0],
            "OS_STATUS": ["0:LIVING", "1:DECEASED"],
        }
    )

    sample_df = pd.DataFrame(
        {
            "PATIENT_ID": ["P1", "P2"],
            "SAMPLE_ID": ["S1", "S2"],
            "ER_STATUS": ["Positive", "Negative"],
        }
    )

    # Merge the patient and sample tables.
    merged_df = merge_clinical_tables(patient_df, sample_df)

    # Check the merged clinical table.
    assert len(merged_df) == 2
    assert merged_df["PATIENT_ID"].tolist() == ["P1", "P2"]
    assert "OS_MONTHS" in merged_df.columns
    assert "SAMPLE_ID" in merged_df.columns
    assert "ER_STATUS" in merged_df.columns


# Check that duplicate patient IDs are rejected.
def test_merge_clinical_tables_rejects_duplicate_patient_ids() -> None:
    patient_df = pd.DataFrame(
        {
            "PATIENT_ID": ["P1", "P1"],
            "OS_MONTHS": [12.0, 24.0],
        }
    )

    sample_df = pd.DataFrame(
        {
            "PATIENT_ID": ["P1"],
            "SAMPLE_ID": ["S1"],
        }
    )

    with pytest.raises(
        ValueError,
        match="duplicate PATIENT_ID",
    ):
        merge_clinical_tables(patient_df, sample_df)


# Check that unmatched patient IDs are rejected.
def test_merge_clinical_tables_rejects_unmatched_patient_ids() -> None:
    patient_df = pd.DataFrame(
        {
            "PATIENT_ID": ["P1", "P2"],
        }
    )

    sample_df = pd.DataFrame(
        {
            "PATIENT_ID": ["P1", "P3"],
            "SAMPLE_ID": ["S1", "S3"],
        }
    )

    with pytest.raises(
        ValueError,
        match="Patient IDs do not match",
    ):
        merge_clinical_tables(patient_df, sample_df)


# ---------------------------------------------------------------------------
# Survival Target Tests
# ---------------------------------------------------------------------------

# Check that survival durations and event indicators are created.
def test_create_survival_target() -> None:
    clinical_df = pd.DataFrame(
        {
            "PATIENT_ID": ["P1", "P2", "P3"],
            "OS_MONTHS": [12.0, 24.0, 36.0],
            "OS_STATUS": [
                "0:LIVING",
                "1:DECEASED",
                "LIVING",
            ],
        }
    )

    # Create the survival target.
    result = create_survival_target(clinical_df)

    # Check the survival target values.
    assert result["duration"].tolist() == [12.0, 24.0, 36.0]
    assert result["event"].tolist() == [0, 1, 0]


# Check that rows with missing survival outcomes are removed.
def test_create_survival_target_removes_missing_outcomes() -> None:
    clinical_df = pd.DataFrame(
        {
            "PATIENT_ID": ["P1", "P2", "P3"],
            "OS_MONTHS": [12.0, None, 36.0],
            "OS_STATUS": [
                "0:LIVING",
                "1:DECEASED",
                None,
            ],
        }
    )

    # Create the survival target.
    result = create_survival_target(clinical_df)

    # Check the remaining complete patient record.
    assert len(result) == 1
    assert result["PATIENT_ID"].tolist() == ["P1"]


# Check that an unsupported survival status is rejected.
def test_create_survival_target_rejects_unknown_status() -> None:
    clinical_df = pd.DataFrame(
        {
            "OS_MONTHS": [12.0],
            "OS_STATUS": ["UNKNOWN"],
        }
    )

    with pytest.raises(
        ValueError,
        match="Unsupported OS_STATUS",
    ):
        create_survival_target(clinical_df)


# Check that a negative survival duration is rejected.
def test_create_survival_target_rejects_negative_duration() -> None:
    clinical_df = pd.DataFrame(
        {
            "OS_MONTHS": [-1.0],
            "OS_STATUS": ["1:DECEASED"],
        }
    )

    with pytest.raises(
        ValueError,
        match="Negative overall-survival",
    ):
        create_survival_target(clinical_df)


# ---------------------------------------------------------------------------
# Model Data Selection Tests
# ---------------------------------------------------------------------------

# Check that the clinical model features are selected.
def test_select_model_data_clinical() -> None:
    data = {
        feature: [1, 2]
        for feature in CLINICAL_FEATURES
    }

    data.update(
        {
            "INTCLUST": ["4ER+", "3"],
            "TMB_NONSYNONYMOUS": [2.1, 4.3],
            "duration": [12.0, 24.0],
            "event": [0, 1],
        }
    )

    clinical_df = pd.DataFrame(data)

    # Select the clinical model data.
    X, duration, event = select_model_data(
        clinical_df,
        model_type="clinical",
    )

    # Check the selected clinical features and survival target.
    assert X.columns.tolist() == CLINICAL_FEATURES
    assert "INTCLUST" not in X.columns
    assert duration.tolist() == [12.0, 24.0]
    assert event.tolist() == [0, 1]


# Check that the extended model features are selected.
def test_select_model_data_extended() -> None:
    data = {
        feature: [1, 2]
        for feature in EXTENDED_FEATURES
    }

    data.update(
        {
            "duration": [12.0, 24.0],
            "event": [0, 1],
        }
    )

    clinical_df = pd.DataFrame(data)

    # Select the extended model data.
    X, duration, event = select_model_data(
        clinical_df,
        model_type="extended",
    )

    # Check the selected extended features and survival target.
    assert X.columns.tolist() == EXTENDED_FEATURES
    assert "INTCLUST" in X.columns
    assert "TMB_NONSYNONYMOUS" in X.columns
    assert duration.tolist() == [12.0, 24.0]
    assert event.tolist() == [0, 1]


# Check that an unknown model type is rejected.
def test_select_model_data_rejects_unknown_model_type() -> None:
    clinical_df = pd.DataFrame(
        {
            "duration": [12.0],
            "event": [1],
        }
    )

    with pytest.raises(
        ValueError,
        match="model_type must be",
    ):
        select_model_data(
            clinical_df,
            model_type="unknown",
        )


# Check that missing model features are rejected.
def test_select_model_data_rejects_missing_features() -> None:
    clinical_df = pd.DataFrame(
        {
            "AGE_AT_DIAGNOSIS": [50],
            "duration": [12.0],
            "event": [1],
        }
    )

    with pytest.raises(
        KeyError,
        match="Missing required modelling columns",
    ):
        select_model_data(
            clinical_df,
            model_type="clinical",
        )


# ---------------------------------------------------------------------------
# Raw Model Data Tests
# ---------------------------------------------------------------------------

# Check that raw extended model data is prepared from the archive.
def test_prepare_raw_model_data(tmp_path: Path) -> None:
    archive_path = tmp_path / "synthetic_metabric.tar.gz"

    patient_content = """# synthetic patient table
PATIENT_ID\tOS_MONTHS\tOS_STATUS
P1\t12\t0:LIVING
P2\t24\t1:DECEASED
P3\t\t1:DECEASED
"""

    sample_columns = [
        "PATIENT_ID",
        "SAMPLE_ID",
        *CLINICAL_FEATURES,
        "INTCLUST",
        "TMB_NONSYNONYMOUS",
    ]

    sample_rows = [
        [
            "P1",
            "S1",
            50,
            "High",
            1,
            "Positive",
            "Negative",
            "Positive",
            2,
            20,
            2,
            "Post",
            "Ductal/NST",
            "4ER+",
            2.3,
        ],
        [
            "P2",
            "S2",
            65,
            "Moderate",
            3,
            "Negative",
            "Positive",
            "Negative",
            3,
            40,
            3,
            "Post",
            "Lobular",
            "3",
            5.1,
        ],
        [
            "P3",
            "S3",
            55,
            "Low",
            0,
            "Positive",
            "Negative",
            "Positive",
            1,
            15,
            1,
            "Pre",
            "Ductal/NST",
            "7",
            1.2,
        ],
    ]

    # Create the synthetic sample table.
    sample_content = (
        "# synthetic sample table\n"
        + "\t".join(sample_columns)
        + "\n"
        + "\n".join(
            "\t".join(map(str, row))
            for row in sample_rows
        )
        + "\n"
    )

    # Create the synthetic METABRIC archive.
    with tarfile.open(archive_path, mode="w:gz") as archive:
        add_text_file(
            archive,
            "study/data_clinical_patient.txt",
            patient_content,
        )

        add_text_file(
            archive,
            "study/data_clinical_sample.txt",
            sample_content,
        )

    # Prepare the extended model data from the archive.
    X, duration, event = prepare_raw_model_data(
        archive_path=archive_path,
        model_type="extended",
    )

    # Check the prepared model data.
    assert len(X) == 2
    assert X.columns.tolist() == EXTENDED_FEATURES
    assert duration.tolist() == [12, 24]
    assert event.tolist() == [0, 1]