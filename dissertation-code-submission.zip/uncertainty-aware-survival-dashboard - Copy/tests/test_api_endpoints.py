from fastapi.testclient import TestClient

from api.main import app


# ---------------------------------------------------------------------------
# Test Data
# ---------------------------------------------------------------------------

# Create a valid patient payload for the API endpoint tests.
def make_patient_payload() -> dict[str, object]:
    return {
        "age_at_diagnosis": 58.0,
        "lymph_nodes_examined_positive": 2.0,
        "grade": 2.0,
        "tumor_size": 24.0,
        "tumor_stage": 2.0,
        "tmb_nonsynonymous": 3.5,
        "cellularity": "Moderate",
        "er_status": "Positive",
        "her2_status": "Negative",
        "pr_status": "Positive",
        "inferred_menopausal_state": "Post",
        "histological_subtype": "Ductal/NST",
        "integrative_cluster": "3",
    }


# ---------------------------------------------------------------------------
# Root Endpoint Tests
# ---------------------------------------------------------------------------

# Check that the root endpoint returns the API message.
def test_root_endpoint() -> None:
    with TestClient(app) as client:
        response = client.get("/")

    assert response.status_code == 200
    assert (
        response.json()["message"]
        == "Breast cancer survival prediction API"
    )


# ---------------------------------------------------------------------------
# Health Endpoint Tests
# ---------------------------------------------------------------------------

# Check that the health endpoint reports the API and model as available.
def test_health_endpoint() -> None:
    with TestClient(app) as client:
        response = client.get("/health")

    assert response.status_code == 200

    body = response.json()

    assert body["status"] == "healthy"
    assert body["model_loaded"] is True


# ---------------------------------------------------------------------------
# Prediction Endpoint Tests
# ---------------------------------------------------------------------------

# Check that the prediction endpoint returns a valid prognosis response.
def test_predict_endpoint() -> None:
    with TestClient(app) as client:
        response = client.post(
            "/predict",
            json=make_patient_payload(),
        )

    assert response.status_code == 200

    body = response.json()

    assert (
        body["model_name"]
        == "MTLR X-CAL Deep Ensemble"
    )

    assert 0.0 <= (
        body["one_year"]["probability"]
    ) <= 1.0

    assert 0.0 <= (
        body["three_year"]["probability"]
    ) <= 1.0

    assert 0.0 <= (
        body["five_year"]["probability"]
    ) <= 1.0

    assert (
        body["one_year"]["probability"]
        >= body["three_year"]["probability"]
        >= body["five_year"]["probability"]
    )

    assert (
        body["overall_model_disagreement"]
        is not None
    )

    assert (
        body["model_disagreement_label"]
        is not None
    )

    assert len(
        body["survival_curve"]
    ) == 40

    first_point = body["survival_curve"][0]

    assert first_point["lower_disagreement_bound"] is not None
    assert first_point["upper_disagreement_bound"] is not None

    assert (
            first_point["lower_disagreement_bound"]
            <= first_point["survival_probability"]
            <= first_point["upper_disagreement_bound"]
    )

    assert len(
        body["limitations"]
    ) >= 3


# Check that the prediction endpoint rejects invalid patient input.
def test_predict_endpoint_rejects_invalid_input() -> None:
    payload = make_patient_payload()
    payload["tumor_size"] = -1.0

    with TestClient(app) as client:
        response = client.post(
            "/predict",
            json=payload,
        )

    assert response.status_code == 422