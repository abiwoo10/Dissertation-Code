import pandas as pd
import pytest


from ml.calibration import (
    calculate_censoring_adjusted_d_calibration,
    calculate_uncensored_d_calibration,
)

from ml.evaluation import (
    EvaluationResult,
    SurvivalModelEvaluator,
    calculate_concordance_index,
    calculate_integrated_brier_score,
)
from ml.prediction import SurvivalPrediction

import numpy as np


# ---------------------------------------------------------------------------
# Test Prediction
# ---------------------------------------------------------------------------

# Create the survival prediction used by the evaluation tests.
def make_prediction() -> SurvivalPrediction:
    return SurvivalPrediction(
        one_year_survival=pd.Series([0.9, 0.8]),
        three_year_survival=pd.Series([0.8, 0.7]),
        five_year_survival=pd.Series([0.7, 0.6]),
        survival_curve=pd.DataFrame(
            {
                12: [0.9, 0.8],
                36: [0.8, 0.7],
                60: [0.7, 0.6],
            }
        ),
        risk_score=pd.Series([0.2, 0.5]),
        model_name="TestModel",
        prediction_times=[12, 36, 60],
    )


# ---------------------------------------------------------------------------
# Evaluation Tests
# ---------------------------------------------------------------------------

# Check the survival model evaluation result.
def test_evaluation_interface() -> None:
    prediction = make_prediction()

    evaluator = SurvivalModelEvaluator()

    result = evaluator.evaluate(
        prediction,
        duration=pd.Series([24.0, 48.0]),
        event=pd.Series([1, 1]),
    )

    assert isinstance(result, EvaluationResult)

    assert result.model_name == "TestModel"

    assert result.prediction_count == 2

    assert result.concordance_index is not None
    assert 0.0 <= result.concordance_index <= 1.0


# Check that evaluation rejects a prediction count mismatch.
def test_prediction_count_validation() -> None:
    prediction = make_prediction()

    evaluator = SurvivalModelEvaluator()

    with pytest.raises(
        ValueError,
        match="Prediction count",
    ):
        evaluator.evaluate(
            prediction,
            duration=pd.Series([24.0]),
            event=pd.Series([1]),
        )


# ---------------------------------------------------------------------------
# Concordance Index Tests
# ---------------------------------------------------------------------------

# Check the concordance index calculation.
def test_calculate_concordance_index() -> None:
    duration = pd.Series([10.0, 20.0, 30.0, 40.0])
    event = pd.Series([1, 1, 1, 1])

    # Earlier deaths have higher predicted risk.
    risk_score = pd.Series([4.0, 3.0, 2.0, 1.0])

    result = calculate_concordance_index(
        duration,
        event,
        risk_score,
    )

    assert result == pytest.approx(1.0)


# Check that the concordance index rejects inputs with different lengths.
def test_calculate_concordance_index_rejects_length_mismatch() -> None:
    with pytest.raises(
        ValueError,
        match="same length",
    ):
        calculate_concordance_index(
            duration=pd.Series([10.0, 20.0]),
            event=pd.Series([1]),
            risk_score=pd.Series([0.5, 0.2]),
        )


# ---------------------------------------------------------------------------
# Integrated Brier Score Tests
# ---------------------------------------------------------------------------

# Check the integrated Brier score calculation.
def test_calculate_integrated_brier_score() -> None:
    prediction = make_prediction()

    result = calculate_integrated_brier_score(
        prediction=prediction,
        duration=pd.Series([24.0, 48.0]),
        event=pd.Series([1, 1]),
        evaluation_times=[12.0, 36.0, 60.0],
    )

    assert np.isfinite(result)
    assert 0.0 <= result <= 1.0


# Check that the evaluator calculates the integrated Brier score.
def test_evaluator_calculates_integrated_brier_score() -> None:
    prediction = make_prediction()

    evaluator = SurvivalModelEvaluator()

    result = evaluator.evaluate(
        prediction=prediction,
        duration=pd.Series([24.0, 48.0]),
        event=pd.Series([1, 1]),
        evaluation_times=[12.0, 36.0, 60.0],
    )

    assert result.integrated_brier_score is not None
    assert 0.0 <= result.integrated_brier_score <= 1.0


# Check that the integrated Brier score rejects missing evaluation times.
def test_integrated_brier_score_rejects_missing_times() -> None:
    prediction = make_prediction()

    with pytest.raises(
        ValueError,
        match="does not contain every evaluation time",
    ):
        calculate_integrated_brier_score(
            prediction=prediction,
            duration=pd.Series([24.0, 48.0]),
            event=pd.Series([1, 1]),
            evaluation_times=[12.0, 24.0, 60.0],
        )


# ---------------------------------------------------------------------------
# D-Calibration Tests
# ---------------------------------------------------------------------------

# Check the uncensored D-calibration calculation.
def test_calculate_uncensored_d_calibration() -> None:
    prediction = make_prediction()

    result = calculate_uncensored_d_calibration(
        prediction=prediction,
        duration=pd.Series([24.0, 48.0]),
        event=pd.Series([1, 1]),
        number_of_bins=2,
    )

    assert result["number_of_bins"] == 2
    assert result["uncensored_count"] == 2
    assert len(result["observed_counts"]) == 2
    assert len(result["expected_counts"]) == 2
    assert 0.0 <= result["p_value"] <= 1.0


# Check that D-calibration requires an uncensored event.
def test_d_calibration_requires_uncensored_event() -> None:
    prediction = make_prediction()

    with pytest.raises(
        ValueError,
        match="At least one uncensored event",
    ):
        calculate_uncensored_d_calibration(
            prediction=prediction,
            duration=pd.Series([24.0, 48.0]),
            event=pd.Series([0, 0]),
        )


# Check that D-calibration requires at least two bins.
def test_d_calibration_rejects_too_few_bins() -> None:
    prediction = make_prediction()

    with pytest.raises(
        ValueError,
        match="at least 2",
    ):
        calculate_uncensored_d_calibration(
            prediction=prediction,
            duration=pd.Series([24.0, 48.0]),
            event=pd.Series([1, 1]),
            number_of_bins=1,
        )


# ---------------------------------------------------------------------------
# Censoring-Adjusted D-Calibration Tests
# ---------------------------------------------------------------------------

# Check the censoring-adjusted D-calibration calculation.
def test_censoring_adjusted_d_calibration() -> None:
    prediction = make_prediction()

    result = calculate_censoring_adjusted_d_calibration(
        prediction=prediction,
        duration=pd.Series([24.0, 48.0]),
        event=pd.Series([1, 0]),
        number_of_bins=2,
    )

    assert result["patient_count"] == 2
    assert result["event_count"] == 1
    assert result["censored_count"] == 1

    assert len(result["observed_counts"]) == 2
    assert len(result["expected_counts"]) == 2

    assert sum(
        result["observed_counts"]
    ) == pytest.approx(2.0)

    assert 0.0 <= result["p_value"] <= 1.0


# Check that censoring-adjusted D-calibration uses all patients.
def test_censoring_adjusted_d_calibration_uses_all_patients() -> None:
    prediction = make_prediction()

    result = calculate_censoring_adjusted_d_calibration(
        prediction=prediction,
        duration=pd.Series([24.0, 48.0]),
        event=pd.Series([0, 0]),
        number_of_bins=2,
    )

    assert result["patient_count"] == 2
    assert result["event_count"] == 0
    assert result["censored_count"] == 2

    assert sum(
        result["observed_counts"]
    ) == pytest.approx(2.0)


# Check that censoring-adjusted D-calibration rejects invalid event values.
def test_censoring_adjusted_d_calibration_rejects_invalid_event() -> None:
    prediction = make_prediction()

    with pytest.raises(
        ValueError,
        match="unsupported values",
    ):
        calculate_censoring_adjusted_d_calibration(
            prediction=prediction,
            duration=pd.Series([24.0, 48.0]),
            event=pd.Series([1, 2]),
        )