import pytest
from pydantic import ValidationError

from api.schemas import (
    HorizonEstimate,
    PatientFeatures,
    PrognosisResponse,
    SurvivalCurvePoint,
)


# ---------------------------------------------------------------------------
# Test Data
# ---------------------------------------------------------------------------

# Create valid patient feature values for the API schema tests.
def make_patient_features() -> dict[str, object]:
    return {
        "age_at_diagnosis": 58.0,
        "lymph_nodes_examined_positive": 2.0,
        "grade": 2.0,
        "tumor_size": 24.0,
        "tumor_stage": 2.0,
        "tmb_nonsynonymous": 3.5,
        "cellularity": "Moderate",
        "er_status": "Positive",
        "her2_status": "Negative",
        "pr_status": "Positive",
        "inferred_menopausal_state": "Post",
        "histological_subtype": "Ductal/NST",
        "integrative_cluster": "3",
    }


# ---------------------------------------------------------------------------
# Patient Feature Tests
# ---------------------------------------------------------------------------

# Check that valid patient features are accepted.
def test_patient_features_accept_valid_input() -> None:
    patient = PatientFeatures(
        **make_patient_features()
    )

    assert patient.age_at_diagnosis == 58.0
    assert patient.er_status == "Positive"


# Check that an invalid ER status is rejected.
def test_patient_features_reject_invalid_er_status() -> None:
    values = make_patient_features()
    values["er_status"] = "Unknown"

    with pytest.raises(ValidationError):
        PatientFeatures(**values)


# Check that a negative tumour size is rejected.
def test_patient_features_reject_negative_tumor_size() -> None:
    values = make_patient_features()
    values["tumor_size"] = -2.0

    with pytest.raises(ValidationError):
        PatientFeatures(**values)


# ---------------------------------------------------------------------------
# Prognosis Response Tests
# ---------------------------------------------------------------------------

# Check that the prognosis response schema accepts valid values.
def test_prognosis_response_schema() -> None:
    response = PrognosisResponse(
        model_name="MTLR X-CAL Deep Ensemble",
        one_year=HorizonEstimate(
            probability=0.95,
            percentage=95.0,
            model_disagreement=0.01,
        ),
        three_year=HorizonEstimate(
            probability=0.85,
            percentage=85.0,
            model_disagreement=0.02,
        ),
        five_year=HorizonEstimate(
            probability=0.75,
            percentage=75.0,
            model_disagreement=0.03,
        ),
        median_survival_months=None,
        median_survival_years=None,
        overall_model_disagreement=0.02,
        model_disagreement_label=(
            "Moderate model disagreement"
        ),
        survival_curve=[
            SurvivalCurvePoint(
                months=12.0,
                survival_probability=0.95,
            ),
            SurvivalCurvePoint(
                months=36.0,
                survival_probability=0.85,
            ),
        ],
        patient_explanation="Model estimate.",
        uncertainty_explanation=(
            "Member disagreement is not a confidence interval."
        ),
        limitations=[
            "Research prototype only.",
        ],
    )

    assert response.one_year.percentage == 95.0
    assert len(response.survival_curve) == 2