import io
import tarfile
from pathlib import Path

import pandas as pd

from scripts.generate_metabric_dictionary import (
    generate_data_dictionary,
)


# ---------------------------------------------------------------------------
# Test Archive Helper
# ---------------------------------------------------------------------------

# Add a text file to the test archive.
def add_text_file(
    archive: tarfile.TarFile,
    filename: str,
    content: str,
) -> None:
    encoded = content.encode("utf-8")
    info = tarfile.TarInfo(name=filename)
    info.size = len(encoded)

    archive.addfile(info, io.BytesIO(encoded))


# ---------------------------------------------------------------------------
# Data Dictionary Tests
# ---------------------------------------------------------------------------

# Check that the METABRIC data dictionary is generated and saved.
def test_generate_data_dictionary(tmp_path: Path) -> None:
    archive_path = tmp_path / "synthetic_metabric.tar.gz"
    output_path = tmp_path / "dictionary.csv"

    patient_content = """# synthetic patient file
PATIENT_ID\tOS_MONTHS\tOS_STATUS\tAGE_AT_DIAGNOSIS
P1\t12\t0:LIVING\t45
P2\t24\t1:DECEASED\t60
P3\t\t\t55
"""

    sample_content = """# synthetic sample file
PATIENT_ID\tSAMPLE_ID\tER_STATUS
P1\tS1\tPositive
P2\tS2\tNegative
P3\tS3\tPositive
"""

    # Create the synthetic METABRIC archive.
    with tarfile.open(archive_path, mode="w:gz") as archive:
        add_text_file(
            archive,
            "study/data_clinical_patient.txt",
            patient_content,
        )
        add_text_file(
            archive,
            "study/data_clinical_sample.txt",
            sample_content,
        )

    # Generate the data dictionary.
    result = generate_data_dictionary(
        archive_path=archive_path,
        output_path=output_path,
    )

    # Check the generated data dictionary.
    assert output_path.exists()
    assert not result.empty

    # Load the saved data dictionary.
    saved = pd.read_csv(output_path)

    assert "column" in saved.columns
    assert "missing_percent" in saved.columns
    assert "example_values" in saved.columns

    # Get the OS_MONTHS dictionary entry.
    os_months = saved.loc[
        saved["column"] == "OS_MONTHS"
    ].iloc[0]

    # Check the OS_MONTHS summary values.
    assert os_months["missing_count"] == 1
    assert os_months["unique_count"] == 2