from __future__ import annotations

import io
import json
import tarfile
from pathlib import Path

from scripts.audit_metabric import audit_metabric


# ---------------------------------------------------------------------------
# Test Archive Helpers
# ---------------------------------------------------------------------------

# Add a text file to the test archive.
def add_text_member(archive: tarfile.TarFile, name: str, content: str) -> None:
    payload = content.encode("utf-8")
    info = tarfile.TarInfo(name=name)
    info.size = len(payload)
    archive.addfile(info, io.BytesIO(payload))


# Create a METABRIC archive for the audit test.
def create_test_archive(path: Path) -> None:
    patient = """# metadata line
PATIENT_ID\tOS_MONTHS\tOS_STATUS\tAGE_AT_DIAGNOSIS\tER_IHC\tVITAL_STATUS
P1\t10\t0:LIVING\t50\tPositve\tLiving
P2\t20\t1:DECEASED\t60\tNegative\tDied
"""
    sample = """# metadata line
PATIENT_ID\tSAMPLE_ID\tTUMOR_SIZE
P1\tS1\t20
P2\tS2\t30
"""

    # Add the patient and sample tables to the archive.
    with tarfile.open(path, "w:gz") as archive:
        add_text_member(
            archive,
            "brca_metabric/data_clinical_patient.txt",
            patient,
        )
        add_text_member(
            archive,
            "brca_metabric/data_clinical_sample.txt",
            sample,
        )


# ---------------------------------------------------------------------------
# METABRIC Audit Tests
# ---------------------------------------------------------------------------

# Check the generated METABRIC audit report and output files.
def test_audit_metabric(tmp_path: Path) -> None:
    archive_path = tmp_path / "test_metabric.tar.gz"
    output_dir = tmp_path / "reports"

    # Create the test METABRIC archive.
    create_test_archive(archive_path)

    # Run the METABRIC audit.
    report = audit_metabric(archive_path, output_dir)

    # Check the generated audit results.
    assert report["cohort"]["patient_rows"] == 2
    assert report["survival_target"]["events"] == 1
    assert report["survival_target"]["censored"] == 1
    assert report["data_quality"]["er_ihc_values"] == ["Negative", "Positive"]
    assert (output_dir / "metabric_audit.json").exists()
    assert (output_dir / "metabric_missingness.csv").exists()

    # Load the saved audit report.
    saved_report = json.loads(
        (output_dir / "metabric_audit.json").read_text(encoding="utf-8")
    )

    # Check the saved audit results.
    assert saved_report["survival_target"]["complete_rows"] == 2