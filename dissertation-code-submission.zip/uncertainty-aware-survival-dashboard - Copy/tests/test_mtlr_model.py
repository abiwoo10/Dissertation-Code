from pathlib import Path

import numpy as np
import pandas as pd
import pytest
import torch

from ml.mtlr_layer import MTLRLayer
from ml.mtlr_model import MTLRModel
from ml.mtlr_utils import (
    build_time_bins,
    encode_mtlr_targets,
    interval_probabilities_to_cdf_at_times,
    interval_probabilities_to_survival,
    mtlr_negative_log_likelihood,
)
from ml.prediction import SurvivalPrediction


# ---------------------------------------------------------------------------
# Time Bin Tests
# ---------------------------------------------------------------------------

# Check that time bins are created from the survival data.
def test_build_time_bins() -> None:
    duration = pd.Series(
        [5.0, 10.0, 15.0, 20.0, 25.0, 30.0]
    )

    event = pd.Series(
        [1, 1, 0, 1, 0, 1]
    )

    bins = build_time_bins(
        duration=duration,
        event=event,
        number_of_bins=3,
    )

    assert isinstance(bins, np.ndarray)
    assert bins.ndim == 1
    assert len(bins) >= 2
    assert np.all(np.diff(bins) > 0)

    # Only uncensored event times are used.
    assert bins[0] == pytest.approx(5.0)
    assert bins[-1] == pytest.approx(30.0)


# Check that time bin creation is deterministic.
def test_build_time_bins_is_deterministic() -> None:
    duration = pd.Series(
        [5.0, 10.0, 15.0, 20.0, 25.0, 30.0]
    )

    event = pd.Series(
        [1, 1, 0, 1, 0, 1]
    )

    first = build_time_bins(
        duration,
        event,
        number_of_bins=3,
    )

    second = build_time_bins(
        duration,
        event,
        number_of_bins=3,
    )

    np.testing.assert_array_equal(first, second)


# Check that unsupported event values are rejected.
def test_build_time_bins_rejects_invalid_event() -> None:
    with pytest.raises(
        ValueError,
        match="unsupported values",
    ):
        build_time_bins(
            duration=pd.Series([5.0, 10.0]),
            event=pd.Series([0, 2]),
        )


# Check that time bin creation requires an uncensored event.
def test_build_time_bins_requires_uncensored_event() -> None:
    with pytest.raises(
        ValueError,
        match="At least one uncensored event",
    ):
        build_time_bins(
            duration=pd.Series([5.0, 10.0]),
            event=pd.Series([0, 0]),
        )


# Check that time bin creation requires at least two bins.
def test_build_time_bins_rejects_too_few_bins() -> None:
    with pytest.raises(
        ValueError,
        match="at least 2",
    ):
        build_time_bins(
            duration=pd.Series([5.0, 10.0]),
            event=pd.Series([1, 1]),
            number_of_bins=1,
        )


# ---------------------------------------------------------------------------
# MTLR Target Encoding Tests
# ---------------------------------------------------------------------------

# Check MTLR target encoding for observed events.
def test_encode_mtlr_targets_for_events() -> None:
    duration = pd.Series([5.0, 15.0, 25.0, 35.0])
    event = pd.Series([1, 1, 1, 1])
    time_bins = np.array([10.0, 20.0, 30.0])

    encoded = encode_mtlr_targets(
        duration,
        event,
        time_bins,
    )

    np.testing.assert_array_equal(
        encoded,
        np.array(
            [
                [1.0, 0.0, 0.0, 0.0],
                [0.0, 1.0, 0.0, 0.0],
                [0.0, 0.0, 1.0, 0.0],
                [0.0, 0.0, 0.0, 1.0],
            ],
            dtype=np.float32,
        ),
    )


# Check MTLR target encoding for censored observations.
def test_encode_mtlr_targets_for_censoring() -> None:
    duration = pd.Series([5.0, 15.0, 35.0])
    event = pd.Series([0, 0, 0])
    time_bins = np.array([10.0, 20.0, 30.0])

    encoded = encode_mtlr_targets(
        duration,
        event,
        time_bins,
    )

    np.testing.assert_array_equal(
        encoded,
        np.array(
            [
                [1.0, 1.0, 1.0, 1.0],
                [0.0, 1.0, 1.0, 1.0],
                [0.0, 0.0, 0.0, 1.0],
            ],
            dtype=np.float32,
        ),
    )


# Check that unsorted time bins are rejected.
def test_encode_mtlr_targets_rejects_unsorted_bins() -> None:
    with pytest.raises(
        ValueError,
        match="strictly increasing",
    ):
        encode_mtlr_targets(
            duration=pd.Series([5.0]),
            event=pd.Series([1]),
            time_bins=np.array([20.0, 10.0]),
        )


# Check that target inputs with different lengths are rejected.
def test_encode_mtlr_targets_rejects_length_mismatch() -> None:
    with pytest.raises(
        ValueError,
        match="same number of rows",
    ):
        encode_mtlr_targets(
            duration=pd.Series([5.0, 10.0]),
            event=pd.Series([1]),
            time_bins=np.array([0.0, 10.0, 20.0]),
        )


# ---------------------------------------------------------------------------
# MTLR Layer Tests
# ---------------------------------------------------------------------------

# Check the output shape produced by the MTLR layer.
def test_mtlr_layer_output_shape() -> None:
    layer = MTLRLayer(
        input_features=3,
        interval_count=5,
    )

    features = torch.randn(4, 3)

    logits = layer(features)

    assert logits.shape == (4, 5)


# Check the interval probabilities produced by the MTLR layer.
def test_mtlr_interval_probabilities_sum_to_one() -> None:
    layer = MTLRLayer(
        input_features=2,
        interval_count=4,
    )

    features = torch.randn(6, 2)

    probabilities = layer.predict_interval_probabilities(
        features
    )

    assert probabilities.shape == (6, 4)

    torch.testing.assert_close(
        probabilities.sum(dim=1),
        torch.ones(6),
    )

    assert torch.all(probabilities >= 0)
    assert torch.all(probabilities <= 1)


# Check that an unexpected feature count is rejected.
def test_mtlr_layer_rejects_wrong_feature_count() -> None:
    layer = MTLRLayer(
        input_features=3,
        interval_count=4,
    )

    with pytest.raises(
        ValueError,
        match="unexpected number of columns",
    ):
        layer(torch.randn(2, 5))


# ---------------------------------------------------------------------------
# MTLR Loss Tests
# ---------------------------------------------------------------------------

# Check the MTLR negative log-likelihood for observed events.
def test_mtlr_negative_log_likelihood_for_events() -> None:
    logits = torch.tensor(
        [
            [2.0, 1.0, 0.0],
            [0.0, 1.0, 2.0],
        ]
    )

    targets = torch.tensor(
        [
            [1.0, 0.0, 0.0],
            [0.0, 0.0, 1.0],
        ]
    )

    loss = mtlr_negative_log_likelihood(
        logits,
        targets,
    )

    assert loss.ndim == 0
    assert torch.isfinite(loss)
    assert loss > 0


# Check the MTLR negative log-likelihood for censoring.
def test_mtlr_negative_log_likelihood_for_censoring() -> None:
    logits = torch.tensor(
        [
            [2.0, 1.0, 0.0],
        ]
    )

    # Censoring permits survival in the final two intervals.
    targets = torch.tensor(
        [
            [0.0, 1.0, 1.0],
        ]
    )

    loss = mtlr_negative_log_likelihood(
        logits,
        targets,
    )

    expected = -torch.log(
        torch.softmax(logits, dim=1)[0, 1:].sum()
    )

    torch.testing.assert_close(
        loss,
        expected,
    )


# Check that loss inputs with different shapes are rejected.
def test_mtlr_loss_rejects_shape_mismatch() -> None:
    with pytest.raises(
        ValueError,
        match="same shape",
    ):
        mtlr_negative_log_likelihood(
            interval_logits=torch.randn(3, 4),
            target_mask=torch.ones(3, 3),
        )


# ---------------------------------------------------------------------------
# Test Training Data
# ---------------------------------------------------------------------------

# Create the training data used by the MTLR model tests.
def make_training_data() -> tuple[
    pd.DataFrame,
    pd.Series,
    pd.Series,
]:
    X = pd.DataFrame(
        {
            "age": [
                42.0,
                48.0,
                53.0,
                57.0,
                61.0,
                65.0,
                69.0,
                74.0,
            ],
            "tumour_size": [
                12.0,
                18.0,
                20.0,
                24.0,
                28.0,
                33.0,
                38.0,
                45.0,
            ],
        }
    )

    duration = pd.Series(
        [120.0, 105.0, 90.0, 78.0, 62.0, 48.0, 32.0, 20.0]
    )

    event = pd.Series(
        [0, 0, 1, 0, 1, 1, 1, 1]
    )

    return X, duration, event


# ---------------------------------------------------------------------------
# MTLR Model Fitting Tests
# ---------------------------------------------------------------------------

# Check that the MTLR model is fitted.
def test_mtlr_model_fit() -> None:
    X, duration, event = make_training_data()

    model = MTLRModel(
        number_of_bins=4,
        learning_rate=0.01,
        epochs=20,
        random_state=42,
    )

    model.fit(X, duration, event)

    assert model.is_fitted is True
    assert model.network is not None
    assert model.time_bins is not None
    assert model.feature_names == X.columns.tolist()
    assert len(model.training_losses) == 20
    assert np.isfinite(model.training_losses).all()


# Check that the MTLR training loss decreases.
def test_mtlr_training_loss_decreases() -> None:
    X, duration, event = make_training_data()

    model = MTLRModel(
        number_of_bins=4,
        learning_rate=0.01,
        epochs=50,
        random_state=42,
    )

    model.fit(X, duration, event)

    assert (
        model.training_losses[-1]
        < model.training_losses[0]
    )


# Check that model fitting rejects inputs with different row counts.
def test_mtlr_model_rejects_row_mismatch() -> None:
    X, duration, event = make_training_data()

    model = MTLRModel(
        number_of_bins=4,
        epochs=5,
    )

    with pytest.raises(
        ValueError,
        match="same number of rows",
    ):
        model.fit(
            X,
            duration.iloc[:-1],
            event,
        )


# ---------------------------------------------------------------------------
# Survival Conversion Tests
# ---------------------------------------------------------------------------

# Check conversion from interval probabilities to survival probabilities.
def test_interval_probabilities_to_survival() -> None:
    probabilities = torch.tensor(
        [
            [0.1, 0.2, 0.3, 0.4],
        ]
    )

    survival = interval_probabilities_to_survival(
        probabilities
    )

    expected = torch.tensor(
        [
            [0.9, 0.7, 0.4],
        ]
    )

    torch.testing.assert_close(
        survival,
        expected,
    )


# Check that interval survival probabilities are monotonic.
def test_interval_survival_is_monotonic() -> None:
    probabilities = torch.softmax(
        torch.randn(5, 6),
        dim=1,
    )

    survival = interval_probabilities_to_survival(
        probabilities
    )

    assert torch.all(
        survival[:, :-1]
        >= survival[:, 1:]
    )


# ---------------------------------------------------------------------------
# MTLR Prediction Tests
# ---------------------------------------------------------------------------

# Check the risk scores generated by the MTLR model.
def test_mtlr_predict_risk() -> None:
    X, duration, event = make_training_data()

    model = MTLRModel(
        number_of_bins=4,
        epochs=20,
        random_state=42,
    )

    model.fit(X, duration, event)

    risk = model.predict_risk(X)

    assert len(risk) == len(X)
    assert risk.name == "risk_score"
    assert np.isfinite(risk).all()


# Check the survival predictions generated by the MTLR model.
def test_mtlr_predict_survival() -> None:
    X, duration, event = make_training_data()

    model = MTLRModel(
        number_of_bins=4,
        epochs=20,
        random_state=42,
    )

    model.fit(X, duration, event)

    prediction = model.predict_survival(
        X,
        time_points=[12.0, 36.0, 60.0],
    )

    assert isinstance(
        prediction,
        SurvivalPrediction,
    )

    assert prediction.patient_count() == len(X)
    assert prediction.has_uncertainty() is False

    assert (
        prediction.one_year_survival
        >= prediction.three_year_survival
    ).all()

    assert (
        prediction.three_year_survival
        >= prediction.five_year_survival
    ).all()

    assert (
        (prediction.survival_curve >= 0.0)
        & (prediction.survival_curve <= 1.0)
    ).all().all()


# Check that survival prediction requires the standard time horizons.
def test_mtlr_predict_survival_requires_standard_horizons() -> None:
    X, duration, event = make_training_data()

    model = MTLRModel(
        number_of_bins=4,
        epochs=5,
    )

    model.fit(X, duration, event)

    with pytest.raises(
        ValueError,
        match="must include 12, 36, and 60",
    ):
        model.predict_survival(
            X,
            time_points=[12.0, 36.0],
        )


# ---------------------------------------------------------------------------
# MTLR Model Persistence Tests
# ---------------------------------------------------------------------------

# Check that a saved MTLR model can be loaded with matching predictions.
def test_mtlr_save_and_load(
    tmp_path: Path,
) -> None:
    X, duration, event = make_training_data()

    model = MTLRModel(
        number_of_bins=4,
        epochs=10,
        random_state=42,
    )

    model.fit(X, duration, event)

    model_path = tmp_path / "mtlr_model.pkl"
    model.save(model_path)

    loaded = MTLRModel.load(model_path)

    assert loaded.is_fitted is True
    assert loaded.feature_names == model.feature_names

    original_prediction = model.predict_survival(
        X,
        [12.0, 36.0, 60.0],
    )

    loaded_prediction = loaded.predict_survival(
        X,
        [12.0, 36.0, 60.0],
    )

    np.testing.assert_allclose(
        original_prediction.survival_curve,
        loaded_prediction.survival_curve,
    )


# Check that an unfitted MTLR model cannot be saved.
def test_mtlr_save_rejects_unfitted_model(
    tmp_path: Path,
) -> None:
    model = MTLRModel()

    with pytest.raises(
        RuntimeError,
        match="Cannot save an unfitted model",
    ):
        model.save(
            tmp_path / "unfitted.pkl"
        )


# ---------------------------------------------------------------------------
# MTLR Validation Tests
# ---------------------------------------------------------------------------

# Check model fitting with validation data.
def test_mtlr_fit_with_validation() -> None:
    X, duration, event = make_training_data()

    model = MTLRModel(
        number_of_bins=4,
        epochs=30,
        patience=5,
        random_state=42,
    )

    model.fit(
        X=X.iloc[:6],
        duration=duration.iloc[:6],
        event=event.iloc[:6],
        X_validation=X.iloc[6:],
        duration_validation=duration.iloc[6:],
        event_validation=event.iloc[6:],
    )

    assert model.is_fitted is True
    assert model.best_epoch is not None
    assert len(model.validation_losses) >= 1
    assert len(model.validation_losses) <= 30


# Check that partial validation data is rejected.
def test_mtlr_fit_rejects_partial_validation_data() -> None:
    X, duration, event = make_training_data()

    model = MTLRModel(
        number_of_bins=4,
        epochs=5,
    )

    with pytest.raises(
        ValueError,
        match="must either all be supplied",
    ):
        model.fit(
            X,
            duration,
            event,
            X_validation=X,
        )


# Check that early stopping restores the best model.
def test_mtlr_early_stopping_restores_best_model() -> None:
    X, duration, event = make_training_data()

    model = MTLRModel(
        number_of_bins=3,
        learning_rate=0.05,
        epochs=100,
        patience=3,
        minimum_improvement=1.0,
        random_state=42,
    )

    model.fit(
        X=X.iloc[:6],
        duration=duration.iloc[:6],
        event=event.iloc[:6],
        X_validation=X.iloc[6:],
        duration_validation=duration.iloc[6:],
        event_validation=event.iloc[6:],
    )

    assert model.stopped_early is True
    assert len(model.training_losses) < 100


# ---------------------------------------------------------------------------
# CDF Calculation Tests
# ---------------------------------------------------------------------------

# Check conversion from interval probabilities to CDF values.
def test_interval_probabilities_to_cdf_at_times() -> None:
    probabilities = torch.tensor(
        [
            [0.2, 0.3, 0.4, 0.1],
            [0.1, 0.2, 0.3, 0.4],
        ],
        dtype=torch.float32,
    )

    observed_times = torch.tensor(
        [5.0, 15.0],
        dtype=torch.float32,
    )

    time_bins = np.array(
        [10.0, 20.0, 30.0],
        dtype=float,
    )

    cdf = interval_probabilities_to_cdf_at_times(
        interval_probabilities=probabilities,
        observed_times=observed_times,
        time_bins=time_bins,
    )

    # Patient 1: halfway through first interval: 0.5 × 0.2 = 0.1
    # Patient 2: first interval mass 0.1 plus half of 0.2 = 0.2
    expected = torch.tensor(
        [0.1, 0.2],
        dtype=torch.float32,
    )

    torch.testing.assert_close(
        cdf,
        expected,
    )


# Check CDF calculation for the final open interval.
def test_cdf_at_times_handles_final_open_interval() -> None:
    probabilities = torch.tensor(
        [
            [0.2, 0.3, 0.4, 0.1],
        ],
        dtype=torch.float32,
    )

    cdf = interval_probabilities_to_cdf_at_times(
        interval_probabilities=probabilities,
        observed_times=torch.tensor([40.0]),
        time_bins=np.array([10.0, 20.0, 30.0]),
    )

    # Probability accumulated before the open-ended final interval.
    torch.testing.assert_close(
        cdf,
        torch.tensor([0.9]),
    )


# Check that the CDF calculation supports gradients.
def test_cdf_at_times_supports_gradients() -> None:
    logits = torch.tensor(
        [[1.0, 0.5, 0.0, -0.5]],
        requires_grad=True,
    )

    probabilities = torch.softmax(
        logits,
        dim=1,
    )

    cdf = interval_probabilities_to_cdf_at_times(
        interval_probabilities=probabilities,
        observed_times=torch.tensor([15.0]),
        time_bins=np.array([10.0, 20.0, 30.0]),
    )

    cdf.sum().backward()

    assert logits.grad is not None
    assert torch.isfinite(logits.grad).all()


# Check that CDF inputs with different patient counts are rejected.
def test_cdf_at_times_rejects_patient_mismatch() -> None:
    with pytest.raises(
        ValueError,
        match="same number of patients",
    ):
        interval_probabilities_to_cdf_at_times(
            interval_probabilities=torch.tensor(
                [
                    [0.2, 0.3, 0.5],
                    [0.3, 0.3, 0.4],
                ]
            ),
            observed_times=torch.tensor([10.0]),
            time_bins=np.array([10.0, 20.0]),
        )


# ---------------------------------------------------------------------------
# X-CAL Tests
# ---------------------------------------------------------------------------

# Check that the MTLR model trains with X-CAL.
def test_mtlr_model_trains_with_xcal() -> None:
    X, duration, event = make_training_data()

    model = MTLRModel(
        number_of_bins=4,
        epochs=10,
        calibration_weight=1.0,
        xcal_bins=5,
        xcal_gamma=100.0,
        random_state=42,
    )

    model.fit(
        X,
        duration,
        event,
    )

    assert model.is_fitted is True
    assert len(model.training_losses) == 10
    assert len(model.training_nll_losses) == 10
    assert len(model.training_xcal_losses) == 10

    assert np.isfinite(
        model.training_xcal_losses
    ).all()

    assert all(
        loss >= 0.0
        for loss in model.training_xcal_losses
    )


# Check that X-CAL losses are recorded with validation data.
def test_mtlr_model_xcal_with_validation() -> None:
    X, duration, event = make_training_data()

    model = MTLRModel(
        number_of_bins=4,
        epochs=10,
        patience=3,
        calibration_weight=0.5,
        xcal_bins=5,
        xcal_gamma=100.0,
        random_state=42,
    )

    model.fit(
        X=X.iloc[:6],
        duration=duration.iloc[:6],
        event=event.iloc[:6],
        X_validation=X.iloc[6:],
        duration_validation=duration.iloc[6:],
        event_validation=event.iloc[6:],
    )

    assert len(model.validation_losses) >= 1

    assert len(model.validation_nll_losses) == (
        len(model.validation_losses)
    )

    assert len(model.validation_xcal_losses) == (
        len(model.validation_losses)
    )


# Check that a negative calibration weight is rejected.
def test_mtlr_model_rejects_negative_calibration_weight() -> None:
    with pytest.raises(
        ValueError,
        match="calibration_weight must not be negative",
    ):
        MTLRModel(
            calibration_weight=-0.1,
        )