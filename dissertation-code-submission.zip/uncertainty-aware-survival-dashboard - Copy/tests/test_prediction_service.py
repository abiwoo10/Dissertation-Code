from pathlib import Path

import pytest

from api.prediction_service import (
    PredictionService,
    load_uncertainty_thresholds,
    patient_features_to_dataframe,
)
from api.schemas import PatientFeatures
from ml.feature_config import EXTENDED_FEATURES


# ---------------------------------------------------------------------------
# Test Patient Data
# ---------------------------------------------------------------------------

# Create the patient data used by the prediction service tests.
def make_patient() -> PatientFeatures:
    return PatientFeatures(
        age_at_diagnosis=58.0,
        lymph_nodes_examined_positive=2.0,
        grade=2.0,
        tumor_size=24.0,
        tumor_stage=2.0,
        tmb_nonsynonymous=3.5,
        cellularity="Moderate",
        er_status="Positive",
        her2_status="Negative",
        pr_status="Positive",
        inferred_menopausal_state="Post",
        histological_subtype="Ductal/NST",
        integrative_cluster="3",
    )


# ---------------------------------------------------------------------------
# Patient Data Conversion Tests
# ---------------------------------------------------------------------------

# Check that patient features are converted to the model dataframe.
def test_patient_features_to_dataframe() -> None:
    frame = patient_features_to_dataframe(
        make_patient()
    )

    assert frame.shape == (
        1,
        len(EXTENDED_FEATURES),
    )

    assert frame.columns.tolist() == EXTENDED_FEATURES

    assert (
        frame.loc[
            "patient",
            "AGE_AT_DIAGNOSIS",
        ]
        == 58.0
    )

    assert (
        frame.loc[
            "patient",
            "INTCLUST",
        ]
        == "3"
    )


# ---------------------------------------------------------------------------
# Uncertainty Threshold Tests
# ---------------------------------------------------------------------------

# Check that uncertainty thresholds are loaded from JSON.
def test_load_uncertainty_thresholds(
    tmp_path: Path,
) -> None:
    path = tmp_path / "thresholds.json"

    path.write_text(
        (
            '{'
            '"lower_threshold": 0.01,'
            '"higher_threshold": 0.03'
            '}'
        ),
        encoding="utf-8",
    )

    thresholds = load_uncertainty_thresholds(
        path
    )

    assert thresholds.lower_threshold == pytest.approx(
        0.01
    )

    assert thresholds.higher_threshold == pytest.approx(
        0.03
    )


# Check that a missing uncertainty threshold file is rejected.
def test_load_uncertainty_thresholds_rejects_missing_file(
    tmp_path: Path,
) -> None:
    with pytest.raises(
        FileNotFoundError,
        match="Uncertainty thresholds not found",
    ):
        load_uncertainty_thresholds(
            tmp_path / "missing.json"
        )


# ---------------------------------------------------------------------------
# Prediction Service Tests
# ---------------------------------------------------------------------------

# Check the prediction service response for valid patient data.
def test_prediction_service_end_to_end() -> None:
    service = PredictionService()

    result = service.predict(
        make_patient()
    )

    assert result.model_name == (
        "MTLR X-CAL Deep Ensemble"
    )

    assert 0.0 <= result.one_year.probability <= 1.0
    assert 0.0 <= result.three_year.probability <= 1.0
    assert 0.0 <= result.five_year.probability <= 1.0

    assert (
        result.one_year.probability
        >= result.three_year.probability
        >= result.five_year.probability
    )

    assert result.overall_model_disagreement is not None
    assert result.model_disagreement_label is not None

    assert len(result.survival_curve) == 40