import pandas as pd
import pytest

from ml.prediction import SurvivalPrediction
from ml.prognosis import (
    PatientPrognosis,
    UncertaintyThresholds,
    calculate_uncertainty_thresholds,
    classify_model_disagreement,
    create_patient_prognosis,
    estimate_median_survival,
    extract_horizon_uncertainty,
)


# ---------------------------------------------------------------------------
# Test Prediction
# ---------------------------------------------------------------------------

# Create the survival prediction used by the prognosis tests.
def make_prediction() -> SurvivalPrediction:
    index = ["patient_1", "patient_2"]

    return SurvivalPrediction(
        one_year_survival=pd.Series(
            [0.95, 0.85],
            index=index,
        ),
        three_year_survival=pd.Series(
            [0.80, 0.65],
            index=index,
        ),
        five_year_survival=pd.Series(
            [0.60, 0.45],
            index=index,
        ),
        survival_curve=pd.DataFrame(
            {
                12.0: [0.95, 0.85],
                36.0: [0.80, 0.65],
                60.0: [0.60, 0.45],
                84.0: [0.40, 0.25],
            },
            index=index,
        ),
        risk_score=pd.Series(
            [0.2, 0.7],
            index=index,
        ),
        model_name="Test MTLR",
        prediction_times=[
            12.0,
            36.0,
            60.0,
            84.0,
        ],
    )


# ---------------------------------------------------------------------------
# Median Survival Tests
# ---------------------------------------------------------------------------

# Check the estimated median survival time.
def test_estimate_median_survival() -> None:
    curve = pd.Series(
        [0.9, 0.7, 0.4],
        index=[12.0, 36.0, 60.0],
    )

    median = estimate_median_survival(curve)

    assert median == pytest.approx(52.0)


# Check that median survival is unavailable when the curve remains above 0.5.
def test_estimate_median_survival_returns_none() -> None:
    curve = pd.Series(
        [0.95, 0.85, 0.70],
        index=[12.0, 36.0, 60.0],
    )

    assert estimate_median_survival(curve) is None


# Check that an increasing survival curve is rejected.
def test_estimate_median_survival_rejects_increasing_curve() -> None:
    curve = pd.Series(
        [0.8, 0.9],
        index=[12.0, 36.0],
    )

    with pytest.raises(
        ValueError,
        match="must not increase",
    ):
        estimate_median_survival(curve)


# ---------------------------------------------------------------------------
# Patient Prognosis Tests
# ---------------------------------------------------------------------------

# Check the patient prognosis created from a survival prediction.
def test_create_patient_prognosis() -> None:
    prognosis = create_patient_prognosis(
        make_prediction(),
        patient_index="patient_1",
    )

    assert isinstance(
        prognosis,
        PatientPrognosis,
    )

    assert prognosis.model_name == "Test MTLR"
    assert prognosis.one_year_percentage() == pytest.approx(95.0)
    assert prognosis.three_year_percentage() == pytest.approx(80.0)
    assert prognosis.five_year_percentage() == pytest.approx(60.0)
    assert prognosis.median_survival_months is not None
    assert prognosis.uncertainty is None


# Check that an unknown patient index is rejected.
def test_create_patient_prognosis_rejects_unknown_patient() -> None:
    with pytest.raises(
        KeyError,
        match="Patient index not found",
    ):
        create_patient_prognosis(
            make_prediction(),
            patient_index="unknown",
        )


# ---------------------------------------------------------------------------
# Test Ensemble Prediction
# ---------------------------------------------------------------------------

# Create the ensemble survival prediction used by the uncertainty tests.
def make_ensemble_prediction() -> SurvivalPrediction:
    index = [
        "patient_1",
        "patient_2",
        "patient_3",
    ]

    curve = pd.DataFrame(
        {
            12.0: [0.95, 0.85, 0.75],
            36.0: [0.80, 0.65, 0.50],
            60.0: [0.60, 0.45, 0.30],
        },
        index=index,
    )

    lower = pd.DataFrame(
        {
            12.0: [0.94, 0.82, 0.69],
            36.0: [0.78, 0.60, 0.42],
            60.0: [0.57, 0.38, 0.20],
        },
        index=index,
    )

    upper = pd.DataFrame(
        {
            12.0: [0.96, 0.88, 0.81],
            36.0: [0.82, 0.70, 0.58],
            60.0: [0.63, 0.52, 0.40],
        },
        index=index,
    )

    return SurvivalPrediction(
        one_year_survival=curve[12.0],
        three_year_survival=curve[36.0],
        five_year_survival=curve[60.0],
        survival_curve=curve,
        risk_score=pd.Series(
            [0.1, 0.4, 0.8],
            index=index,
        ),
        uncertainty=pd.Series(
            [0.01, 0.03, 0.08],
            index=index,
        ),
        lower_confidence=lower,
        upper_confidence=upper,
        model_name="Test Ensemble",
        prediction_times=[
            12.0,
            36.0,
            60.0,
        ],
    )


# ---------------------------------------------------------------------------
# Uncertainty Threshold Tests
# ---------------------------------------------------------------------------

# Check the uncertainty thresholds calculated from the ensemble prediction.
def test_calculate_uncertainty_thresholds() -> None:
    thresholds = calculate_uncertainty_thresholds(
        make_ensemble_prediction()
    )

    assert isinstance(
        thresholds,
        UncertaintyThresholds,
    )

    assert (
        thresholds.lower_threshold
        <= thresholds.higher_threshold
    )


# ---------------------------------------------------------------------------
# Model Disagreement Tests
# ---------------------------------------------------------------------------

# Check model disagreement classification against the thresholds.
def test_classify_model_disagreement() -> None:
    thresholds = UncertaintyThresholds(
        lower_threshold=0.02,
        higher_threshold=0.05,
    )

    assert classify_model_disagreement(
        0.01,
        thresholds,
    ) == "Lower model disagreement"

    assert classify_model_disagreement(
        0.03,
        thresholds,
    ) == "Moderate model disagreement"

    assert classify_model_disagreement(
        0.08,
        thresholds,
    ) == "Higher model disagreement"


# ---------------------------------------------------------------------------
# Horizon Uncertainty Tests
# ---------------------------------------------------------------------------

# Check the uncertainty extracted at a prediction horizon.
def test_extract_horizon_uncertainty() -> None:
    uncertainty = extract_horizon_uncertainty(
        prediction=make_ensemble_prediction(),
        patient_index="patient_2",
        time=36.0,
    )

    assert uncertainty == pytest.approx(
        0.05
    )


# ---------------------------------------------------------------------------
# Ensemble Patient Prognosis Tests
# ---------------------------------------------------------------------------

# Check the patient prognosis created from an ensemble prediction.
def test_create_ensemble_patient_prognosis() -> None:
    prediction = make_ensemble_prediction()

    thresholds = calculate_uncertainty_thresholds(
        prediction
    )

    prognosis = create_patient_prognosis(
        prediction=prediction,
        patient_index="patient_3",
        uncertainty_thresholds=thresholds,
    )

    assert prognosis.uncertainty == pytest.approx(
        0.08
    )

    assert (
        prognosis.model_disagreement_label
        == "Higher model disagreement"
    )

    assert prognosis.one_year_uncertainty == pytest.approx(
        0.06
    )

    assert prognosis.three_year_uncertainty == pytest.approx(
        0.08
    )

    assert prognosis.five_year_uncertainty == pytest.approx(
        0.10
    )

    assert prognosis.uncertainty_explanation is not None