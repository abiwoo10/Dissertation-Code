import pandas as pd
import pytest
from lifelines import KaplanMeierFitter

from ml.kaplan_meier import (
    KaplanMeierSummary,
    fit_kaplan_meier,
    summarise_kaplan_meier,
)


# ---------------------------------------------------------------------------
# Kaplan-Meier Fitting Tests
# ---------------------------------------------------------------------------

# Check that the Kaplan-Meier estimator is fitted.
def test_fit_kaplan_meier() -> None:
    duration = pd.Series([6.0, 12.0, 18.0, 24.0])
    event = pd.Series([1, 0, 1, 0])

    estimator = fit_kaplan_meier(duration, event)

    assert isinstance(estimator, KaplanMeierFitter)
    assert estimator.survival_function_ is not None


# ---------------------------------------------------------------------------
# Kaplan-Meier Summary Tests
# ---------------------------------------------------------------------------

# Check the Kaplan-Meier summary values.
def test_summarise_kaplan_meier() -> None:
    duration = pd.Series([6.0, 12.0, 18.0, 24.0])
    event = pd.Series([1, 0, 1, 0])

    estimator = fit_kaplan_meier(duration, event)

    summary = summarise_kaplan_meier(
        estimator,
        duration,
        event,
        time_points=[6.0, 12.0, 18.0],
    )

    assert isinstance(summary, KaplanMeierSummary)
    assert summary.patient_count == 4
    assert summary.event_count == 2
    assert summary.censored_count == 2

    assert all(
        0.0 <= probability <= 1.0
        for probability in summary.survival_probabilities.values()
    )


# ---------------------------------------------------------------------------
# Kaplan-Meier Validation Tests
# ---------------------------------------------------------------------------

# Check that unsupported event values are rejected.
def test_fit_kaplan_meier_rejects_invalid_event() -> None:
    duration = pd.Series([6.0, 12.0])
    event = pd.Series([0, 2])

    with pytest.raises(
        ValueError,
        match="unsupported values",
    ):
        fit_kaplan_meier(duration, event)


# Check that missing values are rejected.
def test_fit_kaplan_meier_rejects_missing_values() -> None:
    duration = pd.Series([6.0, None])
    event = pd.Series([0, 1])

    with pytest.raises(
        ValueError,
        match="must not contain missing values",
    ):
        fit_kaplan_meier(duration, event)