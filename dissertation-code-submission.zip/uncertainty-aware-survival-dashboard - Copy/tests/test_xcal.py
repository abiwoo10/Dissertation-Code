import pytest
import torch

from ml.xcal import (
    censored_soft_membership,
    soft_membership,
    xcal_loss,
)


# ---------------------------------------------------------------------------
# Soft Membership Tests
# ---------------------------------------------------------------------------

# Check the shape and values of the soft membership output.
def test_soft_membership_shape() -> None:
    values = torch.tensor([0.1, 0.5, 0.9])

    result = soft_membership(
        values,
        lower_bound=0.0,
        upper_bound=0.2,
        gamma=100.0,
    )

    assert result.shape == values.shape
    assert torch.all(result >= 0.0)
    assert torch.all(result <= 1.0)


# Check the shape and values of the censored soft membership output.
def test_censored_soft_membership_shape() -> None:
    values = torch.tensor([0.2, 0.5, 0.8])

    result = censored_soft_membership(
        values,
        lower_bound=0.4,
        upper_bound=0.6,
        gamma=100.0,
    )

    assert result.shape == values.shape
    assert torch.all(result >= 0.0)
    assert torch.all(result <= 1.0)


# ---------------------------------------------------------------------------
# X-CAL Loss Tests
# ---------------------------------------------------------------------------

# Check that the X-CAL loss is finite and non-negative.
def test_xcal_loss_is_finite() -> None:
    cdf_values = torch.linspace(
        0.05,
        0.95,
        steps=20,
    )

    event = torch.ones(20)

    loss = xcal_loss(
        cdf_values,
        event,
        number_of_bins=10,
        gamma=100.0,
    )

    assert loss.ndim == 0
    assert torch.isfinite(loss)
    assert loss >= 0.0


# Check that uniform values produce a lower loss than concentrated values.
def test_uniform_values_have_lower_loss() -> None:
    uniform_values = torch.linspace(
        0.05,
        0.95,
        steps=100,
    )

    concentrated_values = torch.full(
        (100,),
        0.8,
    )

    event = torch.ones(100)

    uniform_loss = xcal_loss(
        uniform_values,
        event,
        gamma=100.0,
    )

    concentrated_loss = xcal_loss(
        concentrated_values,
        event,
        gamma=100.0,
    )

    assert uniform_loss < concentrated_loss


# Check the X-CAL loss with censored observations.
def test_xcal_loss_supports_censoring() -> None:
    cdf_values = torch.tensor(
        [0.2, 0.4, 0.6, 0.8]
    )

    event = torch.tensor(
        [1.0, 0.0, 1.0, 0.0]
    )

    loss = xcal_loss(
        cdf_values,
        event,
        gamma=100.0,
    )

    assert torch.isfinite(loss)
    assert loss >= 0.0


# Check that the X-CAL loss supports gradients.
def test_xcal_loss_supports_gradients() -> None:
    values = torch.tensor(
        [0.15, 0.35, 0.55, 0.75],
        requires_grad=True,
    )

    event = torch.tensor(
        [1.0, 0.0, 1.0, 0.0]
    )

    loss = xcal_loss(
        values,
        event,
        gamma=100.0,
    )

    loss.backward()

    assert values.grad is not None
    assert torch.isfinite(values.grad).all()


# Check that X-CAL loss inputs with different shapes are rejected.
def test_xcal_loss_rejects_shape_mismatch() -> None:
    with pytest.raises(
        ValueError,
        match="same shape",
    ):
        xcal_loss(
            cdf_at_observed_time=torch.tensor(
                [0.2, 0.5]
            ),
            event=torch.tensor([1.0]),
        )