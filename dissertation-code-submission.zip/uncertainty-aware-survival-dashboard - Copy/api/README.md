main.py/
Configures the FastAPI application, CORS settings, and API endpoints for 
health checks and patient survival predictions.

prediction_service.py/
Loads the trained ensemble model, preprocessing pipeline, and uncertainty 
thresholds to generate patient-specific survival predictions and model 
disagreement estimates.

schemas.py/
Defines the Pydantic schemas used to validate patient inputs and structure 
prognosis responses returned by the API.