from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field


# ----------------------
# Patient Input Schema
# ----------------------

# Define the patient features accepted by the prognosis API.
class PatientFeatures(BaseModel):

    # ----------------------------
    # Numerical Clinical Features
    # ----------------------------

    age_at_diagnosis: float = Field(
        ge=18.0,
        le=120.0,
    )

    lymph_nodes_examined_positive: float = Field(
        ge=0.0,
    )

    grade: float = Field(
        ge=1.0,
        le=3.0,
    )

    tumor_size: float = Field(
        gt=0.0,
    )

    tumor_stage: float = Field(
        ge=0.0,
        le=4.0,
    )

    tmb_nonsynonymous: float = Field(
        ge=0.0,
    )

    # ------------------------------
    # Categorical Clinical Features
    # ------------------------------

    cellularity: Literal[
        "Low",
        "Moderate",
        "High",
    ]

    er_status: Literal[
        "Negative",
        "Positive",
    ]

    her2_status: Literal[
        "Negative",
        "Positive",
    ]

    pr_status: Literal[
        "Negative",
        "Positive",
    ]

    inferred_menopausal_state: Literal[
        "Pre",
        "Post",
    ]

    histological_subtype: str
    integrative_cluster: str


# -------------------------
# Survival Summary Models
# -------------------------

# Store a survival estimate and model disagreement.
class HorizonEstimate(BaseModel):
    probability: float = Field(
        ge=0.0,
        le=1.0,
    )

    percentage: float = Field(
        ge=0.0,
        le=100.0,
    )

    # Store the optional model disagreement.
    model_disagreement: float | None = Field(
        default=None,
        ge=0.0,
    )


# Store a point on the predicted survival curve.
class SurvivalCurvePoint(BaseModel):
    months: float = Field(
        ge=0.0,
    )

    survival_probability: float = Field(
        ge=0.0,
        le=1.0,
    )

    # Store the lower and upper disagreement bounds.
    lower_disagreement_bound: float | None = Field(
        default=None,
        ge=0.0,
        le=1.0,
    )

    upper_disagreement_bound: float | None = Field(
        default=None,
        ge=0.0,
        le=1.0,
    )


# --------------------------
# API Response Schema
# --------------------------

# Define the prognosis response returned by the API.
class PrognosisResponse(BaseModel):
    model_name: str

    # Store the survival estimates at each prognosis horizon.
    one_year: HorizonEstimate
    three_year: HorizonEstimate
    five_year: HorizonEstimate

    # Store the estimated median survival.
    median_survival_months: float | None
    median_survival_years: float | None

    # Store the overall model disagreement.
    overall_model_disagreement: float | None
    model_disagreement_label: str | None

    # Store the predicted survival curve.
    survival_curve: list[SurvivalCurvePoint]

    # Store the prognosis explanations.
    patient_explanation: str
    uncertainty_explanation: str | None

    # Store the prediction limitations.
    limitations: list[str]