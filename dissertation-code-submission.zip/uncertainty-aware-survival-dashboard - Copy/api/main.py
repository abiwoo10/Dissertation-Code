from __future__ import annotations

from contextlib import asynccontextmanager

from fastapi import FastAPI, HTTPException, Request

from api.prediction_service import PredictionService
from api.schemas import PatientFeatures, PrognosisResponse

from fastapi.middleware.cors import CORSMiddleware


# --------------------------
# Application Installation
# --------------------------

# Create the prediction service when the API starts.
@asynccontextmanager
async def lifespan(app: FastAPI):
    app.state.prediction_service = PredictionService()
    yield


# Configure the FastAPI application.
app = FastAPI(
    title="Uncertainty-Aware Survival Prediction API",
    version="1.0.0",
    description=(
        "Research prototype for patient-specific breast cancer "
        "survival prediction with model-disagreement estimates."
    ),
    lifespan=lifespan,
)


# ------------------------------
# Cross-Origin Resource Sharing
# ------------------------------

# Allow the local React frontend to communicate with the API.
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5173",
        "http://127.0.0.1:5173",
        "http://localhost:4173",
        "http://127.0.0.1:4173",
    ],
    allow_credentials=True,
    allow_methods=["GET", "POST"],
    allow_headers=["Content-Type", "Accept",],
)


# ---------------
# API Endpoints
# ---------------

# Confirm that the API is running.
@app.get("/")
def root() -> dict[str, str]:
    return {
        "message": "Breast cancer survival prediction API",
    }


# Check that the prediction service started successfully.
@app.get("/health")
def health(request: Request) -> dict[str, object]:
    service_loaded = hasattr(
        request.app.state,
        "prediction_service",
    )

    return {
        "status": (
            "healthy"
            if service_loaded
            else "unavailable"
        ),
        "model_loaded": service_loaded,
    }


# Retrieve the shared prediction service.
@app.post(
    "/predict",
    response_model=PrognosisResponse,
)
def predict(
    patient: PatientFeatures,
    request: Request,
) -> PrognosisResponse:
    service = getattr(
        request.app.state,
        "prediction_service",
        None,
    )

    # Return a service unavailable response if the service is not loaded.
    if service is None:
        raise HTTPException(
            status_code=503,
            detail="Prediction service is unavailable.",
        )

    # Generate the patient survival prediction.
    try:
        return service.predict(
            patient
        )

    # Return validation errors as HTTP 422 responses.
    except (
        ValueError,
        KeyError,
    ) as error:
        raise HTTPException(
            status_code=422,
            detail=str(error),
        ) from error