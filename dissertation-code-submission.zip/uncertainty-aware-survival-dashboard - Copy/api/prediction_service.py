from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd

from api.schemas import (
    HorizonEstimate,
    PatientFeatures,
    PrognosisResponse,
    SurvivalCurvePoint,
)
from ml.ensemble_model import MTLREnsembleModel
from ml.preprocessing import (
    load_feature_transformer,
    transform_raw_features,
)
from ml.feature_config import EXTENDED_FEATURES

from ml.prognosis import (
    UncertaintyThresholds,
    create_patient_prognosis,
)


# ---------------------------------------------------------------------------
# Paths and Prediction Configuration
# ---------------------------------------------------------------------------

# Set the project root.
PROJECT_ROOT = Path(__file__).resolve().parents[1]

# Set the trained ensemble path.
DEFAULT_ENSEMBLE_PATH = (
    PROJECT_ROOT
    / "models"
    / "trained"
    / "mtlr_xcal_ensemble.pkl"
)

# Set the preprocessing pipeline path.
DEFAULT_TRANSFORMER_PATH = (
    PROJECT_ROOT
    / "models"
    / "trained"
    / "extended_preprocessor.joblib"
)

# Set the uncertainty threshold path.
DEFAULT_THRESHOLDS_PATH = (
    PROJECT_ROOT
    / "models"
    / "metadata"
    / "ensemble_uncertainty_thresholds.json"
)

# Set the survival prediction times.
PREDICTION_TIMES = np.arange(
    6.0,
    241.0,
    6.0,
).tolist()


# -----------------
# Feature Mapping
# -----------------

# Map the API feature names to the METABRIC feature names.
RAW_FEATURE_MAPPING = {
    "age_at_diagnosis": "AGE_AT_DIAGNOSIS",
    "cellularity": "CELLULARITY",
    "lymph_nodes_examined_positive": (
        "LYMPH_NODES_EXAMINED_POSITIVE"
    ),
    "er_status": "ER_STATUS",
    "her2_status": "HER2_STATUS",
    "pr_status": "PR_STATUS",
    "grade": "GRADE",
    "tumor_size": "TUMOR_SIZE",
    "tumor_stage": "TUMOR_STAGE",
    "inferred_menopausal_state": (
        "INFERRED_MENOPAUSAL_STATE"
    ),
    "histological_subtype": "HISTOLOGICAL_SUBTYPE",
    "integrative_cluster": "INTCLUST",
    "tmb_nonsynonymous": "TMB_NONSYNONYMOUS",
}


# Convert the patient features to the raw METABRIC dataframe.
def patient_features_to_dataframe(
    patient: PatientFeatures,
) -> pd.DataFrame:
    values = patient.model_dump()

    # Rename the API features to the METABRIC feature names.
    raw_values = {
        raw_name: values[api_name]
        for api_name, raw_name
        in RAW_FEATURE_MAPPING.items()
    }

    # Create the patient dataframe.
    frame = pd.DataFrame(
        [raw_values],
        columns=EXTENDED_FEATURES,
        index=["patient"],
    )

    # Check that the feature order matches the training feature order.
    if frame.columns.tolist() != EXTENDED_FEATURES:
        raise RuntimeError(
            "Raw API feature order does not match EXTENDED_FEATURES."
        )

    return frame


# ---------------------------------------------------------------------------
# Uncertainty Thresholds
# ---------------------------------------------------------------------------

# Load the model disagreement thresholds.
def load_uncertainty_thresholds(
    path: Path,
) -> UncertaintyThresholds:
    # Check that the threshold file exists.
    if not path.exists():
        raise FileNotFoundError(
            f"Uncertainty thresholds not found: {path}"
        )

    # Load the uncertainty thresholds.
    with path.open(
        "r",
        encoding="utf-8",
    ) as input_file:
        metadata = json.load(input_file)

    # Extract the threshold values.
    try:
        lower_threshold = float(
            metadata["lower_threshold"]
        )
        higher_threshold = float(
            metadata["higher_threshold"]
        )
    except (
        KeyError,
        TypeError,
        ValueError,
    ) as error:
        raise ValueError(
            "Uncertainty-threshold metadata is invalid."
        ) from error

    # Create the uncertainty threshold object.
    return UncertaintyThresholds(
        lower_threshold=lower_threshold,
        higher_threshold=higher_threshold,
    )


# --------------------
# Prediction Service
# --------------------

# Provide patient prognosis predictions.
class PredictionService:
    def __init__(
        self,
        ensemble_path: Path = DEFAULT_ENSEMBLE_PATH,
        transformer_path: Path = DEFAULT_TRANSFORMER_PATH,
        thresholds_path: Path = DEFAULT_THRESHOLDS_PATH,
    ) -> None:
        # Load the trained ensemble model.
        self.ensemble = MTLREnsembleModel.load(
            ensemble_path
        )

        # Load the preprocessing pipeline.
        self.transformer = load_feature_transformer(
            transformer_path
        )

        # Load the model disagreement thresholds.
        self.uncertainty_thresholds = (
            load_uncertainty_thresholds(
                thresholds_path
            )
        )

        transformer_feature_names = (
            self.transformer
            .get_feature_names_out()
            .tolist()
        )

        # Check that the transformer and ensemble feature schemas match.
        if (
            transformer_feature_names
            != self.ensemble.feature_names
        ):
            raise ValueError(
                "Transformer feature schema does not match "
                "the ensemble feature schema."
            )

    # Generate the patient prognosis response.
    def predict(
        self,
        patient: PatientFeatures,
    ) -> PrognosisResponse:
        # Convert the patient input to the raw feature dataframe.
        raw_features = patient_features_to_dataframe(
            patient
        )

        # Transform the patient features.
        transformed_features = transform_raw_features(
            X=raw_features,
            transformer=self.transformer,
        )

        # Generate the ensemble survival prediction.
        prediction = self.ensemble.predict_survival(
            X=transformed_features,
            time_points=PREDICTION_TIMES,
        )

        patient_index = transformed_features.index[0]

        # Create the patient prognosis.
        prognosis = create_patient_prognosis(
            prediction=prediction,
            patient_index=patient_index,
            uncertainty_thresholds=(
                self.uncertainty_thresholds
            ),
        )

        # Create the prognosis API response.
        return PrognosisResponse(
            model_name=prognosis.model_name,
            one_year=HorizonEstimate(
                probability=prognosis.one_year_survival,
                percentage=prognosis.one_year_percentage(),
                model_disagreement=(
                    prognosis.one_year_uncertainty
                ),
            ),
            three_year=HorizonEstimate(
                probability=prognosis.three_year_survival,
                percentage=prognosis.three_year_percentage(),
                model_disagreement=(
                    prognosis.three_year_uncertainty
                ),
            ),
            five_year=HorizonEstimate(
                probability=prognosis.five_year_survival,
                percentage=prognosis.five_year_percentage(),
                model_disagreement=(
                    prognosis.five_year_uncertainty
                ),
            ),
            median_survival_months=(
                prognosis.median_survival_months
            ),
            median_survival_years=(
                prognosis.median_survival_years()
            ),
            overall_model_disagreement=(
                prognosis.uncertainty
            ),
            model_disagreement_label=(
                prognosis.model_disagreement_label
            ),
            survival_curve=[
                SurvivalCurvePoint(
                    months=float(time),
                    survival_probability=float(probability),
                    lower_disagreement_bound=(
                        float(
                            prediction.lower_confidence.loc[
                                patient_index,
                                time,
                            ]
                        )
                        if prediction.lower_confidence is not None
                        else None
                    ),
                    upper_disagreement_bound=(
                        float(
                            prediction.upper_confidence.loc[
                                patient_index,
                                time,
                            ]
                        )
                        if prediction.upper_confidence is not None
                        else None
                    ),
                )
                for time, probability
                in prognosis.survival_curve.items()
            ],
            patient_explanation=prognosis.explanation,
            uncertainty_explanation=(
                prognosis.uncertainty_explanation
            ),
            limitations=[
                (
                    "This output is produced by a research prototype "
                    "and is not a clinical assessment."
                ),
                (
                    "Predicted survival probabilities are estimates, "
                    "not guarantees of individual outcomes."
                ),
                (
                    "Model disagreement measures variation between "
                    "ensemble members and is not a confidence interval."
                ),
                (
                    "The model has not undergone prospective or "
                    "external clinical validation."
                ),
            ],
        )