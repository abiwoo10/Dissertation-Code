cox_clinical.json/
Stores metadata and validation results for the trained clinical Cox 
proportional hazards model.

cox_extended.json/
Stores metadata and validation results for the trained extended Cox 
proportional hazards model.

ensemble_uncertainty_thresholds.json/
Stores the validation-derived lower and higher ensemble disagreement 
thresholds used to categorise patient-level uncertainty.

extended_preprocessor.json/
Stores metadata describing the raw and transformed features, dataset 
splits, and model compatibility of the extended preprocessing pipeline.

mtlr_clinical.json/
Stores the training configuration, training history, and validation results 
for the clinical MTLR model.

mtlr_extended.json/
Stores the training configuration, training history, and validation 
results for the extended MTLR model.

mtlr_extended_xcal.json/
Stores the training configuration, X-CAL settings, training history, and 
validation results for the X-CAL-regularised extended MTLR model.

mtlr_xcal_ensemble.json/
Stores the ensemble configuration and validation results for the five-member 
X-CAL MTLR ensemble, including discrimination, calibration, and 
patient-level disagreement results.