cox_clinical.pkl/
Stores the trained Cox proportional hazards model using the clinical 
feature set.

cox_extended.pkl/
Stores the trained Cox proportional hazards model using the extended 
feature set.

extended_preprocessor.joblib/
Stores the fitted preprocessing pipeline used to transform extended 
patient features into the format expected by the trained models.

mtlr_clinical.pkl/
Stores the trained MTLR model using the clinical feature set.

mtlr_extended.pkl/
Stores the trained MTLR model using the extended feature set.

mtlr_extended_xcal.pkl/
Stores the trained extended MTLR model with X-CAL regularisation.

mtlr_xcal_ensemble.pkl/
Stores the trained ensemble of X-CAL-regularised MTLR models used to 
generate survival predictions and model disagreement estimates.