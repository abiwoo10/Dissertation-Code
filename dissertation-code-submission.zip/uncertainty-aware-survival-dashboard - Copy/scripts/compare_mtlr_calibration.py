from __future__ import annotations

import json
from pathlib import Path

import numpy as np

from ml.evaluation import SurvivalModelEvaluator
from ml.calibration import (
    calculate_censoring_adjusted_d_calibration,
    calculate_uncensored_d_calibration,
)
from ml.mtlr_model import MTLRModel
from ml.preprocessing import (
    prepare_model_dataset,
    TransformedDatasetSplit,
)


# ---------------------------------------------------------------------------
# Project Paths
# ---------------------------------------------------------------------------

PROJECT_ROOT = Path(__file__).resolve().parents[1]

# Path used to save the MTLR calibration comparison report.
REPORT_PATH = (
    PROJECT_ROOT
    / "data"
    / "reports"
    / "mtlr_calibration_comparison.json"
)


# ---------------------------------------------------------------------------
# Model Configuration
# ---------------------------------------------------------------------------

# Paths to the uncalibrated and X-CAL MTLR models.
MODELS = {
    "uncalibrated": (
        PROJECT_ROOT
        / "models"
        / "trained"
        / "mtlr_extended.pkl"
    ),
    "xcal": (
        PROJECT_ROOT
        / "models"
        / "trained"
        / "mtlr_extended_xcal.pkl"
    ),
}

# Evaluation time points from 6 to 240 months.
EVALUATION_TIMES = np.arange(
    6.0,
    241.0,
    6.0,
)


# ---------------------------------------------------------------------------
# MTLR Model Evaluation
# ---------------------------------------------------------------------------

# Evaluate an MTLR model using the shared validation dataset.
def evaluate_model(
    model_name: str,
    model_path: Path,
    dataset: TransformedDatasetSplit,
) -> dict[str, object]:

    if not model_path.exists():
        raise FileNotFoundError(
            f"Trained MTLR model not found: {model_path}"
        )

    # Load the trained MTLR model.
    model = MTLRModel.load(model_path)

    # Generate survival predictions across the evaluation time points.
    prediction = model.predict_survival(
        X=dataset.X_validation,
        time_points=EVALUATION_TIMES.tolist(),
    )

    # Calculate the validation evaluation metrics.
    evaluation = SurvivalModelEvaluator().evaluate(
        prediction=prediction,
        duration=dataset.duration_validation,
        event=dataset.event_validation,
        evaluation_times=EVALUATION_TIMES,
    )

    # Calculate uncensored D-calibration.
    d_calibration = calculate_uncensored_d_calibration(
        prediction=prediction,
        duration=dataset.duration_validation,
        event=dataset.event_validation,
        number_of_bins=10,
    )

    # Calculate censoring-adjusted D-calibration.
    adjusted_d_calibration = (
        calculate_censoring_adjusted_d_calibration(
            prediction=prediction,
            duration=dataset.duration_validation,
            event=dataset.event_validation,
            number_of_bins=10,
        )
    )

    # Return the validation results for the model.
    return {
        "model_name": model_name,
        "calibration_weight": getattr(
            model,
            "calibration_weight",
            0.0,
        ),
        "validation_concordance_index": (
            evaluation.concordance_index
        ),
        "validation_integrated_brier_score": (
            evaluation.integrated_brier_score
        ),
        "uncensored_d_calibration": d_calibration,
        "adjusted_d_calibration": adjusted_d_calibration,
    }


# ---------------------------------------------------------------------------
# MTLR Calibration Comparison
# ---------------------------------------------------------------------------

# Compare the uncalibrated and X-CAL MTLR models.
def main() -> None:

    # Prepare the shared extended validation dataset.
    dataset = prepare_model_dataset(
        model_type="extended",
        test_size=0.20,
        validation_size=0.20,
        random_state=42,
    )

    # Evaluate each MTLR model on the validation dataset.
    results = {
        name: evaluate_model(
            model_name=name,
            model_path=model_path,
            dataset=dataset,
        )
        for name, model_path in MODELS.items()
    }

    uncalibrated = results["uncalibrated"]
    calibrated = results["xcal"]

    # Calculate the differences between the X-CAL and uncalibrated models.
    comparison = {
        "dataset_partition": "validation",
        "evaluation_times_months": (
            EVALUATION_TIMES.tolist()
        ),
        "models": results,
        "differences_xcal_minus_uncalibrated": {
            "concordance_index": (
                calibrated["validation_concordance_index"]
                - uncalibrated["validation_concordance_index"]
            ),
            "integrated_brier_score": (
                calibrated["validation_integrated_brier_score"]
                - uncalibrated["validation_integrated_brier_score"]
            ),
            "uncensored_d_calibration_chi_square": (
                calibrated[
                    "uncensored_d_calibration"
                ]["chi_square_statistic"]
                - uncalibrated[
                    "uncensored_d_calibration"
                ]["chi_square_statistic"]
            ),
            "adjusted_d_calibration_chi_square": (
                calibrated[
                    "adjusted_d_calibration"
                ]["chi_square_statistic"]
                - uncalibrated[
                    "adjusted_d_calibration"
                ]["chi_square_statistic"]
            ),
        },
    }

    # Create the report directory if required.
    REPORT_PATH.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    # Save the comparison report as JSON.
    with REPORT_PATH.open(
        "w",
        encoding="utf-8",
    ) as output_file:
        json.dump(
            comparison,
            output_file,
            indent=2,
        )

    # Print the validation results for each model.
    print("MTLR calibration comparison")
    print("-" * 48)

    for name, result in results.items():
        print(f"\n{name}")
        print(
            "  C-index: "
            f"{result['validation_concordance_index']:.3f}"
        )
        print(
            "  IBS: "
            f"{result['validation_integrated_brier_score']:.4f}"
        )
        print(
            "  Uncensored D-calibration chi-square: "
            f"{result['uncensored_d_calibration']['chi_square_statistic']:.3f}"
        )
        print(
            "  Adjusted D-calibration chi-square: "
            f"{result['adjusted_d_calibration']['chi_square_statistic']:.3f}"
        )
        print(
            "  Adjusted D-calibration p-value: "
            f"{result['adjusted_d_calibration']['p_value']:.4f}"
        )

    # Print the differences between the two models.
    print("\nDifferences: X-CAL minus uncalibrated")
    print(
        "  C-index: "
        f"{comparison['differences_xcal_minus_uncalibrated']['concordance_index']:+.3f}"
    )
    print(
        "  IBS: "
        f"{comparison['differences_xcal_minus_uncalibrated']['integrated_brier_score']:+.4f}"
    )
    print(
        "  Adjusted D-calibration chi-square: "
        f"{comparison['differences_xcal_minus_uncalibrated']['adjusted_d_calibration_chi_square']:+.3f}"
    )

    print(f"\nReport saved to: {REPORT_PATH}")


if __name__ == "__main__":
    main()