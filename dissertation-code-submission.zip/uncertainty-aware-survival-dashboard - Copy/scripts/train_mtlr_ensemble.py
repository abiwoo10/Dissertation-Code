from __future__ import annotations

import json
from pathlib import Path

import numpy as np

from ml.ensemble_model import MTLREnsembleModel
from ml.calibration import (
    calculate_censoring_adjusted_d_calibration,
    calculate_uncensored_d_calibration,
)
from ml.evaluation import SurvivalModelEvaluator
from ml.mtlr_model import MTLRModel
from ml.preprocessing import (
    TransformedDatasetSplit,
    prepare_model_dataset,
)


# ---------------------------------------------------------------------------
# Project Paths
# ---------------------------------------------------------------------------

PROJECT_ROOT = Path(__file__).resolve().parents[1]

# Path used to save the trained MTLR ensemble.
ENSEMBLE_PATH = (
    PROJECT_ROOT
    / "models"
    / "trained"
    / "mtlr_xcal_ensemble.pkl"
)

# Path used to save the MTLR ensemble metadata.
METADATA_PATH = (
    PROJECT_ROOT
    / "models"
    / "metadata"
    / "mtlr_xcal_ensemble.json"
)

# Directory used to save the individual ensemble members.
MEMBER_DIRECTORY = (
    PROJECT_ROOT
    / "models"
    / "trained"
    / "ensemble_members"
)


# ---------------------------------------------------------------------------
# Ensemble Configuration
# ---------------------------------------------------------------------------

# Random seeds used for the ensemble members.
MEMBER_SEEDS = [
    11,
    22,
    33,
    44,
    55,
]

# Evaluation time points from 6 to 240 months.
EVALUATION_TIMES = np.arange(
    6.0,
    241.0,
    6.0,
)

# MTLR training parameters.
NUMBER_OF_BINS = 20
LEARNING_RATE = 0.005
WEIGHT_DECAY = 0.001
CALIBRATION_WEIGHT = 2.0

MAX_EPOCHS = 1000
PATIENCE = 50
MINIMUM_IMPROVEMENT = 0.0001

# X-CAL parameters.
XCAL_BINS = 10
XCAL_GAMMA = 10_000.0


# ---------------------------------------------------------------------------
# Ensemble Member Training
# ---------------------------------------------------------------------------

# Train and save one ensemble member.
def train_member(
    dataset: TransformedDatasetSplit,
    seed: int,
    member_number: int,
) -> MTLRModel:

    print(
        f"\nTraining ensemble member "
        f"{member_number}/{len(MEMBER_SEEDS)} "
        f"with seed {seed}..."
    )

    # Create the MTLR model for the ensemble member.
    model = MTLRModel(
        number_of_bins=NUMBER_OF_BINS,
        learning_rate=LEARNING_RATE,
        epochs=MAX_EPOCHS,
        weight_decay=WEIGHT_DECAY,
        random_state=seed,
        patience=PATIENCE,
        minimum_improvement=MINIMUM_IMPROVEMENT,
        calibration_weight=CALIBRATION_WEIGHT,
        xcal_bins=XCAL_BINS,
        xcal_gamma=XCAL_GAMMA,
    )

    # Fit the model using the training and validation datasets.
    model.fit(
        X=dataset.X_train,
        duration=dataset.duration_train,
        event=dataset.event_train,
        X_validation=dataset.X_validation,
        duration_validation=dataset.duration_validation,
        event_validation=dataset.event_validation,
    )

    # Create the ensemble member directory if required.
    MEMBER_DIRECTORY.mkdir(
        parents=True,
        exist_ok=True,
    )

    # Create the path for the trained ensemble member.
    member_path = (
        MEMBER_DIRECTORY
        / f"mtlr_xcal_member_{member_number}.pkl"
    )

    # Save the trained ensemble member.
    model.save(member_path)

    # Print the ensemble member training summary.
    print(f"  Best epoch: {model.best_epoch}")
    print(f"  Stopped early: {model.stopped_early}")
    print(
        "  Best validation loss: "
        f"{min(model.validation_losses):.4f}"
    )
    print(f"  Saved to: {member_path}")

    return model


# ---------------------------------------------------------------------------
# MTLR Ensemble Training
# ---------------------------------------------------------------------------

# Train, evaluate, and save the MTLR X-CAL ensemble.
def main() -> None:

    # Prepare the extended model dataset.
    dataset = prepare_model_dataset(
        model_type="extended",
        test_size=0.20,
        validation_size=0.20,
        random_state=42,
    )

    # Train each ensemble member.
    members = [
        train_member(
            dataset=dataset,
            seed=seed,
            member_number=member_number,
        )
        for member_number, seed in enumerate(
            MEMBER_SEEDS,
            start=1,
        )
    ]

    # Create the MTLR ensemble from the trained members.
    ensemble = MTLREnsembleModel(
        members
    )

    # Generate ensemble predictions for the validation dataset.
    prediction = ensemble.predict_survival(
        X=dataset.X_validation,
        time_points=EVALUATION_TIMES.tolist(),
    )

    # Evaluate the ensemble validation predictions.
    evaluation = SurvivalModelEvaluator().evaluate(
        prediction=prediction,
        duration=dataset.duration_validation,
        event=dataset.event_validation,
        evaluation_times=EVALUATION_TIMES,
    )

    # Calculate uncensored D-calibration.
    d_calibration = calculate_uncensored_d_calibration(
        prediction=prediction,
        duration=dataset.duration_validation,
        event=dataset.event_validation,
        number_of_bins=10,
    )

    # Calculate censoring-adjusted D-calibration.
    adjusted_d_calibration = (
        calculate_censoring_adjusted_d_calibration(
            prediction=prediction,
            duration=dataset.duration_validation,
            event=dataset.event_validation,
            number_of_bins=10,
        )
    )

    # Save the trained MTLR ensemble.
    ensemble.save(ENSEMBLE_PATH)

    # Create the metadata directory if required.
    METADATA_PATH.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    # Create the MTLR ensemble metadata.
    metadata = {
        "model_name": prediction.model_name,
        "model_type": "extended_mtlr_xcal_ensemble",
        "member_count": len(members),
        "member_seeds": MEMBER_SEEDS,
        "training_rows": len(dataset.X_train),
        "validation_rows": len(dataset.X_validation),
        "test_rows": len(dataset.X_test),
        "transformed_feature_count": dataset.X_train.shape[1],
        "number_of_bins": NUMBER_OF_BINS,
        "learning_rate": LEARNING_RATE,
        "weight_decay": WEIGHT_DECAY,
        "calibration_weight": CALIBRATION_WEIGHT,
        "maximum_epochs": MAX_EPOCHS,
        "patience": PATIENCE,
        "minimum_improvement": MINIMUM_IMPROVEMENT,
        "xcal_bins": XCAL_BINS,
        "xcal_gamma": XCAL_GAMMA,
        "evaluation_times_months": (
            EVALUATION_TIMES.tolist()
        ),
        "validation_concordance_index": (
            evaluation.concordance_index
        ),
        "validation_integrated_brier_score": (
            evaluation.integrated_brier_score
        ),
        "uncensored_d_calibration": d_calibration,
        "adjusted_d_calibration": adjusted_d_calibration,
        "mean_patient_uncertainty": float(
            prediction.uncertainty.mean()
        ),
        "median_patient_uncertainty": float(
            prediction.uncertainty.median()
        ),
        "maximum_patient_uncertainty": float(
            prediction.uncertainty.max()
        ),
        "member_best_epochs": [
            member.best_epoch
            for member in members
        ],
    }

    # Save the ensemble metadata as JSON.
    with METADATA_PATH.open(
        "w",
        encoding="utf-8",
    ) as output_file:
        json.dump(
            metadata,
            output_file,
            indent=2,
        )

    # Print the ensemble training and validation summary.
    print("\nMTLR X-CAL ensemble trained successfully.")
    print("-" * 48)
    print(f"Members: {len(members)}")
    print(
        "Validation C-index: "
        f"{evaluation.concordance_index:.3f}"
    )
    print(
        "Validation IBS: "
        f"{evaluation.integrated_brier_score:.4f}"
    )
    print(
        "Adjusted D-calibration chi-square: "
        f"{adjusted_d_calibration['chi_square_statistic']:.3f}"
    )
    print(
        "Adjusted D-calibration p-value: "
        f"{adjusted_d_calibration['p_value']:.4f}"
    )
    print(
        "Mean patient uncertainty: "
        f"{prediction.uncertainty.mean():.4f}"
    )
    print(
        "Median patient uncertainty: "
        f"{prediction.uncertainty.median():.4f}"
    )
    print(
        "Maximum patient uncertainty: "
        f"{prediction.uncertainty.max():.4f}"
    )
    print(f"Ensemble saved to: {ENSEMBLE_PATH}")
    print(f"Metadata saved to: {METADATA_PATH}")


if __name__ == "__main__":
    main()