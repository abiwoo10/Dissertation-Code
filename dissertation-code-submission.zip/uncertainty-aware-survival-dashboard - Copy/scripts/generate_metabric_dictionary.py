from __future__ import annotations

import argparse
import io
import json
import tarfile
from pathlib import Path
from typing import Any

import pandas as pd


# ---------------------------------------------------------------------------
# Project Paths
# ---------------------------------------------------------------------------

PROJECT_ROOT = Path(__file__).resolve().parents[1]

# Default path to the METABRIC archive.
DEFAULT_ARCHIVE = (
    PROJECT_ROOT
    / "data"
    / "raw"
    / "brca_metabric.tar.gz"
)

# Default path used to save the generated data dictionary.
DEFAULT_OUTPUT = (
    PROJECT_ROOT
    / "data"
    / "reports"
    / "metabric_data_dictionary.csv"
)


# ---------------------------------------------------------------------------
# Clinical Table Files
# ---------------------------------------------------------------------------

# Clinical patient and sample filenames within the archive.
CLINICAL_PATIENT_FILENAME = "data_clinical_patient.txt"
CLINICAL_SAMPLE_FILENAME = "data_clinical_sample.txt"


# ---------------------------------------------------------------------------
# Archive Reading
# ---------------------------------------------------------------------------

# Locate a file inside the archive by its filename.
def find_archive_member(
    archive: tarfile.TarFile,
    expected_filename: str,
) -> tarfile.TarInfo:

    # Find archive members matching the expected filename.
    matches = [
        member
        for member in archive.getmembers()
        if member.isfile()
        and Path(member.name).name.lower() == expected_filename.lower()
    ]

    if not matches:
        raise FileNotFoundError(
            f"Could not find {expected_filename!r} inside the archive."
        )

    if len(matches) > 1:
        locations = [member.name for member in matches]
        raise ValueError(
            f"Multiple files named {expected_filename!r} were found: "
            f"{locations}"
        )

    return matches[0]


# Read a tab-separated cBioPortal clinical table from the archive.
def read_cbioportal_table(
    archive: tarfile.TarFile,
    filename: str,
) -> pd.DataFrame:

    # Locate and extract the requested clinical table.
    member = find_archive_member(archive, filename)
    extracted_file = archive.extractfile(member)

    if extracted_file is None:
        raise OSError(f"Unable to read {member.name!r} from the archive.")

    # Decode the extracted table text.
    text = extracted_file.read().decode("utf-8-sig")

    # Read the table into a DataFrame.
    return pd.read_csv(
        io.StringIO(text),
        sep="\t",
        comment="#",
        low_memory=False,
    )


# ---------------------------------------------------------------------------
# Example Values
# ---------------------------------------------------------------------------

# Serialise representative non-missing values as JSON.
def serialise_example_values(
    series: pd.Series,
    maximum_values: int = 10,
) -> str:

    # Select the first unique non-missing values.
    values = (
        series.dropna()
        .astype(str)
        .drop_duplicates()
        .head(maximum_values)
        .tolist()
    )

    return json.dumps(values, ensure_ascii=False)


# ---------------------------------------------------------------------------
# Column Classification
# ---------------------------------------------------------------------------

# Classify a column using its data type and number of unique values.
def classify_column(series: pd.Series) -> str:

    # Get the non-missing values and unique value count.
    non_missing = series.dropna()
    unique_count = non_missing.nunique()

    if pd.api.types.is_numeric_dtype(series):
        if unique_count <= 10:
            return "numeric_discrete"
        return "numeric_continuous"

    if unique_count <= 20:
        return "categorical"

    return "text_or_identifier"


# ---------------------------------------------------------------------------
# Table Dictionary
# ---------------------------------------------------------------------------

# Generate a data dictionary for a DataFrame.
def build_table_dictionary(
    dataframe: pd.DataFrame,
    source_table: str,
) -> pd.DataFrame:

    # Get the table row count and initialise the column records.
    row_count = len(dataframe)
    records: list[dict[str, Any]] = []

    # Generate a dictionary record for each column.
    for column in dataframe.columns:
        series = dataframe[column]
        non_missing_count = int(series.notna().sum())
        missing_count = int(series.isna().sum())
        unique_count = int(series.nunique(dropna=True))

        # Calculate the percentage of missing values.
        missing_percent = (
            round((missing_count / row_count) * 100, 2)
            if row_count
            else 0.0
        )

        # Create the column dictionary record.
        record: dict[str, Any] = {
            "source_table": source_table,
            "column": column,
            "pandas_dtype": str(series.dtype),
            "column_class": classify_column(series),
            "row_count": row_count,
            "non_missing_count": non_missing_count,
            "missing_count": missing_count,
            "missing_percent": missing_percent,
            "unique_count": unique_count,
            "example_values": serialise_example_values(series),
        }

        # Add summary statistics for numeric columns.
        if pd.api.types.is_numeric_dtype(series):
            numeric = pd.to_numeric(series, errors="coerce")

            record.update(
                {
                    "minimum": numeric.min(),
                    "median": numeric.median(),
                    "maximum": numeric.max(),
                }
            )
        else:
            record.update(
                {
                    "minimum": None,
                    "median": None,
                    "maximum": None,
                }
            )

        records.append(record)

    return pd.DataFrame(records)


# ---------------------------------------------------------------------------
# METABRIC Data Dictionary
# ---------------------------------------------------------------------------

# Generate and save the METABRIC clinical data dictionary.
def generate_data_dictionary(
    archive_path: Path,
    output_path: Path,
) -> pd.DataFrame:

    # Resolve the archive and output paths.
    archive_path = archive_path.resolve()
    output_path = output_path.resolve()

    if not archive_path.exists():
        raise FileNotFoundError(f"Archive not found: {archive_path}")

    if not archive_path.is_file():
        raise ValueError(f"Archive path is not a file: {archive_path}")

    # Read the patient and sample clinical tables from the archive.
    with tarfile.open(archive_path, mode="r:*") as archive:
        patient_df = read_cbioportal_table(
            archive,
            CLINICAL_PATIENT_FILENAME,
        )
        sample_df = read_cbioportal_table(
            archive,
            CLINICAL_SAMPLE_FILENAME,
        )

    # Generate a data dictionary for each clinical table.
    patient_dictionary = build_table_dictionary(
        patient_df,
        source_table="clinical_patient",
    )

    sample_dictionary = build_table_dictionary(
        sample_df,
        source_table="clinical_sample",
    )

    # Combine the patient and sample data dictionaries.
    dictionary = pd.concat(
        [patient_dictionary, sample_dictionary],
        ignore_index=True,
    )

    # Sort the data dictionary by source table and column.
    dictionary = dictionary.sort_values(
        ["source_table", "column"]
    ).reset_index(drop=True)

    # Create the output directory and save the data dictionary.
    output_path.parent.mkdir(parents=True, exist_ok=True)
    dictionary.to_csv(output_path, index=False)

    return dictionary


# ---------------------------------------------------------------------------
# Command-Line Interface
# ---------------------------------------------------------------------------

# Parse the command-line arguments.
def parse_arguments() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Generate a METABRIC clinical data dictionary."
    )

    # Add the archive path argument.
    parser.add_argument(
        "--archive",
        type=Path,
        default=DEFAULT_ARCHIVE,
        help="Path to the METABRIC tar or tar.gz archive.",
    )

    # Add the output path argument.
    parser.add_argument(
        "--output",
        type=Path,
        default=DEFAULT_OUTPUT,
        help="Path for the generated CSV data dictionary.",
    )

    return parser.parse_args()


# ---------------------------------------------------------------------------
# Script Entry Point
# ---------------------------------------------------------------------------

# Generate the data dictionary using the command-line arguments.
def main() -> None:
    args = parse_arguments()

    # Generate and save the METABRIC data dictionary.
    dictionary = generate_data_dictionary(
        archive_path=args.archive,
        output_path=args.output,
    )

    # Print the generated dictionary summary.
    print(
        f"Generated data dictionary with "
        f"{len(dictionary)} column records."
    )
    print(f"Saved to: {args.output.resolve()}")


if __name__ == "__main__":
    main()