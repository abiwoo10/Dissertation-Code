from __future__ import annotations

import json
from pathlib import Path

from ml.cox_model import CoxModel
from ml.evaluation import SurvivalModelEvaluator
from ml.preprocessing import prepare_model_dataset

# ---------------------------------------------------------------------------
# Project Paths
# ---------------------------------------------------------------------------

PROJECT_ROOT = Path(__file__).resolve().parents[1]

# Path used to save the Cox model comparison report.
REPORT_PATH = (
        PROJECT_ROOT
        / "data"
        / "reports"
        / "cox_model_comparison.json"
)


# ---------------------------------------------------------------------------
# Cox Model Evaluation
# ---------------------------------------------------------------------------

# Evaluate a trained Cox model using the validation dataset.
def evaluate_model(
        model_type: str,
        model_filename: str,
) -> dict[str, object]:
    # Prepare the dataset for the selected model type.
    dataset = prepare_model_dataset(
        model_type=model_type,
        test_size=0.20,
        validation_size=0.20,
        random_state=42,
    )

    # Build the path to the trained model.
    model_path = (
            PROJECT_ROOT
            / "models"
            / "trained"
            / model_filename
    )

    if not model_path.exists():
        raise FileNotFoundError(
            f"Trained model not found: {model_path}"
        )

    # Load the trained Cox model.
    model = CoxModel.load(model_path)

    # Generate survival predictions for the validation dataset.
    prediction = model.predict_survival(
        X=dataset.X_validation,
        time_points=[12.0, 36.0, 60.0],
    )

    evaluator = SurvivalModelEvaluator()

    # Evaluate the validation predictions.
    result = evaluator.evaluate(
        prediction=prediction,
        duration=dataset.duration_validation,
        event=dataset.event_validation,
    )

    # Return the validation results for the model.
    return {
        "model_type": model_type,
        "validation_rows": result.prediction_count,
        "concordance_index": result.concordance_index,
        "transformed_feature_count": dataset.X_validation.shape[1],
    }


# ---------------------------------------------------------------------------
# Cox Model Comparison
# ---------------------------------------------------------------------------

# Compare the clinical and extended Cox models.
def main() -> None:
    # Evaluate the clinical Cox model.
    clinical_result = evaluate_model(
        model_type="clinical",
        model_filename="cox_clinical.pkl",
    )

    # Evaluate the extended Cox model.
    extended_result = evaluate_model(
        model_type="extended",
        model_filename="cox_extended.pkl",
    )

    # Create the comparison between both validation results.
    comparison = {
        "clinical": clinical_result,
        "extended": extended_result,
        "difference_extended_minus_clinical": (
                extended_result["concordance_index"]
                - clinical_result["concordance_index"]
        ),
    }

    # Create the report directory if required.
    REPORT_PATH.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    # Save the comparison report as JSON.
    with REPORT_PATH.open(
            "w",
            encoding="utf-8",
    ) as output_file:
        json.dump(
            comparison,
            output_file,
            indent=2,
        )

    # Print the Cox model comparison.
    print("Cox validation comparison")
    print("-" * 40)

    print(
        "Clinical C-index: "
        f"{clinical_result['concordance_index']:.3f}"
    )

    print(
        "Extended C-index: "
        f"{extended_result['concordance_index']:.3f}"
    )

    print(
        "Difference: "
        f"{comparison['difference_extended_minus_clinical']:+.3f}"
    )

    print(f"\nReport saved to: {REPORT_PATH}")


if __name__ == "__main__":
    main()