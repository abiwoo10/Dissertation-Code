from __future__ import annotations

import argparse
import hashlib
import io
import json
import tarfile
from pathlib import Path
from typing import Any

import pandas as pd


# ---------------------------------------------------------------------------
# Project Paths and Audit Configuration
# ---------------------------------------------------------------------------

PROJECT_ROOT = Path(__file__).resolve().parents[1]

# Archive members containing the patient and sample clinical data.
PATIENT_MEMBER = "brca_metabric/data_clinical_patient.txt"
SAMPLE_MEMBER = "brca_metabric/data_clinical_sample.txt"

# Required columns from the patient table.
REQUIRED_PATIENT_COLUMNS = {
    "PATIENT_ID",
    "OS_MONTHS",
    "OS_STATUS",
    "AGE_AT_DIAGNOSIS",
}

# Required columns from the sample table.
REQUIRED_SAMPLE_COLUMNS = {
    "PATIENT_ID",
    "SAMPLE_ID",
}

# Columns included in the leakage review.
LEAKAGE_REVIEW_COLUMNS = {
    "VITAL_STATUS",
    "RFS_MONTHS",
    "RFS_STATUS",
}


# ---------------------------------------------------------------------------
# File Hashing
# ---------------------------------------------------------------------------

# Calculate the SHA-256 hash of a file.
def sha256_file(path: Path, chunk_size: int = 1024 * 1024) -> str:
    digest = hashlib.sha256()

    # Read and update the hash in chunks.
    with path.open("rb") as file_handle:
        while chunk := file_handle.read(chunk_size):
            digest.update(chunk)

    return digest.hexdigest()


# ---------------------------------------------------------------------------
# Archive Reading
# ---------------------------------------------------------------------------

# Read a tab-separated cBioPortal table from the archive.
def read_cbioportal_table(archive: tarfile.TarFile, member_name: str) -> pd.DataFrame:
    try:
        member = archive.getmember(member_name)
    except KeyError as exc:
        raise ValueError(f"Required archive member is missing: {member_name}") from exc

    extracted = archive.extractfile(member)
    if extracted is None:
        raise ValueError(f"Could not read archive member: {member_name}")

    # Read the extracted archive member as a DataFrame.
    text_stream = io.TextIOWrapper(extracted, encoding="utf-8")
    return pd.read_csv(text_stream, sep="\t", comment="#", dtype=str)


# ---------------------------------------------------------------------------
# Survival Target Parsing
# ---------------------------------------------------------------------------

# Convert survival status values into binary event indicators.
def parse_event(series: pd.Series) -> pd.Series:
    mapping = {
        "0:LIVING": 0,
        "1:DECEASED": 1,
    }

    # Remove surrounding whitespace before mapping the status values.
    stripped = series.astype("string").str.strip()
    parsed = stripped.map(mapping)

    # Find any survival status values that could not be mapped.
    unknown = sorted(stripped[parsed.isna() & stripped.notna()].unique().tolist())
    if unknown:
        raise ValueError(f"Unknown OS_STATUS values: {unknown}")

    return parsed.astype("Int64")


# ---------------------------------------------------------------------------
# Category Normalisation
# ---------------------------------------------------------------------------

# Normalise categorical values in the supplied table.
def normalise_categories(frame: pd.DataFrame) -> pd.DataFrame:
    output = frame.copy()

    # Correct and standardise ER_IHC values when the column is present.
    if "ER_IHC" in output.columns:
        output["ER_IHC"] = (
            output["ER_IHC"]
            .astype("string")
            .str.strip()
            .replace({"Positve": "Positive"})
        )

    # Remove surrounding whitespace from categorical columns.
    for column in output.select_dtypes(include=["object", "string"]).columns:
        output[column] = output[column].astype("string").str.strip()

    return output


# ---------------------------------------------------------------------------
# METABRIC Audit
# ---------------------------------------------------------------------------

# Audit the METABRIC archive and create the audit outputs.
def audit_metabric(archive_path: Path, output_dir: Path) -> dict[str, Any]:
    if not archive_path.exists():
        raise FileNotFoundError(f"Archive not found: {archive_path}")

    # Create the audit output directory if required.
    output_dir.mkdir(parents=True, exist_ok=True)

    # Load the patient and sample tables from the archive.
    with tarfile.open(archive_path, mode="r:*") as archive:
        patient = read_cbioportal_table(archive, PATIENT_MEMBER)
        sample = read_cbioportal_table(archive, SAMPLE_MEMBER)

    # Find any required columns missing from either table.
    missing_patient = REQUIRED_PATIENT_COLUMNS - set(patient.columns)
    missing_sample = REQUIRED_SAMPLE_COLUMNS - set(sample.columns)

    if missing_patient or missing_sample:
        raise ValueError(
            "Missing required columns. "
            f"Patient: {sorted(missing_patient)}; Sample: {sorted(missing_sample)}"
        )

    # Normalise categorical values in both tables.
    patient = normalise_categories(patient)
    sample = normalise_categories(sample)

    # Create the numeric survival duration and event columns.
    patient["duration"] = pd.to_numeric(patient["OS_MONTHS"], errors="coerce")
    patient["event"] = parse_event(patient["OS_STATUS"])

    # Count duplicate patient and sample identifiers.
    duplicate_patient_ids = int(patient["PATIENT_ID"].duplicated().sum())
    duplicate_sample_ids = int(sample["SAMPLE_ID"].duplicated().sum())

    # Merge the patient and sample tables using the patient identifier.
    merged = patient.merge(
        sample,
        on="PATIENT_ID",
        how="left",
        suffixes=("_patient", "_sample"),
        validate="one_to_one",
    )

    # Select rows containing complete survival targets.
    complete_target = merged["duration"].notna() & merged["event"].notna()
    target_frame = merged.loc[complete_target, ["duration", "event"]]

    # Count negative and zero survival durations.
    invalid_negative_duration = int((merged["duration"] < 0).fillna(False).sum())
    zero_duration = int((merged["duration"] == 0).fillna(False).sum())

    # Calculate the percentage of missing values in each column.
    missingness = (
        merged.isna()
        .mean()
        .mul(100)
        .sort_values(ascending=False)
        .rename_axis("column")
        .reset_index(name="missing_percent")
    )

    # Save the missingness report.
    missingness.to_csv(output_dir / "metabric_missingness.csv", index=False)

    # Find the leakage review columns present in the merged data.
    leakage_columns_present = sorted(LEAKAGE_REVIEW_COLUMNS & set(merged.columns))

    # Create the audit report.
    report: dict[str, Any] = {
        "archive": {
            "path": str(archive_path),
            "sha256": sha256_file(archive_path),
            "size_bytes": archive_path.stat().st_size,
        },
        "cohort": {
            "patient_rows": int(len(patient)),
            "sample_rows": int(len(sample)),
            "merged_rows": int(len(merged)),
            "unique_patients": int(patient["PATIENT_ID"].nunique()),
            "unique_samples": int(sample["SAMPLE_ID"].nunique()),
            "duplicate_patient_ids": duplicate_patient_ids,
            "duplicate_sample_ids": duplicate_sample_ids,
        },
        "survival_target": {
            "complete_rows": int(complete_target.sum()),
            "missing_rows": int((~complete_target).sum()),
            "events": int((target_frame["event"] == 1).sum()),
            "censored": int((target_frame["event"] == 0).sum()),
            "event_fraction": (
                float((target_frame["event"] == 1).mean())
                if len(target_frame)
                else None
            ),
            "median_duration_months": (
                float(target_frame["duration"].median())
                if len(target_frame)
                else None
            ),
            "maximum_duration_months": (
                float(target_frame["duration"].max())
                if len(target_frame)
                else None
            ),
            "negative_duration_rows": invalid_negative_duration,
            "zero_duration_rows": zero_duration,
        },
        "data_quality": {
            "leakage_review_columns_present": leakage_columns_present,
            "er_ihc_values": (
                sorted(merged["ER_IHC"].dropna().unique().tolist())
                if "ER_IHC" in merged.columns
                else []
            ),
        },
    }

    # Save the audit report as JSON.
    with (output_dir / "metabric_audit.json").open("w", encoding="utf-8") as file_handle:
        json.dump(report, file_handle, indent=2)

    return report


# ---------------------------------------------------------------------------
# Command-Line Interface
# ---------------------------------------------------------------------------

# Create the command-line argument parser.
def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Audit the cBioPortal METABRIC archive without extracting it."
    )

    # Add the archive path argument.
    parser.add_argument(
        "--archive",
        type=Path,
        default=PROJECT_ROOT / "data" / "raw" / "brca_metabric.tar.gz",
        help="Path to the METABRIC .tar.gz archive.",
    )

    # Add the audit output directory argument.
    parser.add_argument(
        "--output",
        type=Path,
        default=PROJECT_ROOT / "data" / "reports",
        help="Directory for audit outputs.",
    )

    return parser


# ---------------------------------------------------------------------------
# Script Entry Point
# ---------------------------------------------------------------------------

# Run the METABRIC audit using the command-line arguments.
def main() -> None:
    args = build_parser().parse_args()
    report = audit_metabric(args.archive, args.output)
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()