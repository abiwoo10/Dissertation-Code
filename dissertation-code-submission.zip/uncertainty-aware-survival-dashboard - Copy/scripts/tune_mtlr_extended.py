from __future__ import annotations

import json
import time
from itertools import product
from pathlib import Path

from ml.evaluation import SurvivalModelEvaluator
from ml.mtlr_model import MTLRModel
from ml.preprocessing import (
    prepare_model_dataset,
    TransformedDatasetSplit,
)


# ---------------------------------------------------------------------------
# Project Paths
# ---------------------------------------------------------------------------

PROJECT_ROOT = Path(__file__).resolve().parents[1]

# Path used to save the extended MTLR tuning report.
REPORT_PATH = (
    PROJECT_ROOT
    / "data"
    / "reports"
    / "mtlr_extended_tuning.json"
)


# ---------------------------------------------------------------------------
# Tuning Configuration
# ---------------------------------------------------------------------------

# Hyperparameter values included in the tuning search.
NUMBER_OF_BINS = [10, 20, 30]
LEARNING_RATES = [0.001, 0.005, 0.01]
WEIGHT_DECAYS = [0.0, 0.0001, 0.001]

# Training parameters shared across configurations.
MAX_EPOCHS = 1000
PATIENCE = 50
MINIMUM_IMPROVEMENT = 0.0001
RANDOM_STATE = 42

# Prediction time points used for validation.
PREDICTION_TIMES_MONTHS = [
    12.0,
    36.0,
    60.0,
]


# ---------------------------------------------------------------------------
# Configuration Evaluation
# ---------------------------------------------------------------------------

# Train and evaluate one extended MTLR configuration.
def run_configuration(
    dataset: TransformedDatasetSplit,
    *,
    number_of_bins: int,
    learning_rate: float,
    weight_decay: float,
) -> dict[str, object]:

    # Create the MTLR model using the selected configuration.
    model = MTLRModel(
        number_of_bins=number_of_bins,
        learning_rate=learning_rate,
        epochs=MAX_EPOCHS,
        weight_decay=weight_decay,
        random_state=RANDOM_STATE,
        patience=PATIENCE,
        minimum_improvement=MINIMUM_IMPROVEMENT,
    )

    # Start the training timer.
    start_time = time.perf_counter()

    # Fit the model using the training and validation datasets.
    model.fit(
        X=dataset.X_train,
        duration=dataset.duration_train,
        event=dataset.event_train,
        X_validation=dataset.X_validation,
        duration_validation=dataset.duration_validation,
        event_validation=dataset.event_validation,
    )

    # Calculate the training time.
    elapsed_seconds = time.perf_counter() - start_time

    # Generate survival predictions for the validation dataset.
    prediction = model.predict_survival(
        X=dataset.X_validation,
        time_points=PREDICTION_TIMES_MONTHS,
    )

    # Evaluate the validation predictions.
    evaluation = SurvivalModelEvaluator().evaluate(
        prediction=prediction,
        duration=dataset.duration_validation,
        event=dataset.event_validation,
    )

    # Check that the validation loss history was created.
    if not model.validation_losses:
        raise RuntimeError(
            "Validation loss history was not created."
        )

    # Return the configuration and validation results.
    return {
        "number_of_bins": number_of_bins,
        "learning_rate": learning_rate,
        "weight_decay": weight_decay,
        "best_epoch": model.best_epoch,
        "stopped_early": model.stopped_early,
        "epochs_completed": len(model.training_losses),
        "initial_training_loss": model.training_losses[0],
        "final_training_loss": model.training_losses[-1],
        "best_validation_loss": min(model.validation_losses),
        "final_validation_loss": model.validation_losses[-1],
        "validation_concordance_index": (
            evaluation.concordance_index
        ),
        "training_seconds": elapsed_seconds,
        "time_boundary_count": (
            len(model.time_bins)
            if model.time_bins is not None
            else None
        ),
    }


# ---------------------------------------------------------------------------
# Extended MTLR Tuning
# ---------------------------------------------------------------------------

# Tune the extended MTLR model configurations.
def main() -> None:

    # Prepare the extended model dataset.
    dataset = prepare_model_dataset(
        model_type="extended",
        test_size=0.20,
        validation_size=0.20,
        random_state=RANDOM_STATE,
    )

    # Create all hyperparameter configurations.
    configurations = list(
        product(
            NUMBER_OF_BINS,
            LEARNING_RATES,
            WEIGHT_DECAYS,
        )
    )

    results: list[dict[str, object]] = []

    print(
        f"Running {len(configurations)} "
        "extended MTLR configurations."
    )

    # Train and evaluate each configuration.
    for run_number, (
        number_of_bins,
        learning_rate,
        weight_decay,
    ) in enumerate(configurations, start=1):
        print(
            f"\nRun {run_number}/{len(configurations)}: "
            f"bins={number_of_bins}, "
            f"lr={learning_rate}, "
            f"weight_decay={weight_decay}"
        )

        result = run_configuration(
            dataset,
            number_of_bins=number_of_bins,
            learning_rate=learning_rate,
            weight_decay=weight_decay,
        )

        results.append(result)

        print(
            "Best validation loss: "
            f"{result['best_validation_loss']:.4f}"
        )
        print(
            "Validation C-index: "
            f"{result['validation_concordance_index']:.3f}"
        )
        print(
            "Best epoch: "
            f"{result['best_epoch']}"
        )
        print(
            "Training time: "
            f"{result['training_seconds']:.1f} seconds"
        )

    # Rank the configurations by validation loss.
    ranked_by_validation_loss = sorted(
        results,
        key=lambda item: float(
            item["best_validation_loss"]
        ),
    )

    # Rank the configurations by validation concordance index.
    ranked_by_c_index = sorted(
        results,
        key=lambda item: float(
            item["validation_concordance_index"]
        ),
        reverse=True,
    )

    # Create the extended MTLR tuning report.
    report = {
        "selection_metric": "best_validation_loss",
        "model_type": "extended",
        "configuration_count": len(results),
        "search_space": {
            "number_of_bins": NUMBER_OF_BINS,
            "learning_rates": LEARNING_RATES,
            "weight_decays": WEIGHT_DECAYS,
            "maximum_epochs": MAX_EPOCHS,
            "patience": PATIENCE,
            "minimum_improvement": MINIMUM_IMPROVEMENT,
            "random_state": RANDOM_STATE,
        },
        "best_by_validation_loss": (
            ranked_by_validation_loss[0]
        ),
        "best_by_concordance_index": (
            ranked_by_c_index[0]
        ),
        "results": results,
    }

    # Create the report directory if required.
    REPORT_PATH.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    # Save the tuning report as JSON.
    with REPORT_PATH.open(
        "w",
        encoding="utf-8",
    ) as output_file:
        json.dump(
            report,
            output_file,
            indent=2,
        )

    # Select the configuration with the lowest validation loss.
    best = ranked_by_validation_loss[0]

    # Print the selected configuration and validation results.
    print("\nTuning complete.")
    print("-" * 48)
    print(
        "Selected configuration: "
        f"bins={best['number_of_bins']}, "
        f"lr={best['learning_rate']}, "
        f"weight_decay={best['weight_decay']}"
    )
    print(
        "Best validation loss: "
        f"{best['best_validation_loss']:.4f}"
    )
    print(
        "Validation C-index: "
        f"{best['validation_concordance_index']:.3f}"
    )
    print(f"Report saved to: {REPORT_PATH}")


if __name__ == "__main__":
    main()