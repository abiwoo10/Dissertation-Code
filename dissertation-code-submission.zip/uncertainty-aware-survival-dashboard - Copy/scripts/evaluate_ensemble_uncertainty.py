from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import spearmanr

from ml.ensemble_model import MTLREnsembleModel
from ml.preprocessing import prepare_model_dataset


# ---------------------------------------------------------------------------
# Project Paths
# ---------------------------------------------------------------------------

PROJECT_ROOT = Path(__file__).resolve().parents[1]

# Path to the trained MTLR ensemble model.
ENSEMBLE_PATH = (
    PROJECT_ROOT
    / "models"
    / "trained"
    / "mtlr_xcal_ensemble.pkl"
)

# Path used to save the ensemble uncertainty evaluation report.
REPORT_PATH = (
    PROJECT_ROOT
    / "data"
    / "reports"
    / "ensemble_uncertainty_evaluation.json"
)


# ---------------------------------------------------------------------------
# Evaluation Horizons
# ---------------------------------------------------------------------------

# Prediction horizons used for uncertainty evaluation.
HORIZONS = [
    12.0,
    36.0,
    60.0,
]


# ---------------------------------------------------------------------------
# Observed Survival Outcomes
# ---------------------------------------------------------------------------

# Create known binary survival outcomes at a selected prediction horizon.
def observed_survival_at_horizon(
    duration: pd.Series,
    event: pd.Series,
    horizon: float,
) -> tuple[np.ndarray, np.ndarray]:

    # Convert the survival durations and event indicators to arrays.
    duration_values = duration.to_numpy(dtype=float)
    event_values = event.to_numpy(dtype=bool)

    # Identify deaths occurring on or before the prediction horizon.
    death_before_horizon = (
        event_values
        & (duration_values <= horizon)
    )

    # Identify patients followed beyond the prediction horizon.
    known_alive_at_horizon = (
        duration_values > horizon
    )

    # Select patients with a known survival outcome at the horizon.
    known_mask = (
        death_before_horizon
        | known_alive_at_horizon
    )

    # Assign zero to deaths and one to patients surviving beyond the horizon.
    outcomes = np.where(
        death_before_horizon,
        0.0,
        1.0,
    )

    return outcomes, known_mask


# ---------------------------------------------------------------------------
# Uncertainty Groups
# ---------------------------------------------------------------------------

# Summarise prediction errors across uncertainty groups.
def uncertainty_group_summary(
    uncertainty: np.ndarray,
    absolute_error: np.ndarray,
) -> list[dict[str, float | int | str]]:

    # Divide the uncertainty values into three groups.
    groups = pd.qcut(
        uncertainty,
        q=3,
        labels=[
            "low",
            "medium",
            "high",
        ],
        duplicates="drop",
    )

    # Combine the uncertainty, error and group values.
    frame = pd.DataFrame(
        {
            "uncertainty": uncertainty,
            "absolute_error": absolute_error,
            "group": groups,
        }
    )

    summaries = []

    # Calculate the summary values for each uncertainty group.
    for group_name, group in frame.groupby(
        "group",
        observed=True,
    ):
        summaries.append(
            {
                "group": str(group_name),
                "patient_count": len(group),
                "mean_uncertainty": float(
                    group["uncertainty"].mean()
                ),
                "mean_absolute_error": float(
                    group["absolute_error"].mean()
                ),
            }
        )

    return summaries


# ---------------------------------------------------------------------------
# Horizon Evaluation
# ---------------------------------------------------------------------------

# Evaluate ensemble uncertainty at a selected prediction horizon.
def evaluate_horizon(
    ensemble: MTLREnsembleModel,
    X: pd.DataFrame,
    duration: pd.Series,
    event: pd.Series,
    horizon: float,
) -> dict[str, object]:

    # Create the prediction times required for the horizon evaluation.
    prediction_times = sorted(
        {
            12.0,
            36.0,
            60.0,
            horizon,
        }
    )

    # Generate survival predictions from each ensemble member.
    member_predictions = [
        member.predict_survival(
            X=X,
            time_points=prediction_times,
        )
        for member in ensemble.members
    ]

    # Collect each member's survival probability at the selected horizon.
    member_probabilities = np.stack(
        [
            prediction.survival_curve[
                float(horizon)
            ].to_numpy(dtype=float)
            for prediction in member_predictions
        ],
        axis=0,
    )

    # Calculate the mean ensemble survival probability.
    mean_probability = member_probabilities.mean(
        axis=0
    )

    # Calculate the standard deviation across ensemble members.
    horizon_uncertainty = member_probabilities.std(
        axis=0,
        ddof=0,
    )

    # Get the observed outcomes with known status at the horizon.
    outcomes, known_mask = observed_survival_at_horizon(
        duration=duration,
        event=event,
        horizon=horizon,
    )

    # Select predictions, uncertainty values and outcomes with known status.
    known_probabilities = mean_probability[
        known_mask
    ]

    known_uncertainty = horizon_uncertainty[
        known_mask
    ]

    known_outcomes = outcomes[
        known_mask
    ]

    # Calculate the absolute prediction errors.
    absolute_error = np.abs(
        known_probabilities
        - known_outcomes
    )

    # Calculate the squared prediction errors.
    squared_error = (
        known_probabilities
        - known_outcomes
    ) ** 2

    # Calculate the correlation between uncertainty and absolute error.
    correlation, p_value = spearmanr(
        known_uncertainty,
        absolute_error,
    )

    # Return the uncertainty evaluation results for the horizon.
    return {
        "horizon_months": horizon,
        "known_outcome_count": int(
            known_mask.sum()
        ),
        "excluded_censored_count": int(
            (~known_mask).sum()
        ),
        "mean_predicted_survival": float(
            known_probabilities.mean()
        ),
        "mean_horizon_uncertainty": float(
            known_uncertainty.mean()
        ),
        "maximum_horizon_uncertainty": float(
            known_uncertainty.max()
        ),
        "mean_absolute_error": float(
            absolute_error.mean()
        ),
        "mean_squared_error": float(
            squared_error.mean()
        ),
        "uncertainty_error_spearman_correlation": float(
            correlation
        ),
        "uncertainty_error_p_value": float(
            p_value
        ),
        "uncertainty_groups": uncertainty_group_summary(
            known_uncertainty,
            absolute_error,
        ),
    }


# ---------------------------------------------------------------------------
# Ensemble Uncertainty Evaluation
# ---------------------------------------------------------------------------

# Evaluate ensemble uncertainty across the prediction horizons.
def main() -> None:

    # Prepare the extended validation dataset.
    dataset = prepare_model_dataset(
        model_type="extended",
        test_size=0.20,
        validation_size=0.20,
        random_state=42,
    )

    # Load the trained MTLR ensemble model.
    ensemble = MTLREnsembleModel.load(
        ENSEMBLE_PATH
    )

    # Evaluate ensemble uncertainty at each prediction horizon.
    results = [
        evaluate_horizon(
            ensemble=ensemble,
            X=dataset.X_validation,
            duration=dataset.duration_validation,
            event=dataset.event_validation,
            horizon=horizon,
        )
        for horizon in HORIZONS
    ]

    # Create the ensemble uncertainty evaluation report.
    report = {
        "model": "mtlr_xcal_ensemble",
        "dataset_partition": "validation",
        "member_count": len(
            ensemble.members
        ),
        "uncertainty_definition": (
            "Standard deviation of member survival probabilities "
            "at each prediction horizon."
        ),
        "limitations": [
            (
                "Patients censored before a horizon are excluded because "
                "their binary survival outcome at that horizon is unknown."
            ),
            (
                "Ensemble disagreement represents model uncertainty and "
                "does not capture every source of prognostic uncertainty."
            ),
            (
                "The disagreement values are not clinical confidence "
                "intervals."
            ),
        ],
        "horizons": results,
    }

    # Create the report directory if required.
    REPORT_PATH.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    # Save the evaluation report as JSON.
    with REPORT_PATH.open(
        "w",
        encoding="utf-8",
    ) as output_file:
        json.dump(
            report,
            output_file,
            indent=2,
        )

    # Print the ensemble uncertainty evaluation results.
    print("Ensemble uncertainty evaluation")
    print("-" * 48)

    for result in results:
        print(
            f"\n{result['horizon_months']:.0f}-month horizon"
        )
        print(
            "  Known outcomes: "
            f"{result['known_outcome_count']}"
        )
        print(
            "  Mean uncertainty: "
            f"{result['mean_horizon_uncertainty']:.4f}"
        )
        print(
            "  Mean absolute error: "
            f"{result['mean_absolute_error']:.4f}"
        )
        print(
            "  Uncertainty-error Spearman correlation: "
            f"{result['uncertainty_error_spearman_correlation']:.3f}"
        )
        print(
            "  Correlation p-value: "
            f"{result['uncertainty_error_p_value']:.4f}"
        )

        # Print the error and uncertainty values for each uncertainty group.
        for group in result["uncertainty_groups"]:
            print(
                f"    {group['group']}: "
                f"error={group['mean_absolute_error']:.4f}, "
                f"uncertainty={group['mean_uncertainty']:.4f}"
            )

    print(f"\nReport saved to: {REPORT_PATH}")


if __name__ == "__main__":
    main()