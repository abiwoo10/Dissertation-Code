from __future__ import annotations

import json
from pathlib import Path

import numpy as np

from ml.ensemble_model import MTLREnsembleModel
from ml.preprocessing import prepare_model_dataset
from ml.prognosis import calculate_uncertainty_thresholds


# ---------------------------------------------------------------------------
# Project Paths
# ---------------------------------------------------------------------------

PROJECT_ROOT = Path(__file__).resolve().parents[1]

# Path to the trained MTLR ensemble model.
ENSEMBLE_PATH = (
    PROJECT_ROOT
    / "models"
    / "trained"
    / "mtlr_xcal_ensemble.pkl"
)

# Path used to save the ensemble uncertainty thresholds.
OUTPUT_PATH = (
    PROJECT_ROOT
    / "models"
    / "metadata"
    / "ensemble_uncertainty_thresholds.json"
)


# ---------------------------------------------------------------------------
# Prediction Times
# ---------------------------------------------------------------------------

# Prediction time points from 6 to 240 months.
PREDICTION_TIMES = np.arange(
    6.0,
    241.0,
    6.0,
).tolist()


# ---------------------------------------------------------------------------
# Uncertainty Thresholds
# ---------------------------------------------------------------------------

# Calculate and save ensemble disagreement thresholds.
def main() -> None:

    # Prepare the extended validation dataset.
    dataset = prepare_model_dataset(
        model_type="extended",
        test_size=0.20,
        validation_size=0.20,
        random_state=42,
    )

    if not ENSEMBLE_PATH.exists():
        raise FileNotFoundError(
            f"Ensemble model not found: {ENSEMBLE_PATH}"
        )

    # Load the trained MTLR ensemble model.
    ensemble = MTLREnsembleModel.load(
        ENSEMBLE_PATH
    )

    # Generate survival predictions for the validation dataset.
    prediction = ensemble.predict_survival(
        X=dataset.X_validation,
        time_points=PREDICTION_TIMES,
    )

    # Calculate the uncertainty thresholds from the predictions.
    thresholds = calculate_uncertainty_thresholds(
        prediction
    )

    # Create the uncertainty threshold metadata.
    metadata = {
        "source_partition": "validation",
        "method": "uncertainty tertiles",
        "lower_threshold": thresholds.lower_threshold,
        "higher_threshold": thresholds.higher_threshold,
        "validation_patient_count": len(
            dataset.X_validation
        ),
        "ensemble_model": ENSEMBLE_PATH.name,
    }

    # Create the output directory if required.
    OUTPUT_PATH.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    # Save the uncertainty threshold metadata as JSON.
    with OUTPUT_PATH.open(
        "w",
        encoding="utf-8",
    ) as output_file:
        json.dump(
            metadata,
            output_file,
            indent=2,
        )

    # Print the saved uncertainty thresholds.
    print("Ensemble uncertainty thresholds saved.")
    print(
        "Lower threshold: "
        f"{thresholds.lower_threshold:.6f}"
    )
    print(
        "Higher threshold: "
        f"{thresholds.higher_threshold:.6f}"
    )
    print(f"Saved to: {OUTPUT_PATH}")


if __name__ == "__main__":
    main()