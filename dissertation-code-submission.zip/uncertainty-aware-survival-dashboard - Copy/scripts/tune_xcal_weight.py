from __future__ import annotations

import json
from pathlib import Path

import numpy as np

from ml.calibration import (
    calculate_censoring_adjusted_d_calibration,
    calculate_uncensored_d_calibration,
)
from ml.evaluation import SurvivalModelEvaluator
from ml.mtlr_model import MTLRModel
from ml.preprocessing import (
    prepare_model_dataset,
    TransformedDatasetSplit,
)


# ---------------------------------------------------------------------------
# Project Paths
# ---------------------------------------------------------------------------

PROJECT_ROOT = Path(__file__).resolve().parents[1]

# Path used to save the X-CAL weight tuning report.
REPORT_PATH = (
    PROJECT_ROOT
    / "data"
    / "reports"
    / "xcal_weight_tuning.json"
)


# ---------------------------------------------------------------------------
# X-CAL Tuning Configuration
# ---------------------------------------------------------------------------

# Calibration weights included in the tuning search.
CALIBRATION_WEIGHTS = [
    0.0,
    0.5,
    1.0,
    2.0,
    5.0,
]

# Evaluation time points from 6 to 240 months.
EVALUATION_TIMES = np.arange(
    6.0,
    241.0,
    6.0,
)

# Fixed MTLR parameters used across configurations.
NUMBER_OF_BINS = 20
LEARNING_RATE = 0.005
WEIGHT_DECAY = 0.001

# Training parameters shared across configurations.
MAX_EPOCHS = 1000
PATIENCE = 50
MINIMUM_IMPROVEMENT = 0.0001
RANDOM_STATE = 42

# X-CAL parameters shared across configurations.
XCAL_BINS = 10
XCAL_GAMMA = 10_000.0


# ---------------------------------------------------------------------------
# Configuration Evaluation
# ---------------------------------------------------------------------------

# Train and evaluate one X-CAL regularisation weight.
def run_configuration(
    dataset: TransformedDatasetSplit,
    calibration_weight: float,
) -> dict[str, object]:

    # Create the MTLR model using the selected calibration weight.
    model = MTLRModel(
        number_of_bins=NUMBER_OF_BINS,
        learning_rate=LEARNING_RATE,
        epochs=MAX_EPOCHS,
        weight_decay=WEIGHT_DECAY,
        random_state=RANDOM_STATE,
        patience=PATIENCE,
        minimum_improvement=MINIMUM_IMPROVEMENT,
        calibration_weight=calibration_weight,
        xcal_bins=XCAL_BINS,
        xcal_gamma=XCAL_GAMMA,
    )

    # Fit the model using the training and validation datasets.
    model.fit(
        X=dataset.X_train,
        duration=dataset.duration_train,
        event=dataset.event_train,
        X_validation=dataset.X_validation,
        duration_validation=dataset.duration_validation,
        event_validation=dataset.event_validation,
    )

    # Generate survival predictions for the validation dataset.
    prediction = model.predict_survival(
        X=dataset.X_validation,
        time_points=EVALUATION_TIMES.tolist(),
    )

    # Evaluate the validation predictions.
    evaluation = SurvivalModelEvaluator().evaluate(
        prediction=prediction,
        duration=dataset.duration_validation,
        event=dataset.event_validation,
        evaluation_times=EVALUATION_TIMES,
    )

    # Calculate uncensored D-calibration.
    d_calibration = calculate_uncensored_d_calibration(
        prediction=prediction,
        duration=dataset.duration_validation,
        event=dataset.event_validation,
        number_of_bins=10,
    )

    # Calculate censoring-adjusted D-calibration.
    adjusted_d_calibration = (
        calculate_censoring_adjusted_d_calibration(
            prediction=prediction,
            duration=dataset.duration_validation,
            event=dataset.event_validation,
            number_of_bins=10,
        )
    )

    # Return the configuration and validation results.
    return {
        "calibration_weight": calibration_weight,
        "best_epoch": model.best_epoch,
        "stopped_early": model.stopped_early,
        "epochs_completed": len(model.training_losses),
        "best_validation_total_loss": min(
            model.validation_losses
        ),
        "best_validation_nll": min(
            model.validation_nll_losses
        ),
        "best_validation_xcal_loss": min(
            model.validation_xcal_losses
        ),
        "validation_concordance_index": (
            evaluation.concordance_index
        ),
        "validation_integrated_brier_score": (
            evaluation.integrated_brier_score
        ),
        "d_calibration_chi_square": (
            d_calibration["chi_square_statistic"]
        ),
        "d_calibration_p_value": (
            d_calibration["p_value"]
        ),
        "d_calibration_passes_at_0_05": (
            d_calibration["passes_at_0_05"]
        ),
        "d_calibration_observed_counts": (
            d_calibration["observed_counts"]
        ),
        "adjusted_d_calibration_chi_square": (
            adjusted_d_calibration["chi_square_statistic"]
        ),
        "adjusted_d_calibration_p_value": (
            adjusted_d_calibration["p_value"]
        ),
        "adjusted_d_calibration_passes_at_0_05": (
            adjusted_d_calibration["passes_at_0_05"]
        ),
        "adjusted_d_calibration_observed_counts": (
            adjusted_d_calibration["observed_counts"]
        ),
    }


# ---------------------------------------------------------------------------
# X-CAL Weight Tuning
# ---------------------------------------------------------------------------

# Tune the X-CAL calibration weight.
def main() -> None:

    # Prepare the extended model dataset.
    dataset = prepare_model_dataset(
        model_type="extended",
        test_size=0.20,
        validation_size=0.20,
        random_state=RANDOM_STATE,
    )

    results: list[dict[str, object]] = []

    # Train and evaluate each calibration weight.
    for run_number, calibration_weight in enumerate(
        CALIBRATION_WEIGHTS,
        start=1,
    ):
        print(
            f"\nRun {run_number}/{len(CALIBRATION_WEIGHTS)}: "
            f"calibration_weight={calibration_weight}"
        )

        result = run_configuration(
            dataset=dataset,
            calibration_weight=calibration_weight,
        )

        results.append(result)

        print(
            "  C-index: "
            f"{result['validation_concordance_index']:.3f}"
        )

        print(
            "  IBS: "
            f"{result['validation_integrated_brier_score']:.4f}"
        )

        print(
            "  D-calibration p-value: "
            f"{result['d_calibration_p_value']:.4f}"
        )

        print(
            "  D-calibration chi-square: "
            f"{result['d_calibration_chi_square']:.3f}"
        )

        print(
            "  Adjusted D-calibration p-value: "
            f"{result['adjusted_d_calibration_p_value']:.4f}"
        )

        print(
            "  Adjusted D-calibration chi-square: "
            f"{result['adjusted_d_calibration_chi_square']:.3f}"
        )

        print(
            "  Best epoch: "
            f"{result['best_epoch']}"
        )

    # Rank the configurations by adjusted D-calibration chi-square.
    ranked_by_adjusted_d_calibration = sorted(
        results,
        key=lambda item: float(
            item["adjusted_d_calibration_chi_square"]
        ),
    )

    # Rank the configurations by integrated Brier score.
    ranked_by_ibs = sorted(
        results,
        key=lambda item: float(
            item["validation_integrated_brier_score"]
        ),
    )

    # Create the X-CAL weight tuning report.
    report = {
        "model_type": "extended_mtlr",
        "fixed_configuration": {
            "number_of_bins": NUMBER_OF_BINS,
            "learning_rate": LEARNING_RATE,
            "weight_decay": WEIGHT_DECAY,
            "maximum_epochs": MAX_EPOCHS,
            "patience": PATIENCE,
            "minimum_improvement": MINIMUM_IMPROVEMENT,
            "xcal_bins": XCAL_BINS,
            "xcal_gamma": XCAL_GAMMA,
            "random_state": RANDOM_STATE,
        },
        "calibration_weights": CALIBRATION_WEIGHTS,
        "best_by_adjusted_d_calibration_chi_square": (
            ranked_by_adjusted_d_calibration[0]
        ),
        "best_by_integrated_brier_score": (
            ranked_by_ibs[0]
        ),
        "results": results,
    }

    # Create the report directory if required.
    REPORT_PATH.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    # Save the tuning report as JSON.
    with REPORT_PATH.open(
        "w",
        encoding="utf-8",
    ) as output_file:
        json.dump(
            report,
            output_file,
            indent=2,
        )

    # Select the configuration with the lowest adjusted D-calibration chi-square.
    best_calibrated = ranked_by_adjusted_d_calibration[0]

    # Print the selected calibration weight and validation results.
    print("\nX-CAL weight tuning complete.")
    print("-" * 48)

    print(
        "Best calibration weight by adjusted D-calibration: "
        f"{best_calibrated['calibration_weight']}"
    )

    print(
        "Adjusted D-calibration chi-square: "
        f"{best_calibrated['adjusted_d_calibration_chi_square']:.3f}"
    )

    print(
        "Adjusted D-calibration p-value: "
        f"{best_calibrated['adjusted_d_calibration_p_value']:.4f}"
    )

    print(
        "Uncensored D-calibration chi-square: "
        f"{best_calibrated['d_calibration_chi_square']:.3f}"
    )

    print(
        "Validation IBS: "
        f"{best_calibrated['validation_integrated_brier_score']:.4f}"
    )

    print(
        "Validation C-index: "
        f"{best_calibrated['validation_concordance_index']:.3f}"
    )

    print(f"Report saved to: {REPORT_PATH}")


if __name__ == "__main__":
    main()