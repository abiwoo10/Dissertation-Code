from __future__ import annotations

from pathlib import Path
import sys


# ---------------------------------------------------------------------------
# Project Setup
# ---------------------------------------------------------------------------

PROJECT_ROOT = Path(__file__).resolve().parents[1]

# Add the project root to the Python import path.
sys.path.insert(0, str(PROJECT_ROOT))

from ml.preprocessing import load_feature_transformer


# ---------------------------------------------------------------------------
# Project Paths
# ---------------------------------------------------------------------------

PROJECT_ROOT = Path(__file__).resolve().parents[1]

# Path to the fitted extended feature transformer.
TRANSFORMER_PATH = (
    PROJECT_ROOT
    / "models"
    / "trained"
    / "extended_preprocessor.joblib"
)


# ---------------------------------------------------------------------------
# Preprocessor Inspection
# ---------------------------------------------------------------------------

# Inspect the fitted preprocessing structure and categorical values.
def main() -> None:

    # Load the fitted feature transformer.
    transformer = load_feature_transformer(
        TRANSFORMER_PATH
    )

    print("Fitted preprocessing structure")
    print("-" * 60)

    # Inspect each fitted transformer and its assigned columns.
    for name, fitted_transformer, columns in transformer.transformers_:
        print(f"\nTransformer name: {name}")
        print(
            "Transformer type: "
            f"{type(fitted_transformer).__name__}"
        )
        print(f"Columns: {list(columns)}")

        # Inspect the steps when the transformer is a pipeline.
        if hasattr(
            fitted_transformer,
            "named_steps",
        ):
            print("Pipeline steps:")

            for step_name, step in (
                fitted_transformer
                .named_steps
                .items()
            ):
                print(
                    f"  - {step_name}: "
                    f"{type(step).__name__}"
                )

                # Print categorical values stored by the pipeline step.
                if hasattr(
                    step,
                    "categories_",
                ):
                    print(
                        "    Categories found:"
                    )

                    for column, categories in zip(
                        columns,
                        step.categories_,
                    ):
                        print(f"\n    {column}")

                        for category in categories:
                            print(
                                f"      - {category}"
                            )

        # Print categorical values stored directly by the transformer.
        elif hasattr(
            fitted_transformer,
            "categories_",
        ):
            print("Categories found:")

            for column, categories in zip(
                columns,
                fitted_transformer.categories_,
            ):
                print(f"\n  {column}")

                for category in categories:
                    print(
                        f"    - {category}"
                    )


if __name__ == "__main__":
    main()