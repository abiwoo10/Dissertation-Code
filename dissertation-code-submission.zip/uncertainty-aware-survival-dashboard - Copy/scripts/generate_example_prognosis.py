from __future__ import annotations

import json
from pathlib import Path

from ml.mtlr_model import MTLRModel
from ml.preprocessing import prepare_model_dataset
from ml.prognosis import create_patient_prognosis


# ---------------------------------------------------------------------------
# Project Paths
# ---------------------------------------------------------------------------

PROJECT_ROOT = Path(__file__).resolve().parents[1]

# Path to the trained extended MTLR model.
MODEL_PATH = (
    PROJECT_ROOT
    / "models"
    / "trained"
    / "mtlr_extended.pkl"
)

# Path used to save the example patient prognosis.
OUTPUT_PATH = (
    PROJECT_ROOT
    / "data"
    / "reports"
    / "example_patient_prognosis.json"
)


# ---------------------------------------------------------------------------
# Prediction Times
# ---------------------------------------------------------------------------

# Prediction time points used for the survival curve.
PREDICTION_TIMES = [
    12.0,
    36.0,
    60.0,
    84.0,
    120.0,
    180.0,
]


# ---------------------------------------------------------------------------
# Example Patient Prognosis
# ---------------------------------------------------------------------------

# Generate an example patient prognosis using the extended MTLR model.
def main() -> None:

    # Prepare the extended validation dataset.
    dataset = prepare_model_dataset(
        model_type="extended",
        test_size=0.20,
        validation_size=0.20,
        random_state=42,
    )

    # Load the trained extended MTLR model.
    model = MTLRModel.load(MODEL_PATH)

    # Select the first patient from the validation dataset.
    patient_features = dataset.X_validation.iloc[[0]]

    # Generate the survival prediction for the selected patient.
    prediction = model.predict_survival(
        X=patient_features,
        time_points=PREDICTION_TIMES,
    )

    # Get the selected patient's index.
    patient_index = patient_features.index[0]

    # Create the patient prognosis.
    prognosis = create_patient_prognosis(
        prediction=prediction,
        patient_index=patient_index,
    )

    # Create the example prognosis response.
    output = {
        "model_name": prognosis.model_name,
        "patient_index": str(prognosis.patient_index),
        "one_year_survival_probability": (
            prognosis.one_year_survival
        ),
        "three_year_survival_probability": (
            prognosis.three_year_survival
        ),
        "five_year_survival_probability": (
            prognosis.five_year_survival
        ),
        "median_survival_months": (
            prognosis.median_survival_months
        ),
        "median_survival_years": (
            prognosis.median_survival_years()
        ),
        "uncertainty": prognosis.uncertainty,
        "explanation": prognosis.explanation,
        "survival_curve": {
            f"{float(time):g}_months": float(probability)
            for time, probability
            in prognosis.survival_curve.items()
        },
    }

    # Create the output directory if required.
    OUTPUT_PATH.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    # Save the example prognosis as JSON.
    with OUTPUT_PATH.open(
        "w",
        encoding="utf-8",
    ) as output_file:
        json.dump(
            output,
            output_file,
            indent=2,
        )

    # Print the example prognosis summary.
    print("Example patient prognosis generated.")
    print(
        "1-year estimated survival: "
        f"{prognosis.one_year_percentage():.1f}%"
    )
    print(
        "3-year estimated survival: "
        f"{prognosis.three_year_percentage():.1f}%"
    )
    print(
        "5-year estimated survival: "
        f"{prognosis.five_year_percentage():.1f}%"
    )

    # Print the median survival estimate when it is available.
    if prognosis.median_survival_years() is None:
        print(
            "Median predicted survival was not reached "
            "within the displayed time horizon."
        )
    else:
        print(
            "Median predicted survival: "
            f"{prognosis.median_survival_years():.1f} years"
        )

    print(f"Report saved to: {OUTPUT_PATH}")


if __name__ == "__main__":
    main()