from __future__ import annotations

import json
from pathlib import Path

from ml.kaplan_meier import (
    fit_kaplan_meier,
    summarise_kaplan_meier,
)

from ml.preprocessing import prepare_raw_model_data
from visualisation.survival_plots import save_kaplan_meier_plot


# ---------------------------------------------------------------------------
# Project Paths
# ---------------------------------------------------------------------------

PROJECT_ROOT = Path(__file__).resolve().parents[1]

# Path used to save the Kaplan–Meier figure.
FIGURE_PATH = (
    PROJECT_ROOT
    / "outputs"
    / "figures"
    / "metabric_kaplan_meier.png"
)

# Path used to save the Kaplan–Meier summary.
SUMMARY_PATH = (
    PROJECT_ROOT
    / "data"
    / "reports"
    / "kaplan_meier_summary.json"
)


# ---------------------------------------------------------------------------
# Evaluation Times
# ---------------------------------------------------------------------------

# Time points used for the survival probability summary.
TIME_POINTS_MONTHS = [12.0, 36.0, 60.0, 120.0]


# ---------------------------------------------------------------------------
# Kaplan–Meier Analysis
# ---------------------------------------------------------------------------

# Generate Kaplan–Meier estimates and summary statistics.
def main() -> None:

    # Prepare the clinical survival data.
    _, duration, event = prepare_raw_model_data(
        model_type="clinical"
    )

    # Fit the Kaplan–Meier estimator.
    estimator = fit_kaplan_meier(
        duration=duration,
        event=event,
        label="METABRIC cohort",
    )

    # Calculate the Kaplan–Meier summary statistics.
    summary = summarise_kaplan_meier(
        estimator=estimator,
        duration=duration,
        event=event,
        time_points=TIME_POINTS_MONTHS,
    )

    # Create the figure directory if required.
    FIGURE_PATH.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    # Create the summary directory if required.
    SUMMARY_PATH.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    # Create the Kaplan–Meier summary data.
    summary_data = {
        "patient_count": summary.patient_count,
        "event_count": summary.event_count,
        "censored_count": summary.censored_count,
        "median_survival_months": (
            summary.median_survival_months
        ),
        "survival_probabilities": {
            f"{time:g}_months": probability
            for time, probability
            in summary.survival_probabilities.items()
        },
    }

    # Save the Kaplan–Meier summary as JSON.
    with SUMMARY_PATH.open(
        "w",
        encoding="utf-8",
    ) as output_file:
        json.dump(
            summary_data,
            output_file,
            indent=2,
        )

    # Print the Kaplan–Meier summary.
    print("Kaplan–Meier analysis completed.")
    print(f"Patients: {summary.patient_count}")
    print(f"Events: {summary.event_count}")
    print(f"Censored: {summary.censored_count}")
    print(
        "Median survival: "
        f"{summary.median_survival_months:.2f} months"
    )

    print("\nEstimated survival probabilities:")

    for time, probability in (
        summary.survival_probabilities.items()
    ):
        print(
            f"  {time:g} months: "
            f"{probability:.3f}"
        )

    print(f"\nFigure saved to: {FIGURE_PATH}")
    print(f"Summary saved to: {SUMMARY_PATH}")

    # Save the Kaplan–Meier survival plot.
    save_kaplan_meier_plot(
        estimator=estimator,
        output_path=FIGURE_PATH,
        show_censors=False,
    )


if __name__ == "__main__":
    main()