from __future__ import annotations

import json
from pathlib import Path


# ---------------------------------------------------------------------------
# Project Paths
# ---------------------------------------------------------------------------

PROJECT_ROOT = Path(__file__).resolve().parents[1]

# Directory containing the model metadata files.
METADATA_DIRECTORY = (
    PROJECT_ROOT
    / "models"
    / "metadata"
)

# Path used to save the baseline model comparison report.
REPORT_PATH = (
    PROJECT_ROOT
    / "data"
    / "reports"
    / "baseline_model_comparison.json"
)


# ---------------------------------------------------------------------------
# Model Metadata Files
# ---------------------------------------------------------------------------

# Metadata files for each baseline model.
MODEL_FILES = {
    "clinical_cox": "cox_clinical.json",
    "extended_cox": "cox_extended.json",
    "clinical_mtlr": "mtlr_clinical.json",
    "extended_mtlr": "mtlr_extended.json",
}


# ---------------------------------------------------------------------------
# Metadata Loading
# ---------------------------------------------------------------------------

# Load a model metadata file.
def load_metadata(filename: str) -> dict[str, object]:

    path = METADATA_DIRECTORY / filename

    if not path.exists():
        raise FileNotFoundError(
            f"Model metadata file not found: {path}"
        )

    # Read and return the metadata from the JSON file.
    with path.open(
        "r",
        encoding="utf-8",
    ) as input_file:
        return json.load(input_file)


# ---------------------------------------------------------------------------
# Model Summary
# ---------------------------------------------------------------------------

# Extract the model information used in the baseline comparison.
def extract_model_summary(
    key: str,
    metadata: dict[str, object],
) -> dict[str, object]:

    # Identify the model family from the model key.
    model_family = (
        "MTLR"
        if "mtlr" in key
        else "Cox proportional hazards"
    )

    # Identify the feature set from the model key.
    feature_set = (
        "extended"
        if key.startswith("extended")
        else "clinical"
    )

    # Get the validation concordance index from the metadata.
    validation_c_index = metadata.get(
        "validation_concordance_index"
    )

    # Return the model information required for comparison.
    return {
        "model_key": key,
        "model_family": model_family,
        "feature_set": feature_set,
        "transformed_feature_count": metadata.get(
            "transformed_feature_count"
        ),
        "training_rows": metadata.get("training_rows"),
        "validation_rows": metadata.get("validation_rows"),
        "test_rows": metadata.get("test_rows"),
        "validation_concordance_index": validation_c_index,
        "initial_training_loss": metadata.get(
            "initial_training_loss"
        ),
        "final_training_loss": metadata.get(
            "final_training_loss"
        ),
    }


# ---------------------------------------------------------------------------
# Baseline Model Comparison
# ---------------------------------------------------------------------------

# Compare the baseline models using their saved validation results.
def main() -> None:
    summaries: dict[str, dict[str, object]] = {}

    # Load and summarise the metadata for each baseline model.
    for key, filename in MODEL_FILES.items():
        metadata = load_metadata(filename)
        summaries[key] = extract_model_summary(
            key,
            metadata,
        )

    # Get the clinical Cox validation concordance index.
    clinical_cox_c_index = summaries[
        "clinical_cox"
    ]["validation_concordance_index"]

    if clinical_cox_c_index is None:
        raise ValueError(
            "Clinical Cox metadata does not contain a validation C-index."
        )

    # Calculate each model's difference from the clinical Cox model.
    for summary in summaries.values():
        c_index = summary["validation_concordance_index"]

        summary["difference_from_clinical_cox"] = (
            float(c_index) - float(clinical_cox_c_index)
            if c_index is not None
            else None
        )

    # Select models containing a validation concordance index.
    valid_models = [
        model
        for model in summaries.values()
        if model["validation_concordance_index"] is not None
    ]

    # Rank the models by validation concordance index.
    ranked_models = sorted(
        summaries.values(),
        key=lambda item: float(
            item["validation_concordance_index"]
        ),
        reverse=True,
    )

    # Create the baseline model comparison report.
    report = {
        "comparison_basis": "validation set",
        "reference_model": "clinical_cox",
        "models": summaries,
        "ranking": [
            {
                "position": position,
                "model_key": model["model_key"],
                "validation_concordance_index": (
                    model["validation_concordance_index"]
                ),
            }
            for position, model in enumerate(
                ranked_models,
                start=1,
            )
        ],
        "best_validation_model": ranked_models[0]["model_key"],
    }

    # Create the report directory if required.
    REPORT_PATH.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    # Save the comparison report as JSON.
    with REPORT_PATH.open(
        "w",
        encoding="utf-8",
    ) as output_file:
        json.dump(
            report,
            output_file,
            indent=2,
        )

    # Print the ranked baseline model comparison.
    print("Baseline model comparison")
    print("-" * 48)

    for model in ranked_models:
        print(
            f"{model['model_key']}: "
            f"{model['validation_concordance_index']:.3f} "
            f"({model['difference_from_clinical_cox']:+.3f} "
            "vs clinical Cox)"
        )

    print(
        "\nBest validation model: "
        f"{ranked_models[0]['model_key']}"
    )

    print(f"Report saved to: {REPORT_PATH}")


if __name__ == "__main__":
    main()