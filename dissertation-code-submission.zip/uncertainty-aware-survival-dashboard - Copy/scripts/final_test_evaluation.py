from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from scipy.stats import spearmanr

from ml.calibration import (
    calculate_censoring_adjusted_d_calibration,
)
from ml.ensemble_model import MTLREnsembleModel
from ml.evaluation import SurvivalModelEvaluator
from ml.mtlr_model import MTLRModel
from ml.preprocessing import prepare_model_dataset


PROJECT_ROOT = Path(__file__).resolve().parents[1]

REPORT_PATH = (
    PROJECT_ROOT
    / "data"
    / "reports"
    / "final_test_evaluation.json"
)

XCAL_MODEL_PATH = (
    PROJECT_ROOT
    / "models"
    / "trained"
    / "mtlr_extended_xcal.pkl"
)

ENSEMBLE_PATH = (
    PROJECT_ROOT
    / "models"
    / "trained"
    / "mtlr_xcal_ensemble.pkl"
)

EVALUATION_TIMES = np.arange(
    6.0,
    241.0,
    6.0,
)

HORIZONS = [
    12.0,
    36.0,
    60.0,
]


def evaluate_survival_model(
    model,
    X,
    duration,
    event,
) -> dict[str, object]:

    prediction = model.predict_survival(
        X=X,
        time_points=EVALUATION_TIMES.tolist(),
    )

    evaluation = SurvivalModelEvaluator().evaluate(
        prediction=prediction,
        duration=duration,
        event=event,
        evaluation_times=EVALUATION_TIMES,
    )

    adjusted_d_calibration = (
        calculate_censoring_adjusted_d_calibration(
            prediction=prediction,
            duration=duration,
            event=event,
            number_of_bins=10,
        )
    )

    return {
        "concordance_index": (
            evaluation.concordance_index
        ),
        "integrated_brier_score": (
            evaluation.integrated_brier_score
        ),
        "adjusted_d_calibration": (
            adjusted_d_calibration
        ),
    }


def observed_survival_at_horizon(
    duration,
    event,
    horizon: float,
):
    duration_values = duration.to_numpy(
        dtype=float
    )
    event_values = event.to_numpy(
        dtype=bool
    )

    death_before_horizon = (
        event_values
        & (duration_values <= horizon)
    )

    known_alive_at_horizon = (
        duration_values > horizon
    )

    known_mask = (
        death_before_horizon
        | known_alive_at_horizon
    )

    outcomes = np.where(
        death_before_horizon,
        0.0,
        1.0,
    )

    return outcomes, known_mask


def evaluate_ensemble_uncertainty(
    ensemble,
    X,
    duration,
    event,
    horizon: float,
) -> dict[str, object]:

    prediction_times = sorted(
        {
            12.0,
            36.0,
            60.0,
            horizon,
        }
    )

    member_predictions = [
        member.predict_survival(
            X=X,
            time_points=prediction_times,
        )
        for member in ensemble.members
    ]

    member_probabilities = np.stack(
        [
            prediction.survival_curve[
                float(horizon)
            ].to_numpy(dtype=float)
            for prediction in member_predictions
        ],
        axis=0,
    )

    mean_probability = (
        member_probabilities.mean(axis=0)
    )

    horizon_uncertainty = (
        member_probabilities.std(
            axis=0,
            ddof=0,
        )
    )

    outcomes, known_mask = (
        observed_survival_at_horizon(
            duration=duration,
            event=event,
            horizon=horizon,
        )
    )

    known_probabilities = (
        mean_probability[known_mask]
    )

    known_uncertainty = (
        horizon_uncertainty[known_mask]
    )

    known_outcomes = outcomes[known_mask]

    absolute_error = np.abs(
        known_probabilities
        - known_outcomes
    )

    correlation, p_value = spearmanr(
        known_uncertainty,
        absolute_error,
    )

    return {
        "horizon_months": horizon,
        "known_outcome_count": int(
            known_mask.sum()
        ),
        "excluded_censored_count": int(
            (~known_mask).sum()
        ),
        "spearman_correlation": float(
            correlation
        ),
        "p_value": float(
            p_value
        ),
        "mean_absolute_error": float(
            absolute_error.mean()
        ),
        "mean_horizon_disagreement": float(
            known_uncertainty.mean()
        ),
    }


def main() -> None:

    # Recreates the SAME 60/20/20 split used
    # during development because the split sizes
    # and random seed are unchanged.
    dataset = prepare_model_dataset(
        model_type="extended",
        test_size=0.20,
        validation_size=0.20,
        random_state=42,
    )

    # Load the already-trained/frozen models.
    xcal_model = MTLRModel.load(
        XCAL_MODEL_PATH
    )

    ensemble = MTLREnsembleModel.load(
        ENSEMBLE_PATH
    )

    # ------------------------------------------------
    # Final held-out test: X-CAL MTLR
    # ------------------------------------------------

    xcal_results = evaluate_survival_model(
        model=xcal_model,
        X=dataset.X_test,
        duration=dataset.duration_test,
        event=dataset.event_test,
    )

    # ------------------------------------------------
    # Final held-out test: ensemble
    # ------------------------------------------------

    ensemble_results = evaluate_survival_model(
        model=ensemble,
        X=dataset.X_test,
        duration=dataset.duration_test,
        event=dataset.event_test,
    )

    # ------------------------------------------------
    # Final held-out disagreement/error analysis
    # ------------------------------------------------

    uncertainty_results = [
        evaluate_ensemble_uncertainty(
            ensemble=ensemble,
            X=dataset.X_test,
            duration=dataset.duration_test,
            event=dataset.event_test,
            horizon=horizon,
        )
        for horizon in HORIZONS
    ]

    report = {
        "dataset_partition": "held_out_test",
        "test_rows": len(
            dataset.X_test
        ),
        "random_state": 42,
        "evaluation_times_months": (
            EVALUATION_TIMES.tolist()
        ),
        "xcal_model": xcal_results,
        "ensemble": ensemble_results,
        "ensemble_uncertainty": (
            uncertainty_results
        ),
    }

    REPORT_PATH.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    with REPORT_PATH.open(
        "w",
        encoding="utf-8",
    ) as output_file:
        json.dump(
            report,
            output_file,
            indent=2,
        )

    print(
        "Final held-out test evaluation"
    )
    print("-" * 48)

    print(
        f"Test rows: {len(dataset.X_test)}"
    )

    for name, result in [
        ("X-CAL MTLR", xcal_results),
        ("X-CAL ensemble", ensemble_results),
    ]:
        print(f"\n{name}")

        print(
            "  C-index: "
            f"{result['concordance_index']:.3f}"
        )

        print(
            "  IBS: "
            f"{result['integrated_brier_score']:.4f}"
        )

        dcal = result[
            "adjusted_d_calibration"
        ]

        print(
            "  Adjusted D-calibration "
            "chi-square: "
            f"{dcal['chi_square_statistic']:.3f}"
        )

        print(
            "  Adjusted D-calibration "
            "p-value: "
            f"{dcal['p_value']:.4f}"
        )

        print(
            "  D-calibration passes "
            "at 0.05: "
            f"{dcal['passes_at_0_05']}"
        )

    print(
        "\nEnsemble disagreement "
        "vs absolute error"
    )

    for result in uncertainty_results:
        print(
            f"  "
            f"{result['horizon_months']:.0f} months: "
            f"rho="
            f"{result['spearman_correlation']:.3f}, "
            f"p="
            f"{result['p_value']:.4g}, "
            f"n="
            f"{result['known_outcome_count']}"
        )

    print(
        f"\nReport saved to: "
        f"{REPORT_PATH}"
    )


if __name__ == "__main__":
    main()