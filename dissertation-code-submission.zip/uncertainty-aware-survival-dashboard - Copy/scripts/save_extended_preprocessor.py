from __future__ import annotations

import json
from pathlib import Path

from ml.ensemble_model import MTLREnsembleModel
from ml.preprocessing import (
    prepare_model_dataset,
    save_feature_transformer,
)
from ml.feature_config import EXTENDED_FEATURES


# ---------------------------------------------------------------------------
# Project Paths
# ---------------------------------------------------------------------------

PROJECT_ROOT = Path(__file__).resolve().parents[1]

# Path to the trained MTLR ensemble model.
ENSEMBLE_PATH = (
    PROJECT_ROOT
    / "models"
    / "trained"
    / "mtlr_xcal_ensemble.pkl"
)

# Path used to save the extended feature transformer.
TRANSFORMER_PATH = (
    PROJECT_ROOT
    / "models"
    / "trained"
    / "extended_preprocessor.joblib"
)

# Path used to save the extended preprocessor metadata.
METADATA_PATH = (
    PROJECT_ROOT
    / "models"
    / "metadata"
    / "extended_preprocessor.json"
)


# ---------------------------------------------------------------------------
# Extended Preprocessor
# ---------------------------------------------------------------------------

# Save the extended feature transformer and metadata.
def main() -> None:

    # Prepare the extended model dataset.
    dataset = prepare_model_dataset(
        model_type="extended",
        test_size=0.20,
        validation_size=0.20,
        random_state=42,
    )

    # Load the trained MTLR ensemble model.
    ensemble = MTLREnsembleModel.load(
        ENSEMBLE_PATH
    )

    # Get the transformed feature names from the fitted transformer.
    transformed_feature_names = (
        dataset.transformer
        .get_feature_names_out()
        .tolist()
    )

    # Check that the transformed feature names match the ensemble.
    if (
        transformed_feature_names
        != ensemble.feature_names
    ):
        raise ValueError(
            "Preprocessor feature names do not match "
            "the saved ensemble feature names."
        )

    # Check that the expected number of transformed features is present.
    if len(transformed_feature_names) != 29:
        raise ValueError(
            "Expected 29 transformed features, "
            f"but found {len(transformed_feature_names)}."
        )

    # Save the fitted feature transformer.
    save_feature_transformer(
        transformer=dataset.transformer,
        path=TRANSFORMER_PATH,
    )

    # Create the extended preprocessor metadata.
    metadata = {
        "model_type": "extended",
        "raw_features": EXTENDED_FEATURES,
        "raw_feature_count": len(
            EXTENDED_FEATURES
        ),
        "transformed_features": (
            transformed_feature_names
        ),
        "transformed_feature_count": len(
            transformed_feature_names
        ),
        "training_rows": len(
            dataset.X_train
        ),
        "validation_rows": len(
            dataset.X_validation
        ),
        "test_rows": len(
            dataset.X_test
        ),
        "split_random_state": 42,
        "test_size": 0.20,
        "validation_size": 0.20,
        "compatible_ensemble": (
            ENSEMBLE_PATH.name
        ),
    }

    # Create the metadata directory if required.
    METADATA_PATH.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    # Save the preprocessor metadata as JSON.
    with METADATA_PATH.open(
        "w",
        encoding="utf-8",
    ) as output_file:
        json.dump(
            metadata,
            output_file,
            indent=2,
        )

    # Print the saved preprocessor summary.
    print(
        "Extended preprocessing transformer saved successfully."
    )
    print(
        "Raw features: "
        f"{len(EXTENDED_FEATURES)}"
    )
    print(
        "Transformed features: "
        f"{len(transformed_feature_names)}"
    )
    print(
        "Feature schema matches ensemble: True"
    )
    print(
        f"Transformer saved to: {TRANSFORMER_PATH}"
    )
    print(
        f"Metadata saved to: {METADATA_PATH}"
    )


if __name__ == "__main__":
    main()