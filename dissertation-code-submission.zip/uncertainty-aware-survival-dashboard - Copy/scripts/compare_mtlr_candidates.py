from __future__ import annotations

import json
from pathlib import Path

import numpy as np

from ml.evaluation import SurvivalModelEvaluator
from ml.mtlr_model import MTLRModel
from ml.preprocessing import (
    prepare_model_dataset,
    TransformedDatasetSplit,
)


# ---------------------------------------------------------------------------
# Project Paths
# ---------------------------------------------------------------------------

PROJECT_ROOT = Path(__file__).resolve().parents[1]

# Path used to save the MTLR candidate comparison report.
REPORT_PATH = (
    PROJECT_ROOT
    / "data"
    / "reports"
    / "mtlr_candidate_comparison.json"
)


# ---------------------------------------------------------------------------
# Candidate Configuration
# ---------------------------------------------------------------------------

# MTLR configurations included in the candidate comparison.
CANDIDATES = [
    {
        "name": "mtlr_10_bins",
        "number_of_bins": 10,
        "learning_rate": 0.01,
        "weight_decay": 0.001,
    },
    {
        "name": "mtlr_20_bins",
        "number_of_bins": 20,
        "learning_rate": 0.005,
        "weight_decay": 0.001,
    },
    {
        "name": "mtlr_30_bins",
        "number_of_bins": 30,
        "learning_rate": 0.001,
        "weight_decay": 0.001,
    },
]

# Training parameters shared across the candidate models.
MAX_EPOCHS = 1000
PATIENCE = 50
MINIMUM_IMPROVEMENT = 0.0001
RANDOM_STATE = 42

# Evaluation time points from 12 to 180 months.
EVALUATION_TIMES = np.arange(
    12.0,
    181.0,
    12.0,
)


# ---------------------------------------------------------------------------
# Candidate Evaluation
# ---------------------------------------------------------------------------

# Train and evaluate an MTLR candidate configuration.
def evaluate_candidate(
    dataset: TransformedDatasetSplit,
    configuration: dict[str, object],
) -> dict[str, object]:

    # Create the MTLR model using the candidate configuration.
    model = MTLRModel(
        number_of_bins=int(
            configuration["number_of_bins"]
        ),
        learning_rate=float(
            configuration["learning_rate"]
        ),
        epochs=MAX_EPOCHS,
        weight_decay=float(
            configuration["weight_decay"]
        ),
        random_state=RANDOM_STATE,
        patience=PATIENCE,
        minimum_improvement=MINIMUM_IMPROVEMENT,
    )

    # Fit the model using the training and validation datasets.
    model.fit(
        X=dataset.X_train,
        duration=dataset.duration_train,
        event=dataset.event_train,
        X_validation=dataset.X_validation,
        duration_validation=dataset.duration_validation,
        event_validation=dataset.event_validation,
    )

    # Generate survival predictions for the validation dataset.
    prediction = model.predict_survival(
        X=dataset.X_validation,
        time_points=EVALUATION_TIMES.tolist(),
    )

    # Evaluate the validation predictions.
    result = SurvivalModelEvaluator().evaluate(
        prediction=prediction,
        duration=dataset.duration_validation,
        event=dataset.event_validation,
        evaluation_times=EVALUATION_TIMES,
    )

    # Return the candidate configuration and validation results.
    return {
        "name": configuration["name"],
        "number_of_bins": configuration["number_of_bins"],
        "learning_rate": configuration["learning_rate"],
        "weight_decay": configuration["weight_decay"],
        "best_epoch": model.best_epoch,
        "stopped_early": model.stopped_early,
        "best_validation_loss": min(
            min(model.validation_losses)
            if model.validation_losses
            else None
        ),
        "validation_concordance_index": (
            result.concordance_index
        ),
        "validation_integrated_brier_score": (
            result.integrated_brier_score
        ),
    }


# ---------------------------------------------------------------------------
# Candidate Comparison
# ---------------------------------------------------------------------------

# Compare the MTLR candidate configurations on the validation dataset.
def main() -> None:

    # Prepare the extended training and validation datasets.
    dataset = prepare_model_dataset(
        model_type="extended",
        test_size=0.20,
        validation_size=0.20,
        random_state=RANDOM_STATE,
    )

    results = []

    # Train and evaluate each candidate configuration.
    for configuration in CANDIDATES:
        print(
            f"Evaluating {configuration['name']}..."
        )

        result = evaluate_candidate(
            dataset,
            configuration,
        )

        results.append(result)

        print(
            "  C-index: "
            f"{result['validation_concordance_index']:.3f}"
        )
        print(
            "  IBS: "
            f"{result['validation_integrated_brier_score']:.4f}"
        )
        print(
            "  Best epoch: "
            f"{result['best_epoch']}"
        )

    # Rank the candidate models by Integrated Brier Score.
    ranked_by_ibs = sorted(
        results,
        key=lambda item: float(
            item["validation_integrated_brier_score"]
        ),
    )

    # Create the candidate comparison report.
    report = {
        "selection_metric": (
            "validation_integrated_brier_score"
        ),
        "evaluation_times_months": (
            EVALUATION_TIMES.tolist()
        ),
        "selected_candidate": ranked_by_ibs[0],
        "results": results,
    }

    # Create the report directory if required.
    REPORT_PATH.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    # Save the candidate comparison report as JSON.
    with REPORT_PATH.open(
        "w",
        encoding="utf-8",
    ) as output_file:
        json.dump(
            report,
            output_file,
            indent=2,
        )

    selected = ranked_by_ibs[0]

    # Print the selected candidate and validation results.
    print("\nCandidate comparison complete.")
    print("-" * 48)
    print(
        "Selected candidate: "
        f"{selected['name']}"
    )
    print(
        "Validation IBS: "
        f"{selected['validation_integrated_brier_score']:.4f}"
    )
    print(
        "Validation C-index: "
        f"{selected['validation_concordance_index']:.3f}"
    )
    print(f"Report saved to: {REPORT_PATH}")


if __name__ == "__main__":
    main()