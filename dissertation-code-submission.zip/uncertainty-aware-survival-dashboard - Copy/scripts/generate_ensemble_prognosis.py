from __future__ import annotations

import json
from pathlib import Path

import numpy as np

from ml.ensemble_model import MTLREnsembleModel
from ml.preprocessing import prepare_model_dataset
from ml.prognosis import (
    calculate_uncertainty_thresholds,
    create_patient_prognosis,
)


# ---------------------------------------------------------------------------
# Project Paths
# ---------------------------------------------------------------------------

PROJECT_ROOT = Path(__file__).resolve().parents[1]

# Path to the trained MTLR ensemble model.
ENSEMBLE_PATH = (
    PROJECT_ROOT
    / "models"
    / "trained"
    / "mtlr_xcal_ensemble.pkl"
)

# Path used to save the sample prognosis response.
REPORT_PATH = (
    PROJECT_ROOT
    / "data"
    / "reports"
    / "sample_prognosis_response.json"
)


# ---------------------------------------------------------------------------
# Prediction Times
# ---------------------------------------------------------------------------

# Prediction time points from 6 to 240 months.
PREDICTION_TIMES = np.arange(
    6.0,
    241.0,
    6.0,
).tolist()


# ---------------------------------------------------------------------------
# Sample Ensemble Prognosis
# ---------------------------------------------------------------------------

# Generate an example patient prognosis using the final ensemble.
def main() -> None:

    # Prepare the extended validation dataset.
    dataset = prepare_model_dataset(
        model_type="extended",
        test_size=0.20,
        validation_size=0.20,
        random_state=42,
    )

    if not ENSEMBLE_PATH.exists():
        raise FileNotFoundError(
            f"Ensemble model not found: {ENSEMBLE_PATH}"
        )

    # Load the trained MTLR ensemble model.
    ensemble = MTLREnsembleModel.load(
        ENSEMBLE_PATH
    )

    # Generate predictions for the complete validation dataset.
    validation_prediction = ensemble.predict_survival(
        X=dataset.X_validation,
        time_points=PREDICTION_TIMES,
    )

    # Calculate uncertainty thresholds from the validation predictions.
    thresholds = calculate_uncertainty_thresholds(
        validation_prediction
    )

    # Select the first patient from the validation dataset.
    patient_features = dataset.X_validation.iloc[[0]]
    patient_index = patient_features.index[0]

    # Generate the survival prediction for the selected patient.
    patient_prediction = ensemble.predict_survival(
        X=patient_features,
        time_points=PREDICTION_TIMES,
    )

    # Create the patient prognosis.
    prognosis = create_patient_prognosis(
        prediction=patient_prediction,
        patient_index=patient_index,
        uncertainty_thresholds=thresholds,
    )

    # Create the sample prognosis response.
    output = {
        "model_name": prognosis.model_name,
        "patient_index": str(
            prognosis.patient_index
        ),
        "survival_estimates": {
            "one_year": {
                "probability": prognosis.one_year_survival,
                "percentage": prognosis.one_year_percentage(),
                "model_disagreement": (
                    prognosis.one_year_uncertainty
                ),
            },
            "three_year": {
                "probability": prognosis.three_year_survival,
                "percentage": prognosis.three_year_percentage(),
                "model_disagreement": (
                    prognosis.three_year_uncertainty
                ),
            },
            "five_year": {
                "probability": prognosis.five_year_survival,
                "percentage": prognosis.five_year_percentage(),
                "model_disagreement": (
                    prognosis.five_year_uncertainty
                ),
            },
        },
        "median_survival_months": (
            prognosis.median_survival_months
        ),
        "median_survival_years": (
            prognosis.median_survival_years()
        ),
        "overall_model_disagreement": (
            prognosis.uncertainty
        ),
        "model_disagreement_label": (
            prognosis.model_disagreement_label
        ),
        "uncertainty_thresholds": {
            "lower_threshold": (
                thresholds.lower_threshold
            ),
            "higher_threshold": (
                thresholds.higher_threshold
            ),
        },
        "patient_explanation": prognosis.explanation,
        "uncertainty_explanation": (
            prognosis.uncertainty_explanation
        ),
        "survival_curve": {
            f"{float(time):g}_months": float(probability)
            for time, probability
            in prognosis.survival_curve.items()
        },
        "limitations": [
            (
                "This is an anonymised validation example and is not "
                "a clinical assessment."
            ),
            (
                "Model disagreement measures variation between ensemble "
                "members and is not a statistical confidence interval."
            ),
            (
                "The model does not capture every source of prognostic "
                "uncertainty."
            ),
        ],
    }

    # Create the report directory if required.
    REPORT_PATH.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    # Save the sample prognosis response as JSON.
    with REPORT_PATH.open(
        "w",
        encoding="utf-8",
    ) as output_file:
        json.dump(
            output,
            output_file,
            indent=2,
        )

    # Print the sample prognosis summary.
    print("Example ensemble prognosis generated.")
    print(
        "1-year estimated survival: "
        f"{prognosis.one_year_percentage():.1f}%"
    )
    print(
        "3-year estimated survival: "
        f"{prognosis.three_year_percentage():.1f}%"
    )
    print(
        "5-year estimated survival: "
        f"{prognosis.five_year_percentage():.1f}%"
    )
    print(
        "Model disagreement label: "
        f"{prognosis.model_disagreement_label}"
    )
    print(
        "Overall model disagreement: "
        f"{prognosis.uncertainty:.4f}"
    )

    # Print the median survival estimate when it is available.
    if prognosis.median_survival_years() is None:
        print(
            "Median predicted survival was not reached "
            "within the displayed time horizon."
        )
    else:
        print(
            "Median predicted survival: "
            f"{prognosis.median_survival_years():.1f} years"
        )

    print(f"Report saved to: {REPORT_PATH}")


if __name__ == "__main__":
    main()