from __future__ import annotations

import json
from pathlib import Path

from ml.cox_model import CoxModel
from ml.preprocessing import prepare_model_dataset


# ---------------------------------------------------------------------------
# Project Paths
# ---------------------------------------------------------------------------

PROJECT_ROOT = Path(__file__).resolve().parents[1]

# Path used to save the trained extended Cox model.
MODEL_PATH = (
    PROJECT_ROOT
    / "models"
    / "trained"
    / "cox_extended.pkl"
)

# Path used to save the extended Cox model metadata.
METADATA_PATH = (
    PROJECT_ROOT
    / "models"
    / "metadata"
    / "cox_extended.json"
)


# ---------------------------------------------------------------------------
# Extended Cox Baseline
# ---------------------------------------------------------------------------

# Train and save the extended Cox baseline model.
def main() -> None:

    # Prepare the extended model dataset.
    dataset = prepare_model_dataset(
        model_type="extended",
        test_size=0.20,
        validation_size=0.20,
        random_state=42,
    )

    # Create the Cox model.
    model = CoxModel()

    # Fit the model using the training dataset.
    model.fit(
        X=dataset.X_train,
        duration=dataset.duration_train,
        event=dataset.event_train,
    )

    # Generate survival predictions for the validation dataset.
    validation_prediction = model.predict_survival(
        X=dataset.X_validation,
        time_points=[12.0, 36.0, 60.0],
    )

    # Save the trained Cox model.
    model.save(MODEL_PATH)

    # Create the metadata directory if required.
    METADATA_PATH.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    # Create the extended Cox model metadata.
    metadata = {
        "model_name": validation_prediction.model_name,
        "model_type": "extended",
        "training_rows": len(dataset.X_train),
        "validation_rows": len(dataset.X_validation),
        "test_rows": len(dataset.X_test),
        "transformed_feature_count": dataset.X_train.shape[1],
        "prediction_times_months": [12.0, 36.0, 60.0],
        "validation_prediction_count": (
            validation_prediction.patient_count()
        ),
        "training_event_fraction": float(
            dataset.event_train.mean()
        ),
        "validation_event_fraction": float(
            dataset.event_validation.mean()
        ),
        "test_event_fraction": float(
            dataset.event_test.mean()
        ),
    }

    # Save the model metadata as JSON.
    with METADATA_PATH.open(
        "w",
        encoding="utf-8",
    ) as output_file:
        json.dump(
            metadata,
            output_file,
            indent=2,
        )

    # Print the training summary.
    print("Extended Cox baseline trained successfully.")
    print(f"Training rows: {len(dataset.X_train)}")
    print(f"Validation rows: {len(dataset.X_validation)}")
    print(f"Test rows: {len(dataset.X_test)}")
    print(
        "Transformed features: "
        f"{dataset.X_train.shape[1]}"
    )
    print(
        "Validation predictions: "
        f"{validation_prediction.patient_count()}"
    )
    print(f"Model saved to: {MODEL_PATH}")
    print(f"Metadata saved to: {METADATA_PATH}")


if __name__ == "__main__":
    main()