from __future__ import annotations

import json
from pathlib import Path

import numpy as np

from ml.evaluation import SurvivalModelEvaluator
from ml.calibration import calculate_uncensored_d_calibration
from ml.mtlr_model import MTLRModel
from ml.preprocessing import prepare_model_dataset


# ---------------------------------------------------------------------------
# Project Paths
# ---------------------------------------------------------------------------

PROJECT_ROOT = Path(__file__).resolve().parents[1]

# Path to the trained extended MTLR model.
MODEL_PATH = (
    PROJECT_ROOT
    / "models"
    / "trained"
    / "mtlr_extended.pkl"
)

# Path used to save the MTLR calibration report.
REPORT_PATH = (
    PROJECT_ROOT
    / "data"
    / "reports"
    / "mtlr_extended_calibration.json"
)


# ---------------------------------------------------------------------------
# Evaluation Times
# ---------------------------------------------------------------------------

# Evaluation time points from 6 to 240 months.
EVALUATION_TIMES = np.arange(
    6.0,
    241.0,
    6.0,
)


# ---------------------------------------------------------------------------
# MTLR Calibration Evaluation
# ---------------------------------------------------------------------------

# Evaluate the extended MTLR model on the validation dataset.
def main() -> None:

    # Prepare the extended validation dataset.
    dataset = prepare_model_dataset(
        model_type="extended",
        test_size=0.20,
        validation_size=0.20,
        random_state=42,
    )

    if not MODEL_PATH.exists():
        raise FileNotFoundError(
            f"Trained MTLR model not found: {MODEL_PATH}"
        )

    # Load the trained extended MTLR model.
    model = MTLRModel.load(MODEL_PATH)

    # Generate survival predictions across the evaluation time points.
    prediction = model.predict_survival(
        X=dataset.X_validation,
        time_points=EVALUATION_TIMES.tolist(),
    )

    # Evaluate the validation survival predictions.
    evaluation = SurvivalModelEvaluator().evaluate(
        prediction=prediction,
        duration=dataset.duration_validation,
        event=dataset.event_validation,
        evaluation_times=EVALUATION_TIMES,
    )

    # Calculate uncensored D-calibration.
    d_calibration = calculate_uncensored_d_calibration(
        prediction=prediction,
        duration=dataset.duration_validation,
        event=dataset.event_validation,
        number_of_bins=10,
    )

    # Create the MTLR calibration report.
    report = {
        "model": "extended_mtlr",
        "dataset_partition": "validation",
        "validation_rows": len(dataset.X_validation),
        "event_count": int(
            dataset.event_validation.sum()
        ),
        "censored_count": int(
            (dataset.event_validation == 0).sum()
        ),
        "evaluation_times_months": (
            EVALUATION_TIMES.tolist()
        ),
        "concordance_index": (
            evaluation.concordance_index
        ),
        "integrated_brier_score": (
            evaluation.integrated_brier_score
        ),
        "uncensored_d_calibration": d_calibration,
        "limitations": [
            (
                "This baseline D-calibration calculation includes "
                "uncensored observations only."
            ),
            (
                "It must not be treated as the final censoring-adjusted "
                "calibration result."
            ),
        ],
    }

    # Create the report directory if required.
    REPORT_PATH.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    # Save the calibration report as JSON.
    with REPORT_PATH.open(
        "w",
        encoding="utf-8",
    ) as output_file:
        json.dump(
            report,
            output_file,
            indent=2,
        )

    # Print the MTLR calibration results.
    print("Extended MTLR calibration assessment")
    print("-" * 48)

    print(
        "Validation C-index: "
        f"{evaluation.concordance_index:.3f}"
    )

    print(
        "Validation IBS: "
        f"{evaluation.integrated_brier_score:.4f}"
    )

    print(
        "Uncensored D-calibration count: "
        f"{d_calibration['uncensored_count']}"
    )

    print(
        "D-calibration chi-square: "
        f"{d_calibration['chi_square_statistic']:.3f}"
    )

    print(
        "D-calibration p-value: "
        f"{d_calibration['p_value']:.4f}"
    )

    print(
        "Passes at 0.05: "
        f"{d_calibration['passes_at_0_05']}"
    )

    print(
        "Observed probability-bin counts: "
        f"{d_calibration['observed_counts']}"
    )

    print(f"\nReport saved to: {REPORT_PATH}")


if __name__ == "__main__":
    main()