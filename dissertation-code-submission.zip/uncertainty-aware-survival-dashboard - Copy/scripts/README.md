audit_metabric.py/
Audits the METABRIC dataset and reports its structure, variables, 
missing values, and survival outcome information.

compare_baseline_models.py/
Compares the validation performance of the baseline Cox and MTLR survival 
models.

compare_cox_models.py/
Compares the clinical and extended Cox models to assess their validation 
performance.

compare_mtlr_calibration.py/
Compares the calibration results of the extended MTLR model before and 
after X-CAL regularisation.

compare_mtlr_candidates.py/
Compares candidate MTLR models to support selection of the model 
configuration used in subsequent development.

evaluate_ensemble_uncertainty.py/
Evaluates ensemble disagreement and its relationship with prediction 
error across the selected survival horizons.

evaluate_mtlr_calibration.py/
Evaluates the calibration of MTLR survival predictions using the project’s 
calibration metrics.

final_test_evaluation.py/
Evaluates the final selected models on the previously unseen held-out test 
set, including discrimination, prediction error, calibration and ensemble 
disagreement.

generate_ensemble_prognosis.py/
Generates patient-level prognosis outputs from the trained MTLR ensemble 
model.

generate_example_prognosis.py/
Generates an example patient prognosis using the trained survival 
prediction framework.

generate_kaplan_meier.py/
Generates the Kaplan-Meier overall survival analysis and corresponding 
output figure.

generate_metabric_dictionary.py/
Generates a data dictionary describing the METABRIC variables used by the 
project.

inspect_preprocessor_categories.py/
Inspects the categorical feature levels stored by the fitted preprocessing 
pipeline.

save_ensemble_uncertainty_thresholds.py/
Calculates and saves the ensemble disagreement thresholds used to 
categorise patient-level model disagreement.

save_extended_preprocessor.py/
Fits and saves the extended-feature preprocessing pipeline used for model 
inference.

train_cox_baseline.py/
Trains and saves the baseline Cox model using the clinical feature set.

train_cox_extended.py/
Trains and saves the extended Cox model using the extended feature set.

train_mtlr_baseline.py/
Trains and saves the baseline MTLR model using the clinical feature set.

train_mtlr_ensemble.py/
Trains and saves the MTLR ensemble used to generate survival predictions 
and model disagreement estimates.

train_mtlr_extended.py/
Trains and saves the extended MTLR model using the extended feature set.

train_mtlr_xcal.py/
Trains and saves the extended MTLR model with X-CAL regularisation.

tune_mtlr_extended.py/
Tunes the hyperparameters of the extended MTLR model and records the 
candidate model results.

tune_xcal_weight.py/
Tunes the X-CAL regularisation weight used during MTLR training.

validate_preprocessing.py/
Validates the preprocessing pipeline and checks the transformed datasets 
and feature structure.