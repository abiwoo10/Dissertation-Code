from __future__ import annotations

import json
from pathlib import Path

from ml.evaluation import SurvivalModelEvaluator
from ml.mtlr_model import MTLRModel
from ml.preprocessing import prepare_model_dataset


# ---------------------------------------------------------------------------
# Project Paths
# ---------------------------------------------------------------------------

PROJECT_ROOT = Path(__file__).resolve().parents[1]

MODEL_TYPE = "clinical"

# Path used to save the trained clinical MTLR model.
MODEL_PATH = (
    PROJECT_ROOT
    / "models"
    / "trained"
    / "mtlr_clinical.pkl"
)

# Path used to save the clinical MTLR model metadata.
METADATA_PATH = (
    PROJECT_ROOT
    / "models"
    / "metadata"
    / "mtlr_clinical.json"
)


# ---------------------------------------------------------------------------
# Prediction Times
# ---------------------------------------------------------------------------

# Prediction time points used for validation.
PREDICTION_TIMES_MONTHS = [
    12.0,
    36.0,
    60.0,
]


# ---------------------------------------------------------------------------
# Clinical MTLR Baseline
# ---------------------------------------------------------------------------

# Train, evaluate, and save the clinical MTLR baseline model.
def main() -> None:

    # Prepare the clinical model dataset.
    dataset = prepare_model_dataset(
        model_type=MODEL_TYPE,
        test_size=0.20,
        validation_size=0.20,
        random_state=42,
    )

    # Create the MTLR model.
    model = MTLRModel(
        number_of_bins=20,
        learning_rate=0.01,
        epochs=1000,
        weight_decay=0.0001,
        random_state=42,
        patience=50,
        minimum_improvement=0.0001,
    )

    print("Training clinical MTLR model...")

    # Fit the model using the training and validation datasets.
    model.fit(
        X=dataset.X_train,
        duration=dataset.duration_train,
        event=dataset.event_train,
        X_validation=dataset.X_validation,
        duration_validation=dataset.duration_validation,
        event_validation=dataset.event_validation,
    )

    # Generate survival predictions for the validation dataset.
    validation_prediction = model.predict_survival(
        X=dataset.X_validation,
        time_points=PREDICTION_TIMES_MONTHS,
    )

    # Create the survival model evaluator.
    evaluator = SurvivalModelEvaluator()

    # Evaluate the validation predictions.
    validation_result = evaluator.evaluate(
        prediction=validation_prediction,
        duration=dataset.duration_validation,
        event=dataset.event_validation,
    )

    # Save the trained MTLR model.
    model.save(MODEL_PATH)

    # Create the metadata directory if required.
    METADATA_PATH.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    # Get the final training loss when available.
    final_training_loss = (
        model.training_losses[-1]
        if model.training_losses
        else None
    )

    # Create the clinical MTLR model metadata.
    metadata = {
        "model_name": validation_prediction.model_name,
        "model_type": MODEL_TYPE,
        "training_rows": len(dataset.X_train),
        "validation_rows": len(dataset.X_validation),
        "test_rows": len(dataset.X_test),
        "transformed_feature_count": dataset.X_train.shape[1],
        "number_of_bins_requested": model.number_of_bins,
        "number_of_time_boundaries": (
            len(model.time_bins)
            if model.time_bins is not None
            else None
        ),
        "learning_rate": model.learning_rate,
        "epochs": model.epochs,
        "weight_decay": model.weight_decay,
        "random_state": model.random_state,
        "prediction_times_months": PREDICTION_TIMES_MONTHS,
        "validation_prediction_count": (
            validation_prediction.patient_count()
        ),
        "validation_concordance_index": (
            validation_result.concordance_index
        ),
        "initial_training_loss": (
            model.training_losses[0]
            if model.training_losses
            else None
        ),
        "final_training_loss": final_training_loss,
        "training_event_fraction": float(
            dataset.event_train.mean()
        ),
        "validation_event_fraction": float(
            dataset.event_validation.mean()
        ),
        "test_event_fraction": float(
            dataset.event_test.mean()
        ),
        "best_epoch": model.best_epoch,
        "stopped_early": model.stopped_early,
        "final_validation_loss": (
            model.validation_losses[-1]
            if model.validation_losses
            else None
        ),
        "best_validation_loss": (
            min(model.validation_losses)
            if model.validation_losses
            else None
        ),
    }

    # Save the model metadata as JSON.
    with METADATA_PATH.open(
        "w",
        encoding="utf-8",
    ) as output_file:
        json.dump(
            metadata,
            output_file,
            indent=2,
        )

    # Print the training and validation summary.
    print("\nClinical MTLR baseline trained successfully.")
    print(f"Training rows: {len(dataset.X_train)}")
    print(f"Validation rows: {len(dataset.X_validation)}")
    print(f"Test rows: {len(dataset.X_test)}")
    print(
        "Transformed features: "
        f"{dataset.X_train.shape[1]}"
    )
    print(
        "Time boundaries: "
        f"{len(model.time_bins)}"
    )
    print(
        "Initial training loss: "
        f"{model.training_losses[0]:.4f}"
    )
    print(
        "Final training loss: "
        f"{model.training_losses[-1]:.4f}"
    )
    print(
        "Validation C-index: "
        f"{validation_result.concordance_index:.3f}"
    )
    print(f"Best epoch: {model.best_epoch}")
    print(f"Stopped early: {model.stopped_early}")

    # Print the best validation loss when available.
    if model.validation_losses:
        print(
            "Best validation loss: "
            f"{min(model.validation_losses):.4f}"
        )

    print(f"Model saved to: {MODEL_PATH}")
    print(f"Metadata saved to: {METADATA_PATH}")


if __name__ == "__main__":
    main()