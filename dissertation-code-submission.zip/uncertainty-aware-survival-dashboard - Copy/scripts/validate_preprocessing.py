from __future__ import annotations

from ml.preprocessing import prepare_model_dataset


# ---------------------------------------------------------------------------
# Model Preprocessing Summary
# ---------------------------------------------------------------------------

# Summarise the prepared dataset for a model type.
def summarise_model(model_type: str) -> None:

    # Prepare the model dataset.
    result = prepare_model_dataset(
        model_type=model_type,
        test_size=0.20,
        validation_size=0.20,
        random_state=42,
    )

    # Print the dataset summary.
    print(f"\n{model_type.upper()} MODEL")
    print("-" * 40)

    print(f"Training rows: {len(result.X_train)}")
    print(f"Validation rows: {len(result.X_validation)}")
    print(f"Test rows: {len(result.X_test)}")

    print(f"Transformed features: {result.X_train.shape[1]}")

    print(
        "Training event fraction: "
        f"{result.event_train.mean():.3f}"
    )
    print(
        "Validation event fraction: "
        f"{result.event_validation.mean():.3f}"
    )
    print(
        "Test event fraction: "
        f"{result.event_test.mean():.3f}"
    )

    print(
        "Missing values in training data: "
        f"{int(result.X_train.isna().sum().sum())}"
    )
    print(
        "Missing values in validation data: "
        f"{int(result.X_validation.isna().sum().sum())}"
    )
    print(
        "Missing values in test data: "
        f"{int(result.X_test.isna().sum().sum())}"
    )

    # Print the transformed feature names.
    print("\nTransformed feature names:")

    for feature_name in result.X_train.columns:
        print(f"  - {feature_name}")


# ---------------------------------------------------------------------------
# Preprocessing Validation
# ---------------------------------------------------------------------------

# Summarise preprocessing for the clinical and extended models.
def main() -> None:
    summarise_model("clinical")
    summarise_model("extended")


if __name__ == "__main__":
    main()