import { useEffect, useState } from "react";

import { fetchHealthStatus } from "../services/healthApi";
import type { HealthResponse } from "../types/health";


// ---------------------------------------------------------------------------
// Health State
// ---------------------------------------------------------------------------

// Define the loading, ready, and error states for the health request.
export type HealthState =
    | {
    state: "loading";
    data: null;
    error: null;
}
    | {
    state: "ready";
    data: HealthResponse;
    error: null;
}
    | {
    state: "error";
    data: null;
    error: string;
};


// ---------------------------------------------------------------------------
// Health Status Hook
// ---------------------------------------------------------------------------

// Fetch and manage the current prediction API health status.
export function useHealthStatus(): HealthState {
    const [healthState, setHealthState] =
        useState<HealthState>({
            state: "loading",
            data: null,
            error: null,
        });

    useEffect(() => {
        // Create a controller to cancel the request when the hook unmounts.
        const controller = new AbortController();

        // Load the current health status from the prediction API.
        async function loadHealthStatus() {
            try {
                const data = await fetchHealthStatus(
                    controller.signal,
                );

                setHealthState({
                    state: "ready",
                    data,
                    error: null,
                });
            } catch (error) {
                // Ignore errors caused by an intentionally aborted request.
                if (controller.signal.aborted) {
                    return;
                }

                setHealthState({
                    state: "error",
                    data: null,
                    error:
                        error instanceof Error
                            ? error.message
                            : "Unable to contact the prediction API.",
                });
            }
        }

        void loadHealthStatus();

        // Cancel the health request when the effect is cleaned up.
        return () => {
            controller.abort();
        };
    }, []);

    return healthState;
}