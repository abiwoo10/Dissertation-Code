useHealthStatus.ts/
Provides a reusable React hook for checking and managing the current health 
status of the prediction API.

usePrognosis.ts/
Provides a reusable React hook for requesting patient-specific prognosis 
results and managing the associated loading and error states.

useTheme.ts/
Provides a reusable React hook for managing the application theme and 
switching between light and dark modes.