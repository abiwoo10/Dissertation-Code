import { useCallback, useRef, useState } from "react";

import { requestPrognosis } from "../services/prognosisApi";
import type { PatientData } from "../types/patient";
import type { PrognosisResponse } from "../types/prognosis";


// ---------------------------------------------------------------------------
// Prognosis Hook
// ---------------------------------------------------------------------------

// Generate and manage patient-specific prognosis requests.
export function usePrognosis() {
    const [data, setData] = useState<PrognosisResponse | null>(null);
    const [error, setError] = useState<string | null>(null);
    const [isLoading, setIsLoading] = useState(false);

    // Store the controller for the current prognosis request.
    const controllerRef = useRef<AbortController | null>(null);

    // Request a prognosis for the supplied patient data.
    const generatePrognosis = useCallback(
        async (patient: PatientData) => {
            // Cancel any existing prognosis request.
            controllerRef.current?.abort();

            const controller = new AbortController();
            controllerRef.current = controller;

            // Reset the request state before generating a new prognosis.
            setIsLoading(true);
            setError(null);
            setData(null);

            try {
                const prognosis = await requestPrognosis(
                    patient,
                    controller.signal,
                );

                setData(prognosis);

                return prognosis;
            } catch (error) {
                // Ignore errors caused by an intentionally aborted request.
                if (
                    error instanceof DOMException
                    && error.name === "AbortError"
                ) {
                    return null;
                }

                const message =
                    error instanceof Error
                        ? error.message
                        : "Unable to generate prognosis.";

                setError(message);
                return null;
            } finally {
                // Clear the loading state for the current request.
                if (controllerRef.current === controller) {
                    setIsLoading(false);
                }
            }
        },
        [],
    );

    return {
        data,
        error,
        isLoading,
        generatePrognosis,
    };
}