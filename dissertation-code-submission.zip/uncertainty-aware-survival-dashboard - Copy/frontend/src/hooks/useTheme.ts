import { useEffect, useState } from "react";


// ---------------------------------------------------------------------------
// Theme Configuration
// ---------------------------------------------------------------------------

// Define the available dashboard themes.
export type Theme = "light" | "dark";

// Define the local storage key used to persist the selected theme.
const STORAGE_KEY = "survival-dashboard-theme";


// ---------------------------------------------------------------------------
// Initial Theme
// ---------------------------------------------------------------------------

// Load the stored theme or use the system colour scheme preference.
function getInitialTheme(): Theme {
    const storedTheme = localStorage.getItem(STORAGE_KEY);

    if (storedTheme === "light" || storedTheme === "dark") {
        return storedTheme;
    }

    return window.matchMedia("(prefers-color-scheme: dark)").matches
        ? "dark"
        : "light";
}


// ---------------------------------------------------------------------------
// Theme Hook
// ---------------------------------------------------------------------------

// Manage and persist the dashboard theme.
export function useTheme() {
    const [theme, setTheme] = useState<Theme>(getInitialTheme);

    // Apply the selected theme and save it to local storage.
    useEffect(() => {
        document.documentElement.dataset.theme = theme;
        localStorage.setItem(STORAGE_KEY, theme);
    }, [theme]);

    // Switch between the light and dark themes.
    function toggleTheme() {
        setTheme((currentTheme) =>
            currentTheme === "light" ? "dark" : "light",
        );
    }

    return {
        theme,
        toggleTheme,
    };
}