import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { BrowserRouter } from "react-router";

import App from "./App";

import "./styles/reset.css";
import "./styles/variables.css";
import "./styles/global.css";
import "./styles/utilities.css";


// ---------------------------------------------------------------------------
// Application Root
// ---------------------------------------------------------------------------

// Locate the root HTML element used to mount the React application.
const rootElement = document.getElementById("root");

// Prevent application startup when the required root element is unavailable.
if (!rootElement) {
    throw new Error("Root element was not found.");
}


// ---------------------------------------------------------------------------
// Application Rendering
// ---------------------------------------------------------------------------

// Render the application with strict mode checks and client-side routing.
createRoot(rootElement).render(
    <StrictMode>
        <BrowserRouter>
            <App />
        </BrowserRouter>
    </StrictMode>,
);