import { Link, Navigate, useLocation } from "react-router";

import DisagreementPanel from "../../components/prognosis/DisagreementPanel";
import MedianSurvivalCard from "../../components/prognosis/MedianSurvivalCard";
import SurvivalMetricCard from "../../components/prognosis/SurvivalMetricCard";
import PatientProgress from "../../components/forms/PatientProgress";

import type { PatientData } from "../../types/patient";
import type { PrognosisResponse } from "../../types/prognosis";

import {
    clearPrognosisResult,
    loadPrognosisResult,
    type StoredPrognosis,
} from "../../services/prognosisStorage";

import styles from "./PrognosisPage.module.css";


// ---------------------------------------------------------------------------
// Prognosis Location State
// ---------------------------------------------------------------------------

// Define the patient and prognosis passed through route state.
interface PrognosisLocationState {
    patient: PatientData;
    prognosis: PrognosisResponse;
}


// ---------------------------------------------------------------------------
// Prognosis Page
// ---------------------------------------------------------------------------

// Display the summary of the generated patient-specific prognosis.
function PrognosisPage() {
    const location = useLocation();

    // Load the prognosis from route state or saved storage.
    const state: StoredPrognosis | null =
        (location.state as PrognosisLocationState | null)
        ?? loadPrognosisResult();

    // Return to patient input when no prognosis is available.
    if (!state) {
        return (
            <Navigate
                to="/patient"
                replace
            />
        );
    }

    const { patient, prognosis } = state;

    // Clear the saved prognosis when restarting the workflow.
    function handleStartAgain() {
        clearPrognosisResult();
    }

    return (
        <div className={`${styles.page} page-container`}>
            <PatientProgress currentStep={5} />

            {/* Introduce the generated patient-specific prognosis. */}
            <p className="eyebrow">
                Step 5 of 5
            </p>

            <h1>
                Patient-specific prognosis
            </h1>

            <p className={styles.introduction}>
                Prediction generated using the {prognosis.model_name}.
            </p>

            {/* Display navigation between prognosis result sections. */}
            <nav
                className={styles.resultNavigation}
                aria-label="Prognosis result sections"
            >
                <Link
                    className={`${styles.resultNavigationLink} ${styles.resultNavigationLinkActive}`}
                    to="/prognosis"
                    aria-current="page"
                >
                    Summary
                </Link>

                <Link
                    className={styles.resultNavigationLink}
                    to="/prognosis/details"
                >
                    Detailed analysis
                </Link>
            </nav>

            {/* Display the patient characteristics for this prognosis. */}
            <section
                className={styles.patientSummary}
                aria-labelledby="patient-summary-heading"
            >
                <div>
                    <h2 id="patient-summary-heading">
                        Patient summary
                    </h2>

                    <p>
                        Age {patient.age_at_diagnosis}, stage{" "}
                        {patient.tumor_stage}, grade {patient.grade}, ER{" "}
                        {patient.er_status.toLowerCase()}, HER2{" "}
                        {patient.her2_status.toLowerCase()}.
                    </p>
                </div>
            </section>

            {/* Display the fixed-horizon survival estimates. */}
            <section aria-labelledby="survival-estimates-heading">
                <p className="eyebrow">
                    Predicted outcomes
                </p>

                <h2 id="survival-estimates-heading">
                    Survival estimates
                </h2>

                <div className={styles.summaryGrid}>
                    <SurvivalMetricCard
                        label="1-year survival"
                        estimate={prognosis.one_year}
                    />

                    <SurvivalMetricCard
                        label="3-year survival"
                        estimate={prognosis.three_year}
                    />

                    <SurvivalMetricCard
                        label="5-year survival"
                        estimate={prognosis.five_year}
                    />
                </div>
            </section>

            {/* Display the median survival and model disagreement summaries. */}
            <div className={styles.summaryContentGrid}>
                <MedianSurvivalCard prognosis={prognosis} />

                <DisagreementPanel prognosis={prognosis} />
            </div>

            {/* Display the patient-specific prognosis interpretation. */}
            <section className={styles.interpretationPanel}>
                <p className="eyebrow">
                    Interpretation
                </p>

                <h2>
                    How to interpret this prognosis
                </h2>

                <p>
                    {prognosis.patient_explanation}
                </p>
            </section>

            {/* Display navigation to the detailed prognosis analysis. */}
            <div className={styles.pageNavigation}>
                <Link
                    className="button button--primary"
                    to="/prognosis/details"
                >
                    View detailed analysis
                </Link>
            </div>

            {/* Display options to edit the patient or restart the workflow. */}
            <div className={styles.actions}>
                <Link
                    className="button button--secondary"
                    to="/patient"
                >
                    Edit patient details
                </Link>

                <Link
                    className="button button--primary"
                    to="/"
                    onClick={handleStartAgain}
                >
                    Start again
                </Link>
            </div>
        </div>
    );
}

export default PrognosisPage;