PrognosisPage.module.css/
Defines the page-specific styling and responsive layout for the prognosis 
summary page.

PrognosisPage.tsx/
Displays the patient-specific prognosis summary, including fixed-time 
survival estimates, median survival, model disagreement, and interpretation.