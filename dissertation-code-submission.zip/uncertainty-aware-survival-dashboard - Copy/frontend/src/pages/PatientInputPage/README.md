PatientInputPage.module.css/
Defines the page-specific styling and layout for the patient input workflow.

PatientInputPage.tsx/
Manages the multi-step patient input workflow, including data entry, 
validation, review, and prognosis generation.