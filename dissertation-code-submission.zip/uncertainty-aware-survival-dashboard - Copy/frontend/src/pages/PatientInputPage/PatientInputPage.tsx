import PatientForm from "../../components/forms/PatientForm";

import styles from "./PatientInputPage.module.css";


// ---------------------------------------------------------------------------
// Patient Input Page
// ---------------------------------------------------------------------------

// Display the patient characteristics form for prognosis generation.
function PatientInputPage() {
    return (
        <div className={`${styles.page} page-container`}>
            {/* Introduce the patient input workflow. */}
            <h1>Patient characteristics</h1>

            <p className={styles.introduction}>
                Complete the four-stage form to generate an uncertainty-aware
                patient-specific survival prognosis.
            </p>

            {/* Display the patient input form. */}
            <PatientForm />
        </div>
    );
}

export default PatientInputPage;