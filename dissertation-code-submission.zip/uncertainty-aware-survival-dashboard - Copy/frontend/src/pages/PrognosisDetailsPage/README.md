PrognosisDetailsPage.module.css/
Defines the page-specific styling and responsive layout for the detailed 
prognosis page.

PrognosisDetailsPage.tsx/
Displays the detailed prognosis analysis, including the predicted survival 
curve, model disagreement, and additional interpretation.