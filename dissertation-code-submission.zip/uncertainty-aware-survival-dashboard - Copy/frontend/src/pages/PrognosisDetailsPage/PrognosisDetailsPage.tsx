import { Link, Navigate, useLocation } from "react-router";

import PatientProgress from "../../components/forms/PatientProgress";
import LimitationsPanel from "../../components/prognosis/LimitationsPanel";
import SurvivalCurve from "../../components/prognosis/SurvivalCurve";

import type { PatientData } from "../../types/patient";
import type { PrognosisResponse } from "../../types/prognosis";

import {
    clearPrognosisResult,
    loadPrognosisResult,
    type StoredPrognosis,
} from "../../services/prognosisStorage";

import styles from "./PrognosisDetailsPage.module.css";


// ---------------------------------------------------------------------------
// Prognosis Location State
// ---------------------------------------------------------------------------

// Define the patient and prognosis passed through route state.
interface PrognosisLocationState {
    patient: PatientData;
    prognosis: PrognosisResponse;
}


// ---------------------------------------------------------------------------
// Prognosis Details Page
// ---------------------------------------------------------------------------

// Display the detailed prognosis analysis and model information.
function PrognosisDetailsPage() {
    const location = useLocation();

    // Load the prognosis from route state or saved storage.
    const state: StoredPrognosis | null =
        (location.state as PrognosisLocationState | null)
        ?? loadPrognosisResult();

    // Return to patient input when no prognosis is available.
    if (!state) {
        return (
            <Navigate
                to="/patient"
                replace
            />
        );
    }

    const { patient, prognosis } = state;

    // Clear the saved prognosis when restarting the workflow.
    function handleStartAgain() {
        clearPrognosisResult();
    }

    return (
        <div className={`${styles.page} page-container`}>
            <PatientProgress currentStep={5} />

            {/* Introduce the detailed prognosis analysis. */}
            <p className="eyebrow">
                Step 5 of 5
            </p>

            <h1>
                Detailed prognosis analysis
            </h1>

            <p className={styles.introduction}>
                Explore the full survival distribution, ensemble disagreement,
                and limitations for this prognosis.
            </p>

            {/* Display navigation between prognosis result sections. */}
            <nav
                className={styles.resultNavigation}
                aria-label="Prognosis result sections"
            >
                <Link
                    className={styles.resultNavigationLink}
                    to="/prognosis"
                >
                    Summary
                </Link>

                <Link
                    className={`${styles.resultNavigationLink} ${styles.resultNavigationLinkActive}`}
                    to="/prognosis/details"
                    aria-current="page"
                >
                    Detailed analysis
                </Link>
            </nav>

            {/* Display the patient characteristics for this prognosis. */}
            <section
                className={styles.patientSummary}
                aria-labelledby="details-patient-summary-heading"
            >
                <h2 id="details-patient-summary-heading">
                    Patient context
                </h2>

                <p>
                    Age {patient.age_at_diagnosis}, stage{" "}
                    {patient.tumor_stage}, grade {patient.grade}, ER{" "}
                    {patient.er_status.toLowerCase()}, HER2{" "}
                    {patient.her2_status.toLowerCase()}.
                </p>
            </section>

            <SurvivalCurve prognosis={prognosis} />

            {/* Display the detailed model uncertainty information. */}
            <section
                className={styles.technicalContext}
                aria-labelledby="technical-context-heading"
            >
                <p className="eyebrow">
                    Model context
                </p>

                <h2 id="technical-context-heading">
                    Detailed uncertainty interpretation
                </h2>

                <p>
                    {prognosis.uncertainty_explanation}
                </p>

                {prognosis.overall_model_disagreement != null && (
                    <p>
                        Overall ensemble disagreement:{" "}
                        <strong>
                            {prognosis.overall_model_disagreement.toFixed(4)}
                        </strong>
                    </p>
                )}
            </section>

            <LimitationsPanel prognosis={prognosis} />

            {/* Display navigation back to the prognosis summary. */}
            <div className={styles.pageNavigation}>
                <Link
                    className="button button--secondary"
                    to="/prognosis"
                >
                    Back to summary
                </Link>
            </div>

            {/* Display options to edit the patient or restart the workflow. */}
            <div className={styles.actions}>
                <Link
                    className="button button--secondary"
                    to="/patient"
                >
                    Edit patient details
                </Link>

                <Link
                    className="button button--primary"
                    to="/"
                    onClick={handleStartAgain}
                >
                    Start again
                </Link>
            </div>
        </div>
    );
}

export default PrognosisDetailsPage;