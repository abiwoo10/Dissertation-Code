HomePage.module.css
Defines the page-specific styling and responsive layout for the home page.

HomePage.tsx
Displays the application landing page and introduces the survival 
prognosis workflow and its main features.