AboutPage.module.css/
Defines the page-specific styling and responsive layout for the About page.

AboutPage.tsx/
Displays information about the project, its prediction approach, 
intended use, and important limitations.