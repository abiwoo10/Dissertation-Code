import { Link } from "react-router";

import styles from "./AboutPage.module.css";


// ---------------------------------------------------------------------------
// About Page
// ---------------------------------------------------------------------------

// Display information about the model, evaluation, and intended use.
function AboutPage() {
    return (
        <div className={`${styles.page} page-container`}>
            {/* Introduce the model and purpose of the dashboard. */}
            <header className={styles.header}>
                <p className="eyebrow">
                    Transparency
                </p>

                <h1>
                    About the model and its intended use
                </h1>

                <p className={styles.introduction}>
                    This dashboard is a research prototype for exploring
                    patient-specific breast cancer survival estimates alongside
                    model disagreement and explicit limitations.
                </p>
            </header>

            {/* Display the intended-use warning. */}
            <section
                className={styles.warning}
                aria-labelledby="intended-use-heading"
            >
                <h2 id="intended-use-heading">
                    Intended use
                </h2>

                <p>
                    The application is designed for research demonstration and
                    evaluation only. It is not a medical device, does not provide
                    treatment recommendations, and must not be used for clinical
                    decision-making.
                </p>
            </section>

            {/* Display the main model and dataset information. */}
            <div className={styles.contentGrid}>
                <article className={styles.card}>
                    <p className="eyebrow">
                        Data source
                    </p>

                    <h2>
                        METABRIC cohort
                    </h2>

                    <p>
                        The model was developed using the METABRIC breast cancer
                        dataset, which contains clinical, pathological, and molecular
                        variables together with long-term survival outcomes.
                    </p>

                    <p>
                        The final extended feature set includes patient age, tumour
                        characteristics, receptor status, histological subtype,
                        integrative cluster, and tumour mutational burden.
                    </p>
                </article>

                <article className={styles.card}>
                    <p className="eyebrow">
                        Survival modelling
                    </p>

                    <h2>
                        Multi-Task Logistic Regression
                    </h2>

                    <p>
                        Multi-Task Logistic Regression, or MTLR, estimates a complete
                        individual survival distribution across a sequence of time
                        intervals rather than returning only a single risk score.
                    </p>

                    <p>
                        This supports presentation of fixed-horizon probabilities and
                        a continuous survival curve for each patient.
                    </p>
                </article>

                <article className={styles.card}>
                    <p className="eyebrow">
                        Calibration
                    </p>

                    <h2>
                        X-CAL regularisation
                    </h2>

                    <p>
                        X-CAL was incorporated during training as a calibration-aware
                        regularisation term. The objective was to improve agreement
                        between predicted survival probabilities and observed outcomes
                        while preserving discrimination.
                    </p>
                </article>

                <article className={styles.card}>
                    <p className="eyebrow">
                        Predictive uncertainty
                    </p>

                    <h2>
                        Deep ensemble disagreement
                    </h2>

                    <p>
                        The deployed model is an ensemble of independently trained
                        X-CAL MTLR models. Variation between member predictions is used
                        as a model-disagreement signal.
                    </p>

                    <p>
                        This signal is not a statistical confidence interval and does
                        not represent every source of clinical uncertainty.
                    </p>
                </article>
            </div>

            {/* Summarise the model evaluation criteria. */}
            <section
                className={styles.evaluation}
                aria-labelledby="evaluation-heading"
            >
                <div>
                    <p className="eyebrow">
                        Evaluation
                    </p>

                    <h2 id="evaluation-heading">
                        What was assessed
                    </h2>
                </div>

                <div className={styles.evaluationGrid}>
                    <div>
                        <strong>
                            Discrimination
                        </strong>

                        <p>
                            Harrell’s concordance index was used to assess ranking of
                            survival outcomes.
                        </p>
                    </div>

                    <div>
                        <strong>
                            Probabilistic accuracy
                        </strong>

                        <p>
                            Integrated Brier Score was used to evaluate prediction error
                            across time.
                        </p>
                    </div>

                    <div>
                        <strong>
                            Calibration
                        </strong>

                        <p>
                            Adjusted D-calibration was used to assess consistency between
                            predicted and observed survival probabilities.
                        </p>
                    </div>

                    <div>
                        <strong>
                            Uncertainty usefulness
                        </strong>

                        <p>
                            Ensemble disagreement was compared with absolute prediction
                            error at multiple time horizons.
                        </p>
                    </div>
                </div>
            </section>

            {/* Display the known limitations of the model and application. */}
            <section
                className={styles.limitations}
                aria-labelledby="limitations-heading"
            >
                <p className="eyebrow">
                    Known limitations
                </p>

                <h2 id="limitations-heading">
                    Important constraints
                </h2>

                <ul>
                    <li>
                        The model has not undergone prospective clinical validation.
                    </li>

                    <li>
                        External validation on an independent cohort has not yet been
                        completed.
                    </li>

                    <li>
                        Predictions are limited by the variables and patient population
                        represented in METABRIC.
                    </li>

                    <li>
                        Ensemble disagreement captures variation between models only.
                    </li>

                    <li>
                        The application does not provide treatment advice or replace
                        clinical judgement.
                    </li>
                </ul>
            </section>

            {/* Display links to continue or return to the home page. */}
            <div className={styles.actions}>
                <Link
                    className="button button--primary"
                    to="/patient"
                >
                    Create a prognosis
                </Link>

                <Link
                    className="button button--secondary"
                    to="/"
                >
                    Return home
                </Link>
            </div>
        </div>
    );
}

export default AboutPage;