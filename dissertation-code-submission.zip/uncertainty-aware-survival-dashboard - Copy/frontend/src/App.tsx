import {
    lazy,
    Suspense,
} from "react";

import {
    Navigate,
    Route,
    Routes,
} from "react-router";

import Footer from "./components/layout/Footer";
import Header from "./components/layout/Header";
import LoadingSpinner from "./components/common/LoadingSpinner";


// ---------------------------------------------------------------------------
// Lazy-Loaded Pages
// ---------------------------------------------------------------------------

// Load each page only when its route is requested.
const HomePage = lazy(
    () => import("./pages/HomePage/HomePage"),
);

const PatientInputPage = lazy(
    () => import(
        "./pages/PatientInputPage/PatientInputPage"
        ),
);

const PrognosisPage = lazy(
    () => import(
        "./pages/PrognosisPage/PrognosisPage"
        ),
);

const PrognosisDetailsPage = lazy(
    () => import(
        "./pages/PrognosisDetailsPage/PrognosisDetailsPage"
        ),
);

const AboutPage = lazy(
    () => import("./pages/AboutPage/AboutPage"),
);


// ---------------------------------------------------------------------------
// Application
// ---------------------------------------------------------------------------

// Define the shared application layout and page routing.
function App() {
    return (
        <div className="app-shell">
            <Header />

            <main
                id="main-content"
                className="app-main"
            >
                {/* Display a loading state while lazy-loaded pages are fetched. */}
                <Suspense
                    fallback={
                        <div className="page-container page-loading">
                            <LoadingSpinner />
                            <p>Loading page…</p>
                        </div>
                    }
                >
                    {/* Map application routes to their corresponding pages. */}
                    <Routes>
                        <Route
                            path="/"
                            element={<HomePage />}
                        />

                        <Route
                            path="/patient"
                            element={<PatientInputPage />}
                        />

                        <Route
                            path="/prognosis"
                            element={<PrognosisPage />}
                        />

                        <Route
                            path="/prognosis/details"
                            element={<PrognosisDetailsPage />}
                        />

                        <Route
                            path="/about"
                            element={<AboutPage />}
                        />

                        {/* Redirect unknown routes back to the home page. */}
                        <Route
                            path="*"
                            element={
                                <Navigate
                                    to="/"
                                    replace
                                />
                            }
                        />
                    </Routes>
                </Suspense>
            </main>

            <Footer />
        </div>
    );
}

export default App;