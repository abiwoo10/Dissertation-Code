App.tsx/
Defines the main application layout and routing structure, including the 
shared header, footer, page routes, and loading state.

main.tsx/
Provides the frontend entry point, mounting the React application and 
configuring client-side routing and global styles.