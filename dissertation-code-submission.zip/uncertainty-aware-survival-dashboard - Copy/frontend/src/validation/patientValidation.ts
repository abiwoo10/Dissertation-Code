import type { PatientData } from "../types/patient";


// ---------------------------------------------------------------------------
// Patient Validation Errors
// ---------------------------------------------------------------------------

// Define optional validation messages for each patient data field.
export type PatientFieldErrors = Partial<
    Record<keyof PatientData, string>
>;


// ---------------------------------------------------------------------------
// Patient Data Validation
// ---------------------------------------------------------------------------

// Validate the patient characteristics required for prognosis generation.
export function validatePatientData(
    patient: PatientData,
): PatientFieldErrors {
    const errors: PatientFieldErrors = {};

    // Validate the patient's age at diagnosis.
    if (
        !Number.isFinite(patient.age_at_diagnosis)
        || patient.age_at_diagnosis < 18
        || patient.age_at_diagnosis > 120
    ) {
        errors.age_at_diagnosis =
            "Age must be between 18 and 120 years.";
    }

    // Validate the number of positive lymph nodes.
    if (
        !Number.isFinite(
            patient.lymph_nodes_examined_positive,
        )
        || patient.lymph_nodes_examined_positive < 0
    ) {
        errors.lymph_nodes_examined_positive =
            "Positive lymph-node count cannot be negative.";
    }

    // Validate the tumour grade.
    if (![1, 2, 3].includes(patient.grade)) {
        errors.grade = "Grade must be 1, 2, or 3.";
    }

    // Validate the tumour size.
    if (
        !Number.isFinite(patient.tumor_size)
    ) {
        errors.tumor_size =
            "Enter a tumour size.";
    } else if (patient.tumor_size <= 0) {
        errors.tumor_size =
            "Tumour size must be greater than zero.";
    }

    // Validate the tumour stage.
    if (
        ![0, 1, 2, 3, 4].includes(
            patient.tumor_stage,
        )
    ) {
        errors.tumor_stage =
            "Tumour stage must be between 0 and 4.";
    }

    // Validate the tumour mutational burden.
    if (
        !Number.isFinite(
            patient.tmb_nonsynonymous,
        )
        || patient.tmb_nonsynonymous < 0
    ) {
        errors.tmb_nonsynonymous =
            "Tumour mutational burden cannot be negative.";
    }

    // Validate the cellularity category.
    if (!patient.cellularity.trim()) {
        errors.cellularity =
            "Select a cellularity category.";
    }

    // Validate the hormone and receptor statuses.
    if (!patient.er_status.trim()) {
        errors.er_status = "Select an ER status.";
    }

    if (!patient.her2_status.trim()) {
        errors.her2_status = "Select a HER2 status.";
    }

    if (!patient.pr_status.trim()) {
        errors.pr_status = "Select a PR status.";
    }

    // Validate the inferred menopausal state.
    if (
        !patient.inferred_menopausal_state.trim()
    ) {
        errors.inferred_menopausal_state =
            "Select a menopausal state.";
    }

    // Validate the histological subtype.
    if (!patient.histological_subtype.trim()) {
        errors.histological_subtype =
            "Select a histological subtype.";
    }

    // Validate the integrative cluster.
    if (!patient.integrative_cluster.trim()) {
        errors.integrative_cluster =
            "Select an integrative cluster.";
    }

    return errors;
}


// ---------------------------------------------------------------------------
// Validation Error Check
// ---------------------------------------------------------------------------

// Determine whether any patient validation errors are present.
export function hasPatientErrors(
    errors: PatientFieldErrors,
): boolean {
    return Object.keys(errors).length > 0;
}