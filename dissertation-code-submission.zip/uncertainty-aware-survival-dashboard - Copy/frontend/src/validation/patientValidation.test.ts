import { describe, expect, it } from "vitest";

import { defaultPatientData } from "../types/patient";

import {
    hasPatientErrors,
    validatePatientData,
} from "./patientValidation";


// ---------------------------------------------------------------------------
// Patient Validation Tests
// ---------------------------------------------------------------------------

describe("validatePatientData", () => {
    // Check that the default patient data passes validation.
    it("accepts the default patient data", () => {
        const errors = validatePatientData(
            defaultPatientData,
        );

        expect(errors).toEqual({});
        expect(hasPatientErrors(errors)).toBe(false);
    });

    // Check that ages below the supported range are rejected.
    it("rejects an age below the supported range", () => {
        const errors = validatePatientData({
            ...defaultPatientData,
            age_at_diagnosis: 17,
        });

        expect(errors.age_at_diagnosis).toBe(
            "Age must be between 18 and 120 years.",
        );

        expect(hasPatientErrors(errors)).toBe(true);
    });

    // Check that unsupported tumour grades are rejected.
    it("rejects an invalid tumour grade", () => {
        const errors = validatePatientData({
            ...defaultPatientData,
            grade: 4,
        });

        expect(errors.grade).toBe(
            "Grade must be 1, 2, or 3.",
        );
    });

    // Check that tumour size must be greater than zero.
    it("rejects a non-positive tumour size", () => {
        const errors = validatePatientData({
            ...defaultPatientData,
            tumor_size: 0,
        });

        expect(errors.tumor_size).toBe(
            "Tumour size must be greater than zero.",
        );

        expect(hasPatientErrors(errors)).toBe(true);
    });

    // Check that unsupported tumour stages are rejected.
    it("rejects an invalid tumour stage", () => {
        const errors = validatePatientData({
            ...defaultPatientData,
            tumor_stage: 5,
        });

        expect(errors.tumor_stage).toBe(
            "Tumour stage must be between 0 and 4.",
        );
    });

    // Check that tumour mutational burden cannot be negative.
    it("rejects a negative mutational burden", () => {
        const errors = validatePatientData({
            ...defaultPatientData,
            tmb_nonsynonymous: -1,
        });

        expect(errors.tmb_nonsynonymous).toBe(
            "Tumour mutational burden cannot be negative.",
        );
    });

    // Check that an ER status must be selected.
    it("requires an ER status", () => {
        const errors = validatePatientData({
            ...defaultPatientData,
            er_status: "",
        });

        expect(errors.er_status).toBe(
            "Select an ER status.",
        );
    });
});