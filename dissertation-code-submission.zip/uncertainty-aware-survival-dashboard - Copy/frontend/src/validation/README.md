patientValidation.test.ts/
Tests the patient validation logic to confirm valid patient data is 
accepted and invalid values produce the expected validation errors.

patientValidation.ts/
Validates patient input fields before prognosis generation and provides 
a helper for determining whether any validation errors are present.