global.css/
Defines the shared application styles for layout, navigation, buttons, 
forms, patient workflow components, loading states, and responsive behaviour.

reset.css/
Normalises basic browser styles and establishes consistent defaults for 
sizing, media elements, form controls, and links.

utilities.css/
Provides reusable utility styles, including visually hidden content for 
accessibility.

variables.css/
Defines the shared design tokens for the light and dark themes, including 
colours, shadows, border radii, page width, and transitions.