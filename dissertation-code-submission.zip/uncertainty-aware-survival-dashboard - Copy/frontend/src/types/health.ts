// ---------------------------------------------------------------------------
// Health Response
// ---------------------------------------------------------------------------

// Define the health information returned by the prediction API.
export interface HealthResponse {
    status: string;
    model_loaded: boolean;
}