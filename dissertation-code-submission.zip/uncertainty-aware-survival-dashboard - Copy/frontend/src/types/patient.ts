// ---------------------------------------------------------------------------
// Patient Data
// ---------------------------------------------------------------------------

// Define the patient characteristics required for prognosis generation.
export interface PatientData {
    age_at_diagnosis: number;
    lymph_nodes_examined_positive: number;
    grade: number;
    tumor_size: number;
    tumor_stage: number;
    tmb_nonsynonymous: number;
    cellularity: string;
    er_status: string;
    her2_status: string;
    pr_status: string;
    inferred_menopausal_state: string;
    histological_subtype: string;
    integrative_cluster: string;
}


// ---------------------------------------------------------------------------
// Default Patient Data
// ---------------------------------------------------------------------------

// Define the initial example values used by the patient input form.
export const defaultPatientData = {
    age_at_diagnosis: 58,
    lymph_nodes_examined_positive: 2,
    grade: 2,
    tumor_size: 24,
    tumor_stage: 2,
    tmb_nonsynonymous: 3.5,
    cellularity: "Moderate",
    er_status: "Positive",
    her2_status: "Negative",
    pr_status: "Positive",
    inferred_menopausal_state: "Post",
    histological_subtype: "Ductal/NST",
    integrative_cluster: "3",
} satisfies PatientData;