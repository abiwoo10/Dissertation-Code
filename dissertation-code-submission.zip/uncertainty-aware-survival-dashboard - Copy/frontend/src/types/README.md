health.ts/
Defines the TypeScript interface for health status responses returned by 
the prediction API.

patient.ts/
Defines the patient data structure used throughout the frontend and 
provides the default patient values used by the input form.

prognosis.ts/
Defines the TypeScript interfaces for prognosis results, including 
survival estimates, survival curve points, and model disagreement 
information.