// ---------------------------------------------------------------------------
// Horizon Estimate
// ---------------------------------------------------------------------------

// Define a fixed-time survival estimate and its model disagreement.
export interface HorizonEstimate {
    probability: number;
    percentage: number;
    model_disagreement: number | null;
}


// ---------------------------------------------------------------------------
// Survival Curve Point
// ---------------------------------------------------------------------------

// Define an individual time point within the predicted survival curve.
export interface SurvivalCurvePoint {
    months: number;
    survival_probability: number;
    lower_disagreement_bound?: number | null;
    upper_disagreement_bound?: number | null;
}


// ---------------------------------------------------------------------------
// Prognosis Response
// ---------------------------------------------------------------------------

// Define the complete patient-specific prognosis returned by the prediction API.
export interface PrognosisResponse {
    model_name: string;
    one_year: HorizonEstimate;
    three_year: HorizonEstimate;
    five_year: HorizonEstimate;
    median_survival_months: number | null;
    median_survival_years: number | null;
    overall_model_disagreement: number | null;
    model_disagreement_label: string | null;
    survival_curve: SurvivalCurvePoint[];
    patient_explanation: string;
    uncertainty_explanation: string;
    limitations: string[];
}