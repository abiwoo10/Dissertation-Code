import type { PrognosisResponse } from "../../types/prognosis";

import styles from "./DisagreementPanel.module.css";


// ---------------------------------------------------------------------------
// Disagreement Panel Properties
// ---------------------------------------------------------------------------

// Define the prognosis displayed by the disagreement panel.
interface DisagreementPanelProps {
    prognosis: PrognosisResponse;
}


// ---------------------------------------------------------------------------
// Disagreement Description
// ---------------------------------------------------------------------------

// Select the description for the model disagreement category.
function getDisagreementDescription(
    label: string | null,
): string {
    if (!label) {
        return "No qualitative disagreement category was returned.";
    }

    const labelText = label.toLowerCase();

    if (labelText.includes("lower")) {
        return (
            "The independently trained ensemble members produced "
            + "relatively similar predictions for this patient."
        );
    }

    if (labelText.includes("moderate")) {
        return (
            "The ensemble members showed some variation in their "
            + "predictions for this patient."
        );
    }

    if (labelText.includes("higher")) {
        return (
            "The ensemble members produced more varied predictions "
            + "for this patient, indicating lower model agreement."
        );
    }

    return (
        "This category summarises how strongly the independently "
        + "trained ensemble members agreed."
    );
}


// ---------------------------------------------------------------------------
// Disagreement Panel
// ---------------------------------------------------------------------------

// Display the model disagreement information for the prognosis.
function DisagreementPanel({
                               prognosis,
                           }: DisagreementPanelProps) {
    const disagreementScore =
        prognosis.overall_model_disagreement;

    return (
        <section
            className={styles.panel}
            aria-labelledby="model-disagreement-heading"
        >
            <p className="eyebrow">
                Predictive uncertainty
            </p>

            <h2 id="model-disagreement-heading">
                Model disagreement
            </h2>

            {/* Display the qualitative disagreement category. */}
            <div className={styles.status}>
                <span
                    className={styles.statusIndicator}
                    aria-hidden="true"
                />

                <strong>
                    {prognosis.model_disagreement_label
                        ?? "Disagreement category unavailable"}
                </strong>
            </div>

            <p className={styles.summary}>
                {getDisagreementDescription(
                    prognosis.model_disagreement_label,
                )}
            </p>

            {/* Display the overall disagreement score when available. */}
            {disagreementScore != null && (
                <div className={styles.score}>
                    <span>Overall disagreement score</span>
                    <strong>{disagreementScore.toFixed(4)}</strong>
                </div>
            )}

            <p className={styles.explanation}>
                {prognosis.uncertainty_explanation}
            </p>

            {/* Display additional interpretation information. */}
            <details className={styles.details}>
                <summary>
                    How should this be interpreted?
                </summary>

                <p>
                    Model disagreement reflects variation between ensemble
                    members. It is not a statistical confidence interval and
                    does not capture every source of clinical uncertainty.
                </p>
            </details>
        </section>
    );
}

export default DisagreementPanel;