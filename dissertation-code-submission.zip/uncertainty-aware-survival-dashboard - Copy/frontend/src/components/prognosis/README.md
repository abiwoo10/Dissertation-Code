DisagreementPanel.module.css/
Defines the component-specific styling for the model disagreement panel.

DisagreementPanel.tsx/
Displays the level of disagreement between ensemble models and provides 
supporting uncertainty information.

LimitationsPanel.module.css/
Defines the component-specific styling for the prognosis limitations panel.

LimitationsPanel.tsx/
Displays the limitations associated with the generated patient-specific 
prognosis.

MedianSurvivalCard.module.css/
Defines the component-specific styling for the median survival summary card.

MedianSurvivalCard.tsx/
Displays the predicted median survival estimate returned by the prognosis 
model.

SurvivalCurve.module.css/
Defines the component-specific styling and layout for the survival curve 
visualisation.

SurvivalCurve.tsx/
Visualises predicted survival probability over time together with the 
available model disagreement bounds.

SurvivalMetricCard.module.css/
Defines the component-specific styling for fixed-time survival estimate 
cards.

SurvivalMetricCard.test.tsx/
Tests that the survival metric card correctly displays the supplied 
survival estimate and associated information.

SurvivalMetricCard.tsx/
Displays a fixed-time survival probability and its associated model 
disagreement information.