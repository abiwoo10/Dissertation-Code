import type { PrognosisResponse } from "../../types/prognosis";

import styles from "./MedianSurvivalCard.module.css";


// ---------------------------------------------------------------------------
// Median Survival Card Properties
// ---------------------------------------------------------------------------

// Define the prognosis containing the median survival estimates.
interface MedianSurvivalCardProps {
    prognosis: PrognosisResponse;
}


// ---------------------------------------------------------------------------
// Median Survival Card
// ---------------------------------------------------------------------------

// Display the median predicted survival.
function MedianSurvivalCard({
                                prognosis,
                            }: MedianSurvivalCardProps) {
    const medianYears =
        prognosis.median_survival_years;

    const medianMonths =
        prognosis.median_survival_months;

    return (
        <section
            className={styles.card}
            aria-labelledby="median-survival-heading"
        >
            <p className="eyebrow">
                Summary estimate
            </p>

            <h2 id="median-survival-heading">
                Median predicted survival
            </h2>

            {/* Display the median survival estimate when available. */}
            {medianYears == null ? (
                <p className={styles.unavailable}>
                    Median predicted survival was not reached within the
                    displayed time horizon.
                </p>
            ) : (
                <>
                    <strong className={styles.value}>
                        {medianYears.toFixed(1)} years
                    </strong>

                    {medianMonths != null && (
                        <p className={styles.secondary}>
                            Approximately {medianMonths.toFixed(0)} months
                        </p>
                    )}
                </>
            )}
        </section>
    );
}

export default MedianSurvivalCard;