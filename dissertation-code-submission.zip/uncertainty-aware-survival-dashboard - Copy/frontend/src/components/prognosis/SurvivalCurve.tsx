import {
    Area,
    CartesianGrid,
    ComposedChart,
    Legend,
    Line,
    ReferenceLine,
    ResponsiveContainer,
    Tooltip,
    XAxis,
    YAxis,
} from "recharts";

import type {
    PrognosisResponse,
    SurvivalCurvePoint,
} from "../../types/prognosis";

import styles from "./SurvivalCurve.module.css";


// ---------------------------------------------------------------------------
// Survival Curve Properties
// ---------------------------------------------------------------------------

// Define the prognosis displayed by the survival curve.
interface SurvivalCurveProps {
    prognosis: PrognosisResponse;
}

// Define the additional values used to display the disagreement band.
interface SurvivalChartPoint extends SurvivalCurvePoint {
    disagreementBase: number;
    disagreementWidth: number;
}

// Define the survival chart point provided to the tooltip.
interface TooltipPayloadItem {
    payload: SurvivalChartPoint;
}

// Define the tooltip display state and values.
interface SurvivalTooltipProps {
    active?: boolean;
    payload?: TooltipPayloadItem[];
    label?: number;
}


// ---------------------------------------------------------------------------
// Survival Tooltip
// ---------------------------------------------------------------------------

// Display the survival and disagreement values for a chart point.
function SurvivalTooltip({
                             active,
                             payload,
                             label,
                         }: SurvivalTooltipProps) {
    if (!active || !payload?.length) {
        return null;
    }

    const chartPoint = payload[0].payload;

    return (
        <div className={styles.tooltip}>
            <strong>{Number(label).toFixed(0)} months</strong>

            <dl>
                <div>
                    <dt>Predicted survival</dt>
                    <dd>
                        {(chartPoint.survival_probability * 100).toFixed(1)}%
                    </dd>
                </div>

                {chartPoint.lower_disagreement_bound != null
                    && chartPoint.upper_disagreement_bound != null && (
                        <>
                            <div>
                                <dt>Lower member bound</dt>
                                <dd>
                                    {(
                                        chartPoint.lower_disagreement_bound * 100
                                    ).toFixed(1)}
                                    %
                                </dd>
                            </div>

                            <div>
                                <dt>Upper member bound</dt>
                                <dd>
                                    {(
                                        chartPoint.upper_disagreement_bound * 100
                                    ).toFixed(1)}
                                    %
                                </dd>
                            </div>
                        </>
                    )}
            </dl>
        </div>
    );
}


// ---------------------------------------------------------------------------
// Probability Formatting
// ---------------------------------------------------------------------------

// Format a probability as a percentage.
function formatProbability(value: number) {
    return `${Math.round(value * 100)}%`;
}


// ---------------------------------------------------------------------------
// Survival Curve
// ---------------------------------------------------------------------------

// Display the predicted survival curve and ensemble disagreement.
function SurvivalCurve({
                           prognosis,
                       }: SurvivalCurveProps) {
    // Prepare the survival curve data and disagreement band values.
    const chartData: SurvivalChartPoint[] = [
        {
            months: 0,
            survival_probability: 1,
            lower_disagreement_bound: 1,
            upper_disagreement_bound: 1,
            disagreementBase: 1,
            disagreementWidth: 0,
        },
        ...prognosis.survival_curve.map(
            (point): SurvivalChartPoint => {
                const lower =
                    point.lower_disagreement_bound
                    ?? point.survival_probability;

                const upper =
                    point.upper_disagreement_bound
                    ?? point.survival_probability;

                return {
                    ...point,
                    disagreementBase: lower,
                    disagreementWidth: Math.max(
                        0,
                        upper - lower,
                    ),
                };
            },
        ),
    ];

    // Define the reference points for the prediction horizons.
    const horizonPoints = [
        {
            months: 12,
            label: "1 year",
        },
        {
            months: 36,
            label: "3 years",
        },
        {
            months: 60,
            label: "5 years",
        },
    ];

    return (
        <section
            className={styles.panel}
            aria-labelledby="survival-curve-heading"
        >
            {/* Display the survival curve heading and instructions. */}
            <div className={styles.header}>
                <div>
                    <p className="eyebrow">
                        Individual survival distribution
                    </p>

                    <h2 id="survival-curve-heading">
                        Predicted survival over time
                    </h2>

                    <p>
                        Hover over or focus on the chart to inspect the estimated
                        survival probability at each time point.
                    </p>
                </div>
            </div>

            {/* Display the predicted survival chart. */}
            <div
                className={styles.chart}
                role="img"
                aria-label={
                    "Interactive predicted survival curve from 6 to "
                    + "240 months, including the variation between "
                    + "ensemble-member predictions."
                }
            >
                <ResponsiveContainer
                    width="100%"
                    height="100%"
                >
                    <ComposedChart
                        data={chartData}
                        margin={{
                            top: 20,
                            right: 24,
                            bottom: 16,
                            left: 8,
                        }}
                    >
                        <CartesianGrid
                            strokeDasharray="2 8"
                            className={styles.grid}
                        />

                        <XAxis
                            dataKey="months"
                            type="number"
                            domain={[0, 240]}
                            ticks={[0, 12, 36, 60, 120, 180, 240]}
                            tickLine={false}
                            axisLine={false}
                            label={{
                                value: "Time since diagnosis (months)",
                                position: "insideBottom",
                                offset: -10,
                            }}
                        />

                        <YAxis
                            domain={[0, 1]}
                            ticks={[0, 0.25, 0.5, 0.75, 1]}
                            tickFormatter={formatProbability}
                            tickLine={false}
                            axisLine={false}
                            width={54}
                        />

                        <Tooltip
                            content={<SurvivalTooltip />}
                            cursor={{
                                stroke: "var(--color-primary-500)",
                                strokeDasharray: "4 4",
                            }}
                        />

                        <Legend
                            verticalAlign="top"
                            align="right"
                            height={38}
                        />

                        {/* Display the ensemble disagreement band. */}
                        <Area
                            type="monotone"
                            dataKey="disagreementBase"
                            stackId="disagreement"
                            stroke="none"
                            fill="transparent"
                            fillOpacity={0}
                            legendType="none"
                            isAnimationActive={false}
                        />

                        <Area
                            type="monotone"
                            dataKey="disagreementWidth"
                            stackId="disagreement"
                            name="Ensemble disagreement band"
                            stroke="none"
                            fill="var(--color-disagreement-band)"
                            fillOpacity={0.42}
                            isAnimationActive={false}
                        />

                        {/* Display the disagreement boundary lines. */}
                        <Line
                            type="monotone"
                            dataKey="lower_disagreement_bound"
                            name="Lower disagreement bound"
                            stroke="var(--color-disagreement-bound)"
                            strokeWidth={2.25}
                            strokeDasharray="7 4"
                            dot={false}
                            connectNulls
                            legendType="none"
                            isAnimationActive={false}
                        />

                        <Line
                            type="monotone"
                            dataKey="upper_disagreement_bound"
                            name="Upper disagreement bound"
                            stroke="var(--color-disagreement-bound)"
                            strokeWidth={2.25}
                            strokeDasharray="7 4"
                            dot={false}
                            connectNulls
                            legendType="none"
                            isAnimationActive={false}
                        />

                        {/* Display the prediction horizon reference lines. */}
                        {horizonPoints.map((point) => (
                            <ReferenceLine
                                key={point.months}
                                x={point.months}
                                stroke="var(--color-border)"
                                strokeDasharray="4 4"
                                label={{
                                    value: point.label,
                                    position: "insideTop",
                                    fill: "var(--color-text-muted)",
                                    fontSize: 12,
                                }}
                            />
                        ))}

                        {/* Display the predicted survival line. */}
                        <Line
                            type="monotone"
                            dataKey="survival_probability"
                            name="Predicted survival"
                            stroke="var(--color-survival-line)"
                            strokeWidth={3.5}
                            dot={false}
                            activeDot={{
                                r: 6,
                                strokeWidth: 2,
                                fill: "var(--color-surface)",
                            }}
                            isAnimationActive
                        />
                    </ComposedChart>
                </ResponsiveContainer>
            </div>

            <p className={styles.caption}>
                The amber shaded region and dashed boundary lines show variation
                between independently trained ensemble members. The band may be
                narrow when the models produce similar predictions. It is not a
                statistical confidence interval.
            </p>

            {/* Display the survival summary as text. */}
            <details className={styles.accessibleSummary}>
                <summary>
                    View survival curve as text
                </summary>

                <ul>
                    <li>
                        1-year predicted survival:{" "}
                        {prognosis.one_year.percentage.toFixed(1)}%
                    </li>

                    <li>
                        3-year predicted survival:{" "}
                        {prognosis.three_year.percentage.toFixed(1)}%
                    </li>

                    <li>
                        5-year predicted survival:{" "}
                        {prognosis.five_year.percentage.toFixed(1)}%
                    </li>

                    <li>
                        {prognosis.median_survival_years == null
                            ? (
                                "Median predicted survival was not reached "
                                + "within the displayed horizon."
                            )
                            : (
                                `Median predicted survival: ${
                                    prognosis.median_survival_years.toFixed(1)
                                } years.`
                            )}
                    </li>
                </ul>
            </details>
        </section>
    );
}

export default SurvivalCurve;