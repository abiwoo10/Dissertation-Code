import type { HorizonEstimate } from "../../types/prognosis";

import styles from "./SurvivalMetricCard.module.css";


// ---------------------------------------------------------------------------
// Survival Metric Card Properties
// ---------------------------------------------------------------------------

// Define the label and survival estimate displayed by the card.
interface SurvivalMetricCardProps {
    label: string;
    estimate: HorizonEstimate;
}


// ---------------------------------------------------------------------------
// Survival Metric Card
// ---------------------------------------------------------------------------

// Display a survival estimate and its model disagreement.
function SurvivalMetricCard({
                                label,
                                estimate,
                            }: SurvivalMetricCardProps) {
    return (
        <article className={styles.card}>
            <span className={styles.label}>
                {label}
            </span>

            <strong className={styles.value}>
                {estimate.percentage.toFixed(1)}%
            </strong>

            {/* Display model disagreement when available. */}
            {estimate.model_disagreement != null && (
                <span className={styles.disagreement}>
                    Model disagreement:{" "}
                    {estimate.model_disagreement.toFixed(4)}
                </span>
            )}
        </article>
    );
}

export default SurvivalMetricCard;