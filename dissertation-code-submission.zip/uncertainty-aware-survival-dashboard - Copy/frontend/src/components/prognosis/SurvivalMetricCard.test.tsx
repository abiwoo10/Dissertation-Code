import {
    render,
    screen,
} from "@testing-library/react";

import {
    describe,
    expect,
    it,
} from "vitest";

import SurvivalMetricCard from "./SurvivalMetricCard";


// ---------------------------------------------------------------------------
// Survival Metric Card Tests
// ---------------------------------------------------------------------------

describe("SurvivalMetricCard", () => {

    // Check that the survival estimate and disagreement are displayed.
    it("renders the survival estimate", () => {
        render(
            <SurvivalMetricCard
                label="1-year survival"
                estimate={{
                    probability: 0.945,
                    percentage: 94.5,
                    model_disagreement: 0.0012,
                }}
            />,
        );

        expect(
            screen.getByText("1-year survival"),
        ).toBeInTheDocument();

        expect(
            screen.getByText("94.5%"),
        ).toBeInTheDocument();

        expect(
            screen.getByText(
                "Model disagreement: 0.0012",
            ),
        ).toBeInTheDocument();
    });

    // Check that unavailable disagreement is not displayed.
    it("omits disagreement when unavailable", () => {
        render(
            <SurvivalMetricCard
                label="5-year survival"
                estimate={{
                    probability: 0.75,
                    percentage: 75,
                    model_disagreement: null,
                }}
            />,
        );

        expect(
            screen.queryByText(
                /Model disagreement:/i,
            ),
        ).not.toBeInTheDocument();
    });
});