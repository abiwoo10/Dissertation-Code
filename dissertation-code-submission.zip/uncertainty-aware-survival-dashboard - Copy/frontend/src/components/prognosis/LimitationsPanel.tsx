import type { PrognosisResponse } from "../../types/prognosis";

import styles from "./LimitationsPanel.module.css";


// ---------------------------------------------------------------------------
// Limitations Panel Properties
// ---------------------------------------------------------------------------

// Define the prognosis containing the prediction limitations.
interface LimitationsPanelProps {
    prognosis: PrognosisResponse;
}


// ---------------------------------------------------------------------------
// Limitations Panel
// ---------------------------------------------------------------------------

// Display the limitations associated with the prognosis.
function LimitationsPanel({
                              prognosis,
                          }: LimitationsPanelProps) {
    return (
        <section
            className={styles.panel}
            aria-labelledby="limitations-heading"
        >
            <p className="eyebrow">
                Responsible interpretation
            </p>

            <h2 id="limitations-heading">
                Important limitations
            </h2>

            {/* Display each prognosis limitation. */}
            <ul>
                {prognosis.limitations.map((limitation) => (
                    <li key={limitation}>
                        {limitation}
                    </li>
                ))}
            </ul>
        </section>
    );
}

export default LimitationsPanel;