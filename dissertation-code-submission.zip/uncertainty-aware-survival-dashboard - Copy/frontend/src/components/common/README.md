BackendStatus.tsx/
Displays the current availability and connection status of the 
prediction backend.

LoadingSpinner.tsx/
Provides a reusable loading indicator for operations that are waiting 
to complete.