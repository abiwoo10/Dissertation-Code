import { useHealthStatus } from "../../hooks/useHealthStatus";


// ---------------------------------------------------------------------------
// Backend Status
// ---------------------------------------------------------------------------

function BackendStatus() {
    const health = useHealthStatus();

    // Show the loading state while the prediction service is checked.
    if (health.state === "loading") {
        return (
            <div
                className="backend-status backend-status--loading"
                role="status"
            >
                <span
                    className="backend-status__indicator"
                    aria-hidden="true"
                />

                Checking prediction service…
            </div>
        );
    }

    // Show an error when the health request fails.
    if (health.state === "error") {
        return (
            <div
                className="backend-status backend-status--error"
                role="alert"
            >
                 <span
                     className="backend-status__indicator"
                     aria-hidden="true"
                 />

                Prediction service unavailable
            </div>
        );
    }

    // Check that the API is healthy and the prediction model is loaded.
    const available =
        health.data.status === "healthy"
        && health.data.model_loaded;

    // Show the current prediction service status.
    return (
        <div
            className={
                available
                    ? "backend-status backend-status--available"
                    : "backend-status backend-status--error"
            }
            role="status"
        >
                    <span
                        className="backend-status__indicator"
                        aria-hidden="true"
                    />

            {available
                ? "Prediction service available"
                : "Prediction model unavailable"}
        </div>
    );
}

export default BackendStatus;