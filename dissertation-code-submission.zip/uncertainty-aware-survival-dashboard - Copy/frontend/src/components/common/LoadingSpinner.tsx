// ---------------------------------------------------------------------------
// Loading Spinner
// ---------------------------------------------------------------------------

// Display the loading spinner.
function LoadingSpinner() {
    return (
        <span
            className="loading-spinner"
            role="status"
            aria-label="Loading"
        />
    );
}

export default LoadingSpinner;