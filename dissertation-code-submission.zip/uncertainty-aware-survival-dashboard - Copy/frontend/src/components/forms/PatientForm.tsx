import {
    useMemo,
    useState,
} from "react";

import { useNavigate } from "react-router";

import ClinicalFields from "./ClinicalFields";
import MolecularFields from "./MolecularFields";
import PathologyFields from "./PathologyFields";
import PatientProgress from "./PatientProgress";
import PatientReview from "./PatientReview";

import { usePrognosis } from "../../hooks/usePrognosis";

import {
    defaultPatientData,
    type PatientData,
} from "../../types/patient";

import {
    hasPatientErrors,
    validatePatientData,
    type PatientFieldErrors,
} from "../../validation/patientValidation";

import {
    clearPrognosisResult,
    loadPrognosisResult,
    savePrognosisResult,
} from "../../services/prognosisStorage";


// ---------------------------------------------------------------------------
// Form Configuration
// ---------------------------------------------------------------------------

// Define the available patient form steps.
type PatientFormStep = 1 | 2 | 3 | 4;

// Group the clinical fields used in the first step.
const clinicalFields: Array<keyof PatientData> = [
    "age_at_diagnosis",
    "lymph_nodes_examined_positive",
    "grade",
    "tumor_size",
    "tumor_stage",
    "inferred_menopausal_state",
];

// Group the pathology fields used in the second step.
const pathologyFields: Array<keyof PatientData> = [
    "cellularity",
    "er_status",
    "her2_status",
    "pr_status",
    "histological_subtype",
];

// Group the molecular fields used in the third step.
const molecularFields: Array<keyof PatientData> = [
    "integrative_cluster",
    "tmb_nonsynonymous",
];


// ---------------------------------------------------------------------------
// Validation Helpers
// ---------------------------------------------------------------------------

// Select validation errors for the requested fields.
function selectErrors(
    allErrors: PatientFieldErrors,
    fields: Array<keyof PatientData>,
): PatientFieldErrors {
    const selectedErrors: PatientFieldErrors = {};

    fields.forEach((field) => {
        const message = allErrors[field];

        if (message) {
            selectedErrors[field] = message;
        }
    });

    return selectedErrors;
}


// ---------------------------------------------------------------------------
// Patient Form
// ---------------------------------------------------------------------------

// Manage the patient input and review workflow.
function PatientForm() {
    // Restore saved patient data or use the default values.
    const [patient, setPatient] =
        useState<PatientData>(() => {
            const storedResult =
                loadPrognosisResult();

            return storedResult?.patient
                ?? defaultPatientData;
        });

    const [errors, setErrors] =
        useState<PatientFieldErrors>({});

    const [currentStep, setCurrentStep] =
        useState<PatientFormStep>(1);

    const navigate = useNavigate();

    const {
        error: prognosisError,
        isLoading,
        generatePrognosis,
    } = usePrognosis();

    // Select the title for the current form step.
    const stepTitle = useMemo(() => {
        switch (currentStep) {
            case 1:
                return "Clinical characteristics";
            case 2:
                return "Receptor and pathology characteristics";
            case 3:
                return "Molecular characteristics";
            case 4:
                return "Review patient details";
        }
    }, [currentStep]);


    // -----------------------------------------------------------------------
    // Form Updates
    // -----------------------------------------------------------------------

    // Update a patient field and clear its existing error.
    function handleChange(
        field: keyof PatientData,
        value: string | number,
    ) {
        clearPrognosisResult();

        setPatient((currentPatient) => ({
            ...currentPatient,
            [field]: value,
        }));

        setErrors((currentErrors) => {
            if (!(field in currentErrors)) {
                return currentErrors;
            }

            const nextErrors = {
                ...currentErrors,
            };

            delete nextErrors[field];

            return nextErrors;
        });
    }

    // Get the validation errors for the current step.
    function getCurrentStepErrors(): PatientFieldErrors {
        const allErrors =
            validatePatientData(patient);

        if (currentStep === 1) {
            return selectErrors(
                allErrors,
                clinicalFields,
            );
        }

        if (currentStep === 2) {
            return selectErrors(
                allErrors,
                pathologyFields,
            );
        }

        if (currentStep === 3) {
            return selectErrors(
                allErrors,
                molecularFields,
            );
        }

        return allErrors;
    }


    // -----------------------------------------------------------------------
    // Step Navigation
    // -----------------------------------------------------------------------

    // Validate the current step and move to the next step.
    function moveToNextStep() {
        const stepErrors =
            getCurrentStepErrors();

        setErrors(stepErrors);

        if (hasPatientErrors(stepErrors)) {
            return;
        }

        setErrors({});

        setCurrentStep((step) => {
            if (step >= 4) {
                return 4;
            }

            return (step + 1) as PatientFormStep;
        });

        window.scrollTo({
            top: 0,
            behavior: "smooth",
        });
    }

    // Move to the previous form step.
    function moveToPreviousStep() {
        setErrors({});

        setCurrentStep((step) => {
            if (step <= 1) {
                return 1;
            }

            return (step - 1) as PatientFormStep;
        });

        window.scrollTo({
            top: 0,
            behavior: "smooth",
        });
    }

    // Submit the current form step.
    function handleSubmit(
        event: React.FormEvent<HTMLFormElement>,
    ) {
        event.preventDefault();
        moveToNextStep();
    }

    // Return to the first step for editing.
    function handleEdit() {
        setCurrentStep(1);

        window.scrollTo({
            top: 0,
            behavior: "smooth",
        });
    }


    // -----------------------------------------------------------------------
    // Prognosis Generation
    // -----------------------------------------------------------------------

    // Validate the patient details and generate the prognosis.
    async function handleConfirm() {
        const validationErrors =
            validatePatientData(patient);

        setErrors(validationErrors);

        if (hasPatientErrors(validationErrors)) {
            setCurrentStep(1);

            window.scrollTo({
                top: 0,
                behavior: "smooth",
            });

            return;
        }

        const prognosis =
            await generatePrognosis(patient);

        if (!prognosis) {
            return;
        }

        // Save the patient data and generated prognosis.
        savePrognosisResult({
            patient,
            prognosis,
        });

        // Open the prognosis page with the generated result.
        navigate(
            "/prognosis",
            {
                state: {
                    patient,
                    prognosis,
                },
            },
        );
    }


    // -----------------------------------------------------------------------
    // Form Display
    // -----------------------------------------------------------------------

    return (
        <div className="patient-workflow">
            <PatientProgress
                currentStep={currentStep}
            />

            {/* Display the current step heading and instructions. */}
            <header className="patient-step-header">
                <p className="eyebrow">
                    Step {currentStep} of 5
                </p>

                <h2>
                    {stepTitle}
                </h2>

                <p>
                    {currentStep === 1
                        && (
                            "Enter the patient’s core clinical and tumour "
                            + "characteristics."
                        )}

                    {currentStep === 2
                        && (
                            "Enter receptor status and pathological "
                            + "classification details."
                        )}

                    {currentStep === 3
                        && (
                            "Enter the molecular variables required by "
                            + "the extended prognostic model."
                        )}

                    {currentStep === 4
                        && (
                            "Check every value before generating the "
                            + "patient-specific prognosis."
                        )}
                </p>
            </header>

            {/* Display any prognosis generation error. */}
            {prognosisError && (
                <div
                    className="form-api-error"
                    role="alert"
                >
                    {prognosisError}
                </div>
            )}

            {/* Display the review screen or current input step. */}
            {currentStep === 4 ? (
                <PatientReview
                    patient={patient}
                    onEdit={handleEdit}
                    onBack={moveToPreviousStep}
                    onConfirm={handleConfirm}
                    isLoading={isLoading}
                />
            ) : (
                <form
                    className="patient-form"
                    onSubmit={handleSubmit}
                    noValidate
                >
                    {currentStep === 1 && (
                        <ClinicalFields
                            patient={patient}
                            errors={errors}
                            onChange={handleChange}
                        />
                    )}

                    {currentStep === 2 && (
                        <PathologyFields
                            patient={patient}
                            errors={errors}
                            onChange={handleChange}
                        />
                    )}

                    {currentStep === 3 && (
                        <MolecularFields
                            patient={patient}
                            errors={errors}
                            onChange={handleChange}
                        />
                    )}

                    {/* Display the navigation controls for the current step. */}
                    <div className="form-actions form-actions--wizard">
                        {currentStep > 1 && (
                            <button
                                type="button"
                                className="button button--secondary"
                                onClick={moveToPreviousStep}
                            >
                                Back
                            </button>
                        )}

                        <button
                            type="submit"
                            className="button button--primary"
                        >
                            {currentStep === 3
                                ? "Review patient details"
                                : "Continue"}
                        </button>
                    </div>
                </form>
            )}
        </div>
    );
}

export default PatientForm;