import type { PatientData } from "../../types/patient";
import type { PatientFieldErrors } from "../../validation/patientValidation";


// ---------------------------------------------------------------------------
// Pathology Field Properties
// ---------------------------------------------------------------------------

// Define the patient data, validation errors, and change handler.
interface PathologyFieldsProps {
    patient: PatientData;
    errors: PatientFieldErrors;
    onChange: (
        field: keyof PatientData,
        value: string | number,
    ) => void;
}


// ---------------------------------------------------------------------------
// Pathology Fields
// ---------------------------------------------------------------------------

// Display the receptor and pathology patient input fields.
function PathologyFields({
                             patient,
                             errors,
                             onChange,
                         }: PathologyFieldsProps) {
    return (
        <fieldset className="form-section">
            <legend>Receptor and pathology characteristics</legend>

            <p className="form-section__description">
                Enter tumour receptor status, cellularity, and histological subtype.
            </p>

            <div className="form-grid">

                {/* Select the patient's ER status. */}
                <div className="form-field">
                    <label htmlFor="er_status">ER status</label>

                    <select
                        id="er_status"
                        name="er_status"
                        value={patient.er_status}
                        onChange={(event) =>
                            onChange("er_status", event.target.value)
                        }
                    >
                        <option value="Negative">Negative</option>
                        <option value="Positive">Positive</option>
                    </select>
                </div>

                {/* Select the patient's PR status. */}
                <div className="form-field">
                    <label htmlFor="pr_status">PR status</label>

                    <select
                        id="pr_status"
                        name="pr_status"
                        value={patient.pr_status}
                        onChange={(event) =>
                            onChange("pr_status", event.target.value)
                        }
                    >
                        <option value="Negative">Negative</option>
                        <option value="Positive">Positive</option>
                    </select>
                </div>

                {/* Select the patient's HER2 status. */}
                <div className="form-field">
                    <label htmlFor="her2_status">HER2 status</label>

                    <select
                        id="her2_status"
                        name="her2_status"
                        value={patient.her2_status}
                        onChange={(event) =>
                            onChange("her2_status", event.target.value)
                        }
                    >
                        <option value="Negative">Negative</option>
                        <option value="Positive">Positive</option>
                    </select>
                </div>

                {/* Select the tumour cellularity. */}
                <div className="form-field">
                    <label htmlFor="cellularity">Cellularity</label>

                    <select
                        id="cellularity"
                        name="cellularity"
                        value={patient.cellularity}
                        onChange={(event) =>
                            onChange("cellularity", event.target.value)
                        }
                    >
                        <option value="Low">Low</option>
                        <option value="Moderate">Moderate</option>
                        <option value="High">High</option>
                    </select>

                </div>

                {/* Select the tumour histological subtype. */}
                <div className="form-field form-field--wide">
                    <label htmlFor="histological_subtype">
                        Histological subtype
                    </label>

                    <select
                        id="histological_subtype"
                        name="histological_subtype"
                        value={patient.histological_subtype}
                        onChange={(event) =>
                            onChange(
                                "histological_subtype",
                                event.target.value,
                            )
                        }
                        aria-invalid={
                            errors.histological_subtype ? "true" : "false"
                        }
                        aria-describedby={
                            errors.histological_subtype
                                ? "histological_subtype-error"
                                : "histological_subtype-help"
                        }
                    >
                        <option value="Ductal/NST">
                            Ductal / NST
                        </option>

                        <option value="Lobular">
                            Lobular
                        </option>

                        <option value="Medullary">
                            Medullary
                        </option>

                        <option value="Metaplastic">
                            Metaplastic
                        </option>

                        <option value="Mixed">
                            Mixed
                        </option>

                        <option value="Mucinous">
                            Mucinous
                        </option>

                        <option value="Other">
                            Other
                        </option>

                        <option value="Tubular/ cribriform">
                            Tubular / cribriform
                        </option>
                    </select>

                    {errors.histological_subtype && (
                        <p
                            id="histological_subtype-error"
                            className="form-error"
                            role="alert"
                        >
                            {errors.histological_subtype}
                        </p>
                    )}
                </div>
            </div>
        </fieldset>
    );
}

export default PathologyFields;