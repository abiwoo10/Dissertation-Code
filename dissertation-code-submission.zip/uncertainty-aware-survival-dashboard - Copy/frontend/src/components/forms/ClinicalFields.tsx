import type { PatientData } from "../../types/patient";
import type { PatientFieldErrors } from "../../validation/patientValidation";


// ---------------------------------------------------------------------------
// Clinical Field Properties
// ---------------------------------------------------------------------------

// Define the patient data, validation errors, and change handler.
interface ClinicalFieldsProps {
    patient: PatientData;
    errors: PatientFieldErrors;
    onChange: (
        field: keyof PatientData,
        value: string | number,
    ) => void;
}


// ---------------------------------------------------------------------------
// Clinical Fields
// ---------------------------------------------------------------------------

// Display the clinical patient input fields.
function ClinicalFields({
                            patient,
                            errors,
                            onChange,
                        }: ClinicalFieldsProps) {
    return (
        <fieldset className="form-section">
            <legend>Clinical characteristics</legend>
            <p className="form-section__description">
                Enter demographic information and core tumour characteristics.
            </p>

            <div className="form-grid">

                {/* Collect the patient's age at diagnosis. */}
                <div className="form-field">
                    <label htmlFor="age_at_diagnosis">
                        Age at diagnosis
                    </label>

                    <input
                        id="age_at_diagnosis"
                        name="age_at_diagnosis"
                        type="number"
                        min="18"
                        max="120"
                        step="1"
                        value={patient.age_at_diagnosis}
                        onChange={(event) =>
                            onChange(
                                "age_at_diagnosis",
                                Number(event.target.value),
                            )
                        }
                        aria-invalid={
                            errors.age_at_diagnosis
                                ? "true"
                                : "false"
                        }
                        aria-describedby={
                            errors.age_at_diagnosis
                                ? "age_at_diagnosis-error"
                                : undefined
                        }
                    />

                    {errors.age_at_diagnosis && (
                        <p
                            id="age_at_diagnosis-error"
                            className="form-error"
                            role="alert"
                        >
                            {errors.age_at_diagnosis}
                        </p>
                    )}
                </div>

                {/* Collect the patient's tumour size. */}
                <div className="form-field">
                    <label htmlFor="tumor_size">
                        Tumour size (mm)
                    </label>

                    <input
                        id="tumor_size"
                        name="tumor_size"
                        type="number"
                        min="0.1"
                        step="0.1"
                        value={patient.tumor_size}
                        onChange={(event) =>
                            onChange(
                                "tumor_size",
                                Number(event.target.value),
                            )
                        }
                        aria-invalid={
                            errors.tumor_size
                                ? "true"
                                : "false"
                        }
                        aria-describedby={
                            errors.tumor_size
                                ? "tumor_size-error"
                                : undefined
                        }
                    />

                    {errors.tumor_size && (
                        <p
                            id="tumor_size-error"
                            className="form-error"
                            role="alert"
                        >
                            {errors.tumor_size}
                        </p>
                    )}
                </div>

                {/* Collect the number of positive lymph nodes. */}
                <div className="form-field">
                    <label htmlFor="lymph_nodes_examined_positive">
                        Positive lymph nodes
                    </label>

                    <input
                        id="lymph_nodes_examined_positive"
                        name="lymph_nodes_examined_positive"
                        type="number"
                        min="0"
                        step="1"
                        value={
                            patient.lymph_nodes_examined_positive
                        }
                        onChange={(event) =>
                            onChange(
                                "lymph_nodes_examined_positive",
                                Number(event.target.value),
                            )
                        }
                        aria-invalid={
                            errors.lymph_nodes_examined_positive
                                ? "true"
                                : "false"
                        }
                        aria-describedby={
                            errors.lymph_nodes_examined_positive
                                ? "lymph_nodes_examined_positive-error"
                                : undefined
                        }
                    />

                    {errors.lymph_nodes_examined_positive && (
                        <p
                            id="lymph_nodes_examined_positive-error"
                            className="form-error"
                            role="alert"
                        >
                            {
                                errors.lymph_nodes_examined_positive
                            }
                        </p>
                    )}
                </div>

                {/* Select the tumour grade. */}
                <div className="form-field">
                    <label htmlFor="grade">
                        Tumour grade
                    </label>

                    <select
                        id="grade"
                        name="grade"
                        value={patient.grade}
                        onChange={(event) =>
                            onChange(
                                "grade",
                                Number(event.target.value),
                            )
                        }
                    >
                        <option value={1}>Grade 1</option>
                        <option value={2}>Grade 2</option>
                        <option value={3}>Grade 3</option>
                    </select>
                </div>

                {/* Select the tumour stage. */}
                <div className="form-field">
                    <label htmlFor="tumor_stage">
                        Tumour stage
                    </label>

                    <select
                        id="tumor_stage"
                        name="tumor_stage"
                        value={patient.tumor_stage}
                        onChange={(event) =>
                            onChange(
                                "tumor_stage",
                                Number(event.target.value),
                            )
                        }
                    >
                        <option value={0}>Stage 0</option>
                        <option value={1}>Stage 1</option>
                        <option value={2}>Stage 2</option>
                        <option value={3}>Stage 3</option>
                        <option value={4}>Stage 4</option>
                    </select>
                </div>

                {/* Select the patient's menopausal state. */}
                <div className="form-field">
                    <label htmlFor="inferred_menopausal_state">
                        Menopausal state
                    </label>

                    <select
                        id="inferred_menopausal_state"
                        name="inferred_menopausal_state"
                        value={
                            patient.inferred_menopausal_state
                        }
                        onChange={(event) =>
                            onChange(
                                "inferred_menopausal_state",
                                event.target.value,
                            )
                        }
                    >
                        <option value="Pre">
                            Pre-menopausal
                        </option>
                        <option value="Post">
                            Post-menopausal
                        </option>
                    </select>
                </div>
            </div>
        </fieldset>
    );
}

export default ClinicalFields;