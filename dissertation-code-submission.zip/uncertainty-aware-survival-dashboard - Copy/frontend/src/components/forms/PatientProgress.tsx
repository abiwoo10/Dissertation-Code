// ---------------------------------------------------------------------------
// Patient Progress Properties
// ---------------------------------------------------------------------------

// Define the current workflow step.
interface PatientProgressProps {
    currentStep: 1 | 2 | 3 | 4 | 5;
}


// ---------------------------------------------------------------------------
// Workflow Steps
// ---------------------------------------------------------------------------

// Define the steps in the prognosis workflow.
const steps = [
    {
        number: 1,
        shortLabel: "Clinical",
        fullLabel: "Clinical characteristics",
    },
    {
        number: 2,
        shortLabel: "Pathology",
        fullLabel: "Receptor and pathology characteristics",
    },
    {
        number: 3,
        shortLabel: "Molecular",
        fullLabel: "Molecular characteristics",
    },
    {
        number: 4,
        shortLabel: "Review",
        fullLabel: "Review patient details",
    },
    {
        number: 5,
        shortLabel: "Prognosis",
        fullLabel: "Patient-specific prognosis",
    },
] as const;


// ---------------------------------------------------------------------------
// Patient Progress
// ---------------------------------------------------------------------------

// Display the patient's progress through the prognosis workflow.
function PatientProgress({
                             currentStep,
                         }: PatientProgressProps) {
    // Get the current workflow step.
    const current =
        steps.find((step) => step.number === currentStep)
        ?? steps[0];

    return (
        <nav
            className="patient-progress"
            aria-label="Prognosis workflow progress"
        >
            {/* Display the mobile progress indicator. */}
            <div className="patient-progress__mobile">
        <span>
            Step {currentStep} of {steps.length}
        </span>

                <strong>
                    {current.fullLabel}
                </strong>

                <div
                    className="patient-progress__bar"
                    aria-hidden="true"
                >
          <span
              style={{
                  width: `${(currentStep / steps.length) * 100}%`,
              }}
          />
                </div>
            </div>

            {/* Display each step in the prognosis workflow. */}
            <ol className="patient-progress__steps">
                {steps.map((step) => {
                    // Check the status of the current step.
                    const isCurrent =
                        step.number === currentStep;

                    const isComplete =
                        step.number < currentStep;

                    return (
                        <li
                            key={step.number}
                            className={[
                                "patient-progress__step",
                                isCurrent
                                    ? "patient-progress__step--current"
                                    : "",
                                isComplete
                                    ? "patient-progress__step--complete"
                                    : "",
                            ]
                                .filter(Boolean)
                                .join(" ")}
                            aria-current={
                                isCurrent ? "step" : undefined
                            }
                        >
              <span
                  className="patient-progress__number"
                  aria-hidden="true"
              >
                {isComplete ? "✓" : step.number}
              </span>
                            <span className="patient-progress__label">
                  {step.shortLabel}
              </span>
                        </li>
                    );
                })}
            </ol>
        </nav>
    );
}

export default PatientProgress;