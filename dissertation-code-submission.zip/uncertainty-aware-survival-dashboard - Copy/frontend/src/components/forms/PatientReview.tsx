import type { PatientData } from "../../types/patient";


// ---------------------------------------------------------------------------
// Patient Review Properties
// ---------------------------------------------------------------------------

// Define the patient data and review action handlers.
interface PatientReviewProps {
    patient: PatientData;
    onEdit: () => void;
    onBack: () => void;
    onConfirm: () => void;
    isLoading: boolean;
}


// ---------------------------------------------------------------------------
// Review Sections
// ---------------------------------------------------------------------------

// Define the patient fields displayed in each review section.
const reviewSections: Array<{
    heading: string;
    rows: Array<{
        label: string;
        field: keyof PatientData;
        suffix?: string;
    }>;
}> = [
    {
        heading: "Clinical characteristics",
        rows: [
            {
                label: "Age at diagnosis",
                field: "age_at_diagnosis",
                suffix: " years",
            },
            {
                label: "Tumour size",
                field: "tumor_size",
                suffix: " mm",
            },
            {
                label: "Positive lymph nodes",
                field: "lymph_nodes_examined_positive",
            },
            {
                label: "Tumour grade",
                field: "grade",
            },
            {
                label: "Tumour stage",
                field: "tumor_stage",
            },
            {
                label: "Menopausal state",
                field: "inferred_menopausal_state",
            },
        ],
    },
    {
        heading: "Receptor and pathology characteristics",
        rows: [
            {
                label: "ER status",
                field: "er_status",
            },
            {
                label: "PR status",
                field: "pr_status",
            },
            {
                label: "HER2 status",
                field: "her2_status",
            },
            {
                label: "Cellularity",
                field: "cellularity",
            },
            {
                label: "Histological subtype",
                field: "histological_subtype",
            },
        ],
    },
    {
        heading: "Molecular characteristics",
        rows: [
            {
                label: "Integrative cluster",
                field: "integrative_cluster",
            },
            {
                label: "Tumour mutational burden",
                field: "tmb_nonsynonymous",
            },
        ],
    },
];


// ---------------------------------------------------------------------------
// Patient Review
// ---------------------------------------------------------------------------

// Display the patient details before prognosis generation.
function PatientReview({
                           patient,
                           onEdit,
                           onBack,
                           onConfirm,
                           isLoading,
                       }: PatientReviewProps) {
    return (
        <section
            className="review-panel"
            aria-labelledby="patient-review-heading"
        >
            {/* Display the review heading and edit control. */}
            <div className="review-panel__header">
                <div>
                    <h3 id="patient-review-heading">
                        Confirm patient details
                    </h3>

                    <p>
                        Review all clinical, pathological, and molecular
                        characteristics before generating a prognosis.
                    </p>
                </div>

                <button
                    type="button"
                    className="button button--secondary"
                    onClick={onEdit}
                    disabled={isLoading}
                >
                    Edit patient details
                </button>
            </div>

            {/* Display the patient details by review section. */}
            <div className="review-sections">
                {reviewSections.map((section) => (
                    <section
                        className="review-section"
                        key={section.heading}
                    >
                        <h4>
                            {section.heading}
                        </h4>

                        <dl className="review-grid">
                            {section.rows.map(
                                ({
                                     label,
                                     field,
                                     suffix = "",
                                 }) => (
                                    <div
                                        className="review-item"
                                        key={field}
                                    >
                                        <dt>
                                            {label}
                                        </dt>

                                        <dd>
                                            {String(patient[field])}
                                            {suffix}
                                        </dd>
                                    </div>
                                ),
                            )}
                        </dl>
                    </section>
                ))}
            </div>

            {/* Display the review navigation and confirmation controls. */}
            <div className="review-actions">
                <button
                    type="button"
                    className="button button--secondary"
                    onClick={onBack}
                    disabled={isLoading}
                >
                    Back
                </button>

                <button
                    type="button"
                    className="button button--primary"
                    onClick={onConfirm}
                    disabled={isLoading}
                >
                    {isLoading
                        ? "Generating prognosis…"
                        : "Generate prognosis"}
                </button>
            </div>
        </section>
    );
}

export default PatientReview;