import type { PatientData } from "../../types/patient";
import type { PatientFieldErrors } from "../../validation/patientValidation";


// ---------------------------------------------------------------------------
// Molecular Field Properties
// ---------------------------------------------------------------------------

// Define the patient data, validation errors, and change handler.
interface MolecularFieldsProps {
    patient: PatientData;
    errors: PatientFieldErrors;
    onChange: (
        field: keyof PatientData,
        value: string | number,
    ) => void;
}


// ---------------------------------------------------------------------------
// Molecular Fields
// ---------------------------------------------------------------------------

// Display the molecular patient input fields.
function MolecularFields({
                             patient,
                             errors,
                             onChange,
                         }: MolecularFieldsProps) {
    return (
        <fieldset className="form-section">
            <legend>Molecular characteristics</legend>

            <p className="form-section__description">
                These variables are used by the extended prognostic model.
            </p>

            <div className="form-grid">

                {/* Select the patient's integrative cluster. */}
                <div className="form-field">
                    <label htmlFor="integrative_cluster">
                        Integrative cluster
                    </label>

                    <select
                        id="integrative_cluster"
                        name="integrative_cluster"
                        value={patient.integrative_cluster}
                        onChange={(event) =>
                            onChange(
                                "integrative_cluster",
                                event.target.value,
                            )
                        }
                        aria-invalid={
                            errors.integrative_cluster ? "true" : "false"
                        }
                        aria-describedby={
                            errors.integrative_cluster
                                ? "integrative_cluster-error"
                                : "integrative_cluster-help"
                        }
                    >
                        <option value="1">Cluster 1</option>
                        <option value="2">Cluster 2</option>
                        <option value="3">Cluster 3</option>
                        <option value="4ER+">Cluster 4 ER+</option>
                        <option value="4ER-">Cluster 4 ER-</option>
                        <option value="5">Cluster 5</option>
                        <option value="6">Cluster 6</option>
                        <option value="7">Cluster 7</option>
                        <option value="8">Cluster 8</option>
                        <option value="9">Cluster 9</option>
                        <option value="10">Cluster 10</option>
                    </select>

                    <p
                        id="integrative_cluster-help"
                        className="form-help"
                    >
                        METABRIC molecular subtype combining genomic and expression
                        characteristics.
                    </p>

                    {errors.integrative_cluster && (
                        <p
                            id="integrative_cluster-error"
                            className="form-error"
                            role="alert"
                        >
                            {errors.integrative_cluster}
                        </p>
                    )}
                </div>

                {/* Collect the patient's tumour mutational burden. */}
                <div className="form-field">
                    <label htmlFor="tmb_nonsynonymous">
                        Tumour mutational burden
                    </label>

                    <input
                        id="tmb_nonsynonymous"
                        name="tmb_nonsynonymous"
                        type="number"
                        min="0"
                        step="0.1"
                        value={
                            Number.isFinite(patient.tmb_nonsynonymous)
                                ? patient.tmb_nonsynonymous
                                : ""
                        }
                        onChange={(event) =>
                            onChange(
                                "tmb_nonsynonymous",
                                event.target.value === ""
                                    ? Number.NaN
                                    : Number(event.target.value),
                            )
                        }
                        aria-invalid={
                            errors.tmb_nonsynonymous ? "true" : "false"
                        }
                        aria-describedby={
                            errors.tmb_nonsynonymous
                                ? "tmb_nonsynonymous-error"
                                : "tmb_nonsynonymous-help"
                        }
                    />

                    <p
                        id="tmb_nonsynonymous-help"
                        className="form-help"
                    >
                        Number of non-synonymous mutations per megabase.
                    </p>

                    {errors.tmb_nonsynonymous && (
                        <p
                            id="tmb_nonsynonymous-error"
                            className="form-error"
                            role="alert"
                        >
                            {errors.tmb_nonsynonymous}
                        </p>
                    )}
                </div>
            </div>
        </fieldset>
    );
}

export default MolecularFields;