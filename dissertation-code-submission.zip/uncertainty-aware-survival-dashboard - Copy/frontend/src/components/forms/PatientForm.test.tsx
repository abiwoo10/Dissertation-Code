import {
    render,
    screen,
} from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import {
    MemoryRouter,
    Route,
    Routes,
} from "react-router";
import {
    beforeEach,
    describe,
    expect,
    it,
    vi,
} from "vitest";

import PatientForm from "./PatientForm";

import type { PrognosisResponse } from "../../types/prognosis";


// ---------------------------------------------------------------------------
// Test Setup
// ---------------------------------------------------------------------------

// Create the mocked prognosis generator.
const mockGeneratePrognosis = vi.fn();

// Mock the prognosis hook.
vi.mock("../../hooks/usePrognosis", () => ({
    usePrognosis: () => ({
        data: null,
        error: null,
        isLoading: false,
        generatePrognosis: mockGeneratePrognosis,
    }),
}));

// Define an example prognosis response.
const examplePrognosis: PrognosisResponse = {
    model_name: "MTLR X-CAL Deep Ensemble",

    one_year: {
        probability: 0.95,
        percentage: 95,
        model_disagreement: 0.001,
    },

    three_year: {
        probability: 0.85,
        percentage: 85,
        model_disagreement: 0.002,
    },

    five_year: {
        probability: 0.75,
        percentage: 75,
        model_disagreement: 0.003,
    },

    median_survival_months: 180,
    median_survival_years: 15,

    overall_model_disagreement: 0.005,
    model_disagreement_label: "Lower model disagreement",

    survival_curve: [
        {
            months: 12,
            survival_probability: 0.95,
            lower_disagreement_bound: 0.94,
            upper_disagreement_bound: 0.96,
        },
    ],

    patient_explanation: "Example explanation.",
    uncertainty_explanation: "Example uncertainty explanation.",

    limitations: [
        "Research prototype only.",
    ],
};


// ---------------------------------------------------------------------------
// Test Helpers
// ---------------------------------------------------------------------------

// Render the patient form with the required routes.
function renderPatientForm() {
    return render(
        <MemoryRouter initialEntries={["/patient"]}>
            <Routes>
                <Route
                    path="/patient"
                    element={<PatientForm />}
                />

                <Route
                    path="/prognosis"
                    element={
                        <h1>Prognosis route reached</h1>
                    }
                />
            </Routes>
        </MemoryRouter>,
    );
}

// Move through the form to the review screen.
async function moveToReview(
    user: ReturnType<typeof userEvent.setup>,
) {
    await user.click(
        screen.getByRole("button", {
            name: "Continue",
        }),
    );

    await user.click(
        screen.getByRole("button", {
            name: "Continue",
        }),
    );

    await user.click(
        screen.getByRole("button", {
            name: "Review patient details",
        }),
    );
}


// ---------------------------------------------------------------------------
// Patient Form Tests
// ---------------------------------------------------------------------------

describe("PatientForm", () => {

    // Reset the test state before each test.
    beforeEach(() => {
        mockGeneratePrognosis.mockReset();
        sessionStorage.clear();

        Object.defineProperty(window, "scrollTo", {
            value: vi.fn(),
            writable: true,
        });
    });

    // Check that the form progresses to the review screen.
    it("moves through the form and opens the review screen", async () => {
        const user = userEvent.setup();

        renderPatientForm();

        expect(
            screen.getByRole("heading", {
                name: "Clinical characteristics",
            }),
        ).toBeInTheDocument();

        await user.click(
            screen.getByRole("button", {
                name: "Continue",
            }),
        );

        expect(
            screen.getByRole("heading", {
                name: "Receptor and pathology characteristics",
            }),
        ).toBeInTheDocument();

        await user.click(
            screen.getByRole("button", {
                name: "Continue",
            }),
        );

        expect(
            screen.getByRole("heading", {
                name: "Molecular characteristics",
            }),
        ).toBeInTheDocument();

        await user.click(
            screen.getByRole("button", {
                name: "Review patient details",
            }),
        );

        expect(
            screen.getByRole("heading", {
                name: "Confirm patient details",
            }),
        ).toBeInTheDocument();

        expect(
            screen.getByText("58 years"),
        ).toBeInTheDocument();

        expect(
            screen.getByText("24 mm"),
        ).toBeInTheDocument();
    });

    // Check the validation response for an invalid tumour size.
    it("shows an accessible error for invalid tumour size", async () => {
        const user = userEvent.setup();

        renderPatientForm();

        const tumourSizeInput =
            screen.getByLabelText(
                "Tumour size (mm)",
            );

        await user.clear(tumourSizeInput);
        await user.type(tumourSizeInput, "0");

        await user.click(
            screen.getByRole("button", {
                name: "Continue",
            }),
        );

        expect(
            screen.getByRole("alert"),
        ).toHaveTextContent(
            "Tumour size must be greater than zero.",
        );

        expect(
            tumourSizeInput,
        ).toHaveAttribute(
            "aria-invalid",
            "true",
        );

        expect(
            screen.getByRole("heading", {
                name: "Clinical characteristics",
            }),
        ).toBeInTheDocument();
    });

    // Check that the reviewed patient is submitted.
    it("submits the reviewed patient and navigates to prognosis", async () => {
        const user = userEvent.setup();

        mockGeneratePrognosis.mockResolvedValue(
            examplePrognosis,
        );

        renderPatientForm();

        await moveToReview(user);

        await user.click(
            screen.getByRole("button", {
                name: "Generate prognosis",
            }),
        );

        expect(
            mockGeneratePrognosis,
        ).toHaveBeenCalledTimes(1);

        expect(
            await screen.findByRole("heading", {
                name: "Prognosis route reached",
            }),
        ).toBeInTheDocument();
    });
});