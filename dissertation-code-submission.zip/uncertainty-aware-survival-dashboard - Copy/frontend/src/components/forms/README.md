ClinicalFields.tsx/
Defines the patient form fields used to collect clinical characteristics 
required for prognosis generation.

MolecularFields.tsx/
Defines the patient form fields used to collect molecular and biomarker 
characteristics.

PathologyFields.tsx/
Defines the patient form fields used to collect tumour pathology 
characteristics.

PatientForm.test.tsx/
Tests the patient form behaviour, including patient data entry, validation, 
and progression through the workflow.

PatientForm.tsx/
Coordinates the patient data entry form and manages the clinical, 
pathology, and molecular sections of the workflow.

PatientProgress.tsx/
Displays the patient's current position within the multi-step prognosis 
workflow.

PatientReview.tsx/
Displays the entered patient information for review before the prognosis 
is generated.