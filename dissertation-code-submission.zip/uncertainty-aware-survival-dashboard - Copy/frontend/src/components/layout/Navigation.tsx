import { NavLink } from "react-router";


// ---------------------------------------------------------------------------
// Navigation Properties
// ---------------------------------------------------------------------------

// Define the navigation state and selection handler.
interface NavigationProps {
    isOpen: boolean;
    onNavigate: () => void;
}


// ---------------------------------------------------------------------------
// Navigation Items
// ---------------------------------------------------------------------------

// Define the primary navigation links.
const navigationItems = [
    { label: "Home", path: "/" },
    { label: "Patient input", path: "/patient" },
    { label: "About the model", path: "/about" },
];


// ---------------------------------------------------------------------------
// Navigation
// ---------------------------------------------------------------------------

// Display the primary site navigation.
function Navigation({
                        isOpen,
                        onNavigate,
                    }: NavigationProps) {
    return (
        <nav
            id="primary-navigation"
            className={
                isOpen
                    ? "primary-navigation-wrapper primary-navigation-wrapper--open"
                    : "primary-navigation-wrapper"
            }
            aria-label="Primary navigation"
        >
            {/* Display each navigation link. */}
            <ul className="primary-navigation">
                {navigationItems.map((item) => (
                    <li key={item.path}>
                        <NavLink
                            to={item.path}
                            end={item.path === "/"}
                            onClick={onNavigate}
                            className={({ isActive }) =>
                                isActive
                                    ? "primary-navigation__link primary-navigation__link--active"
                                    : "primary-navigation__link"
                            }
                        >
                            {item.label}
                        </NavLink>
                    </li>
                ))}
            </ul>
        </nav>
    );
}

export default Navigation;