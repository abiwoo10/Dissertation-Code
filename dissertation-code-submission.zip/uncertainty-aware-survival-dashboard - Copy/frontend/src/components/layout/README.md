Footer.tsx/
Defines the shared footer displayed across the application.

Header.tsx/
Defines the shared application header, including branding, 
navigation, theme controls, and responsive menu behaviour.

Navigation.tsx/
Defines the primary navigation links used to move between the main 
sections of the application.