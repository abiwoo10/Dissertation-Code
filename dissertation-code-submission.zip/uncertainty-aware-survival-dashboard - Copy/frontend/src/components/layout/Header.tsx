import { useState } from "react";
import { Link } from "react-router";

import Navigation from "./Navigation";
import { useTheme } from "../../hooks/useTheme";


// ---------------------------------------------------------------------------
// Header
// ---------------------------------------------------------------------------

// Display the site header and navigation controls.
function Header() {
    const { theme, toggleTheme } = useTheme();
    const [menuOpen, setMenuOpen] = useState(false);

    return (
        <header className="site-header">
            {/* Provide direct access to the main page content. */}
            <a className="skip-link" href="#main-content">
                Skip to main content
            </a>

            <div className="site-header__inner page-container">
                {/* Display the dashboard brand and home link. */}
                <Link className="brand" to="/" aria-label="Dashboard home">
          <span className="brand__mark" aria-hidden="true">
            UA
          </span>

                    <span className="brand__text">
            <strong>Uncertainty-Aware</strong>
            <span>Survival Dashboard</span>
          </span>
                </Link>

                {/* Display the navigation and theme controls. */}
                <div className="site-header__actions">
                    <button
                        className="menu-toggle"
                        type="button"
                        aria-expanded={menuOpen}
                        aria-controls="primary-navigation"
                        onClick={() => setMenuOpen((current) => !current)}
                    >
            <span aria-hidden="true">
              {menuOpen ? "✕" : "☰"}
            </span>

                        <span className="visually-hidden">
              {menuOpen ? "Close navigation" : "Open navigation"}
            </span>
                    </button>

                    <button
                        className="theme-toggle"
                        type="button"
                        onClick={toggleTheme}
                        aria-label={`Switch to ${
                            theme === "light" ? "dark" : "light"
                        } mode`}
                        aria-pressed={theme === "dark"}
                    >
            <span aria-hidden="true">
              {theme === "light" ? "☾" : "☀"}
            </span>
                    </button>
                </div>

                {/* Display the primary navigation. */}
                <Navigation
                    isOpen={menuOpen}
                    onNavigate={() => setMenuOpen(false)}
                />
            </div>
        </header>
    );
}

export default Header;