// ---------------------------------------------------------------------------
// Footer
// ---------------------------------------------------------------------------

// Display the site footer.
function Footer() {
    return (
        <footer className="site-footer">
            <div className="site-footer__inner page-container">
                <p>
                    Uncertainty-Aware Survival Dashboard
                </p>

                <p>
                    Research prototype. Not for clinical decision-making.
                </p>
            </div>
        </footer>
    );
}

export default Footer;