import {
    beforeEach,
    describe,
    expect,
    it,
} from "vitest";

import {
    clearPrognosisResult,
    loadPrognosisResult,
    savePrognosisResult,
} from "./prognosisStorage";

import {
    defaultPatientData,
} from "../types/patient";

import type {
    PrognosisResponse,
} from "../types/prognosis";


// ---------------------------------------------------------------------------
// Test Prognosis Data
// ---------------------------------------------------------------------------

// Define a representative prognosis response for storage tests.
const prognosis: PrognosisResponse = {
    model_name: "MTLR X-CAL Deep Ensemble",

    one_year: {
        probability: 0.95,
        percentage: 95,
        model_disagreement: 0.001,
    },

    three_year: {
        probability: 0.85,
        percentage: 85,
        model_disagreement: 0.002,
    },

    five_year: {
        probability: 0.75,
        percentage: 75,
        model_disagreement: 0.003,
    },

    median_survival_months: 180,
    median_survival_years: 15,

    overall_model_disagreement: 0.005,
    model_disagreement_label: "Lower model disagreement",

    survival_curve: [
        {
            months: 12,
            survival_probability: 0.95,
            lower_disagreement_bound: 0.94,
            upper_disagreement_bound: 0.96,
        },
    ],

    patient_explanation: "Example explanation.",
    uncertainty_explanation: "Example uncertainty explanation.",

    limitations: [
        "Research prototype only.",
    ],
};


// ---------------------------------------------------------------------------
// Prognosis Storage Tests
// ---------------------------------------------------------------------------

describe("prognosisStorage", () => {
    // Clear session storage before each test.
    beforeEach(() => {
        sessionStorage.clear();
    });

    // Check that a prognosis can be saved and restored.
    it("saves and restores a prognosis", () => {
        savePrognosisResult({
            patient: defaultPatientData,
            prognosis,
        });

        expect(
            loadPrognosisResult(),
        ).toEqual({
            patient: defaultPatientData,
            prognosis,
        });
    });

    // Check that a saved prognosis can be removed.
    it("clears a saved prognosis", () => {
        savePrognosisResult({
            patient: defaultPatientData,
            prognosis,
        });

        clearPrognosisResult();

        expect(
            loadPrognosisResult(),
        ).toBeNull();
    });

    // Check that invalid JSON is removed from storage.
    it("removes invalid stored JSON", () => {
        sessionStorage.setItem(
            "survival-dashboard-prognosis",
            "{invalid",
        );

        expect(
            loadPrognosisResult(),
        ).toBeNull();
    });

    // Check that stored data with an invalid structure is removed.
    it("removes stored data with an invalid shape", () => {
        sessionStorage.setItem(
            "survival-dashboard-prognosis",
            JSON.stringify({
                patient: null,
                prognosis: null,
            }),
        );

        expect(loadPrognosisResult()).toBeNull();
    });
});