import type { PatientData } from "../types/patient";
import type { PrognosisResponse } from "../types/prognosis";


// ---------------------------------------------------------------------------
// API Configuration
// ---------------------------------------------------------------------------

// Define the prediction API base URL from the environment or local default.
const API_BASE_URL =
    import.meta.env.VITE_API_BASE_URL ?? "http://127.0.0.1:8000";


// ---------------------------------------------------------------------------
// Prognosis API Error
// ---------------------------------------------------------------------------

// Define a custom error for prognosis API request failures.
export class PrognosisApiError extends Error {
    constructor(message: string) {
        super(message);
        this.name = "PrognosisApiError";
    }
}


// ---------------------------------------------------------------------------
// Prognosis Request
// ---------------------------------------------------------------------------

// Request a patient-specific prognosis from the prediction API.
export async function requestPrognosis(
    patient: PatientData,
    signal?: AbortSignal,
): Promise<PrognosisResponse> {
    let response: Response;

    // Send the patient data to the prediction endpoint.
    try {
        response = await fetch(
            `${API_BASE_URL}/predict`,
            {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    Accept: "application/json",
                },
                body: JSON.stringify(patient),
                signal,
            },
        );
    } catch (error) {
        // Preserve intentionally aborted requests.
        if (error instanceof DOMException && error.name === "AbortError") {
            throw error;
        }

        throw new PrognosisApiError(
            "Unable to connect to the prediction service.",
        );
    }

    let payload: unknown;

    // Parse the prediction service response.
    try {
        payload = await response.json();
    } catch {
        throw new PrognosisApiError(
            "The prediction service returned invalid JSON.",
        );
    }

    // Convert unsuccessful API responses into prognosis errors.
    if (!response.ok) {
        const detail =
            typeof payload === "object"
            && payload !== null
            && "detail" in payload
                ? String(payload.detail)
                : `Prediction request failed with status ${response.status}.`;

        throw new PrognosisApiError(detail);
    }

    // Validate the expected structure of the prognosis response.
    if (
        typeof payload !== "object"
        || payload === null
        || !("model_name" in payload)
        || !("one_year" in payload)
        || !("three_year" in payload)
        || !("five_year" in payload)
        || !("survival_curve" in payload)
        || !Array.isArray(payload.survival_curve)
    ) {
        throw new PrognosisApiError(
            "The prediction service returned an invalid prognosis response.",
        );
    }

    return payload as PrognosisResponse;
}