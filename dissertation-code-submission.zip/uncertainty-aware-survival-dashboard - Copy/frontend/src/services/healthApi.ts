import type { HealthResponse } from "../types/health";


// ---------------------------------------------------------------------------
// API Configuration
// ---------------------------------------------------------------------------

// Define the prediction API base URL from the environment or local default.
const API_BASE_URL =
    import.meta.env.VITE_API_BASE_URL ?? "http://127.0.0.1:8000";


// ---------------------------------------------------------------------------
// Health Status Request
// ---------------------------------------------------------------------------

// Request the current health status of the prediction API.
export async function fetchHealthStatus(
    signal?: AbortSignal,
): Promise<HealthResponse> {
    const response = await fetch(
        `${API_BASE_URL}/health`,
        {
            method: "GET",
            headers: {
                Accept: "application/json",
            },
            signal,
        },
    );

    // Reject unsuccessful HTTP responses.
    if (!response.ok) {
        throw new Error(
            `Health request failed with status ${response.status}.`,
        );
    }

    const payload: unknown = await response.json();

    // Validate the structure of the health response.
    if (
        typeof payload !== "object"
        || payload === null
        || !("status" in payload)
        || !("model_loaded" in payload)
        || typeof payload.status !== "string"
        || typeof payload.model_loaded !== "boolean"
    ) {
        throw new Error(
            "The API returned an invalid health response.",
        );
    }

    return payload as HealthResponse;
}