import type { PatientData } from "../types/patient";
import type { PrognosisResponse } from "../types/prognosis";


// ---------------------------------------------------------------------------
// Storage Configuration
// ---------------------------------------------------------------------------

// Define the session storage key used to persist prognosis results.
const STORAGE_KEY = "survival-dashboard-prognosis";


// ---------------------------------------------------------------------------
// Stored Prognosis
// ---------------------------------------------------------------------------

// Define the patient data and prognosis stored together in the session.
export interface StoredPrognosis {
    patient: PatientData;
    prognosis: PrognosisResponse;
}


// ---------------------------------------------------------------------------
// Save Prognosis
// ---------------------------------------------------------------------------

// Save a generated prognosis and its patient data to session storage.
export function savePrognosisResult(
    result: StoredPrognosis,
): void {
    sessionStorage.setItem(
        STORAGE_KEY,
        JSON.stringify(result),
    );
}


// ---------------------------------------------------------------------------
// Load Prognosis
// ---------------------------------------------------------------------------

// Load and validate a previously saved prognosis from session storage.
export function loadPrognosisResult(): StoredPrognosis | null {
    const storedValue = sessionStorage.getItem(
        STORAGE_KEY,
    );

    // Return no result when nothing has been stored.
    if (!storedValue) {
        return null;
    }

    try {
        const parsed: unknown = JSON.parse(
            storedValue,
        );

        // Remove stored data that does not match the expected structure.
        if (
            typeof parsed !== "object"
            || parsed === null
            || !("patient" in parsed)
            || !("prognosis" in parsed)
            || typeof parsed.patient !== "object"
            || parsed.patient === null
            || typeof parsed.prognosis !== "object"
            || parsed.prognosis === null
        ) {
            clearPrognosisResult();
            return null;
        }

        return parsed as StoredPrognosis;
    } catch {
        // Remove stored data that cannot be parsed as JSON.
        clearPrognosisResult();
        return null;
    }
}


// ---------------------------------------------------------------------------
// Clear Prognosis
// ---------------------------------------------------------------------------

// Remove the saved prognosis from session storage.
export function clearPrognosisResult(): void {
    sessionStorage.removeItem(
        STORAGE_KEY,
    );
}