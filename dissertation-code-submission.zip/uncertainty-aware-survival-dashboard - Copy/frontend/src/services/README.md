healthApi.ts/
Handles requests to the API health endpoint and validates the returned 
service status.

prognosisApi.ts/
Sends patient data to the prediction API and handles prognosis responses, 
connection failures, and invalid API results.

prognosisStorage.test.ts/
Tests the prognosis storage functions to ensure results can be saved, 
loaded, cleared, and safely handled when stored data is invalid.

prognosisStorage.ts/
Manages temporary prognosis results in session storage so patient data 
and predictions can be retained between frontend pages.