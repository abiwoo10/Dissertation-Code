import "@testing-library/jest-dom/vitest";

import { afterEach } from "vitest";
import { cleanup } from "@testing-library/react";


// ---------------------------------------------------------------------------
// Test Cleanup
// ---------------------------------------------------------------------------

// Reset the rendered components and browser storage after each test.
afterEach(() => {
    cleanup();
    sessionStorage.clear();
    localStorage.clear();
});