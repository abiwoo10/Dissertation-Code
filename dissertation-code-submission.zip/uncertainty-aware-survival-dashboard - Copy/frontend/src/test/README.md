setup.ts/
Configures the shared frontend testing environment and clears rendered 
components and browser storage after each test.