/// <reference types="vitest/config" />

import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";


// ---------------------------------------------------------------------------
// Vite Configuration
// ---------------------------------------------------------------------------

// Configure the Vite build environment with React support.
export default defineConfig({
    plugins: [react()],

    // Configure the Vitest environment used by the frontend test suite.
    test: {
        environment: "jsdom",
        globals: true,
        setupFiles: "./src/test/setup.ts",
        css: true,
    },
});