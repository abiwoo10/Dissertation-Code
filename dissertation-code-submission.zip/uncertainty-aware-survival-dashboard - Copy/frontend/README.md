.env.example/
Provides an example environment configuration for the frontend, 
including the base URL used to connect to the prediction API.

.oxlintrc.json/
Configures Oxlint for the React and TypeScript frontend, including rules 
for React hooks and component exports.

index.html/
Provides the HTML entry point for the frontend and the root element into 
which the React application is rendered.

package.json/
Defines the frontend package metadata, npm scripts, runtime dependencies, 
and development dependencies used to build, test, lint, and run the 
application.

package-lock.json/
Records the exact versions and dependency tree of the installed npm 
packages to support reproducible installations.

tsconfig.app.json/
Configures TypeScript compilation and type checking for the browser-based 
React application source code.

tsconfig.json/
Provides the root TypeScript configuration and references the separate 
application and Node.js TypeScript configurations.

tsconfig.node.json/
Configures TypeScript for Node.js-based project files, including the Vite 
configuration.

vite.config.ts/
Configures Vite with React support and defines the Vitest environment and 
setup used by the frontend test suite.