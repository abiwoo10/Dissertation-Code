The original METABRIC dataset is not redistributed with this 
project.

To reproduce the model training pipeline, obtain the METABRIC 
dataset from the appropriate source and place it in this directory 
using the filename expected by the training scripts.

The dashboard itself does not require the raw dataset, as it uses the 
pre-trained model and preprocessing pipeline included elsewhere in the 
project.