baseline_model_comparison.json/
Stores validation results comparing the clinical and extended Cox and 
MTLR baseline models, including their C-index rankings.

cox_model_comparison.json/
Stores validation results comparing the clinical and extended Cox 
models and the difference in their concordance indices.

ensemble_uncertainty_evaluation.json/
Stores the validation analysis of ensemble disagreement and its 
relationship with prediction error at the 1-, 3-, and 5-year horizons.

example_patient_prognosis.json/
Stores an example patient prognosis from the MTLR model, including 
survival estimates and the predicted survival curve.

final_test_evaluation.json/
Stores the final held-out test evaluation of the X-CAL model and ensemble, 
including discrimination, calibration, and ensemble disagreement results.

kaplan_meier_summary.json/
Stores the Kaplan-Meier cohort summary, including patient and event 
counts, median survival, and survival probabilities at selected time points.

metabric_audit.json/
Stores the METABRIC dataset audit results, including cohort structure, 
survival target completeness, and data-quality checks.

metabric_data_dictionary.csv/
Provides a data dictionary for the METABRIC variables, including their 
source, data type, missingness, unique values, examples, and numeric 
summaries.

metabric_missingness.csv/
Summarises the percentage of missing values for each METABRIC variable.

mtlr_calibration_comparison.json/
Stores validation results comparing the uncalibrated extended MTLR model 
with the X-CAL-regularised model across discrimination and calibration 
metrics.

mtlr_candidate_comparison.json/
Stores the comparison of shortlisted MTLR configurations and identifies 
the candidate selected using validation Integrated Brier Score.

mtlr_extended_calibration.json/
Stores the validation calibration evaluation of the extended MTLR model, 
including C-index, Integrated Brier Score, and D-calibration results.

mtlr_extended_tuning.json/
Stores the full extended MTLR hyperparameter search results across time 
bins, learning rates, and weight decay values.

results_summary.csv/
Summarises and ranks the evaluated survival models using their validation 
performance metrics and comparison with the clinical Cox baseline.

sample_prognosis_response.json/
Stores an example prognosis response from the final X-CAL ensemble, 
including survival estimates, model disagreement, explanations, and the 
survival curve.

xcal_weight_tuning.json/
Stores the X-CAL calibration-weight tuning results and compares candidate 
weights using validation discrimination and calibration metrics.