# METABRIC Feature Selection Policy

## Objective

This project predicts individual overall survival distributions for breast cancer patients and communicates survival probabilities, calibration, and predictive uncertainty in a patient-centred dashboard.

The system is intended to support prognosis communication. It is not a clinical decision-support system and must not present predictions as certainties.

## Prediction target

The survival target is defined using:

- `OS_MONTHS`: observed survival or follow-up duration in months
- `OS_STATUS`: event indicator used to determine whether death occurred or the observation was censored

These variables are used during model training and evaluation. They are never entered by a clinician and are never used as predictor variables.

## Model A: Clinical baseline

The clinical baseline uses variables that are broadly interpretable and relevant to prognosis communication.

- `AGE_AT_DIAGNOSIS`
- `CELLULARITY`
- `LYMPH_NODES_EXAMINED_POSITIVE`
- `ER_STATUS`
- `HER2_STATUS`
- `PR_STATUS`
- `GRADE`
- `TUMOR_SIZE`
- `TUMOR_STAGE`
- `INFERRED_MENOPAUSAL_STATE`
- `HISTOLOGICAL_SUBTYPE`

## Model B: Extended comparison model

The extended model contains all Model A features plus selected molecular variables.

- `INTCLUST`
- `TMB_NONSYNONYMOUS`

The purpose of Model B is to evaluate whether molecular information improves discrimination, calibration, and uncertainty estimation compared with the clinical baseline.

## Excluded outcome and leakage variables

The following variables must not be used as model inputs:

- `OS_MONTHS`
- `OS_STATUS`
- `VITAL_STATUS`
- `RFS_MONTHS`
- `RFS_STATUS`

`OS_MONTHS` and `OS_STATUS` define the target. The remaining variables contain future outcome information and would introduce data leakage.

## Excluded identifiers and metadata

- `PATIENT_ID`
- `SAMPLE_ID`
- `ONCOTREE_CODE`

Identifiers do not carry valid prognostic information. `ONCOTREE_CODE` is excluded initially because it is primarily a diagnostic classification and may overlap with histological subtype.

## Deferred variables

The following variables may be considered in later exploratory experiments:

- `CLAUDIN_SUBTYPE`
- `HER2_SNP6`
- `THREEGENE`
- `NPI`
- `LATERALITY`
- treatment variables

`NPI` is deferred because it combines tumour size, grade, and lymph-node information already represented as separate features. Treatment variables require a clearly defined prediction time and intended-use scenario before inclusion.