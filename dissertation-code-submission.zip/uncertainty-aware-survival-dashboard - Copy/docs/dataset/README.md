DATA_PROVENANCE.md/
Documents the source, acquisition details, archive contents, 
checksum, and storage policy for the METABRIC dataset.

DATASET_CARD.md/
Provides the template used to document a dataset’s source, population, 
survival endpoint, predictors, limitations, and suitability for the project.

DATASET_CARD_METABRIC.md/
Documents METABRIC’s intended use, survival outcome, storage requirements, 
known risks, and initial cohort audit for the project.

DATASET_CARD_TCGA_BRCA.md/
Documents TCGA-BRCA as a potential external validation dataset, 
including its intended scope, requirements, and known harmonisation risks.

DATASET_SELECTION.md/
Documents the selection of METABRIC for model development and TCGA-BRCA 
as an optional external validation cohort, together with the proposed 
endpoint and feature strategy.

FEATURE_DICTIONARY.md/
Defines the fields used to document each model feature, including its 
source name, type, valid values, transformation, modelling role, and 
dashboard label.

PREPROCESSING_PLAN.md/
Provides a placeholder for documenting the planned dataset preprocessing 
workflow.