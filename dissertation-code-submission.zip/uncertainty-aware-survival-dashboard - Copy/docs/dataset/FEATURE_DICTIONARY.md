| Field                        | Meaning                             |
| ---------------------------- | ----------------------------------- |
| Raw name                     | Original column name                |
| Canonical name               | Name used by our code               |
| Type                         | Numeric, categorical, boolean       |
| Unit                         | Years, millimetres, months, etc.    |
| Valid values                 | Permitted range or categories       |
| Missing-value encoding       | Blank, NA, -999, Unknown            |
| Predictor/target             | Role in modelling                   |
| Available at prediction time | Yes or no                           |
| Transformation               | Scaling, encoding, grouping         |
| Dashboard label              | Patient-facing display text         |
| Include/exclude              | Final decision                      |
| Reason                       | Clinical or technical justification |
