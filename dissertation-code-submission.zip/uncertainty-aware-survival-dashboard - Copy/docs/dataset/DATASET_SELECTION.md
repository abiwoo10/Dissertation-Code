# Dataset Selection

## Proposed Primary Dataset

METABRIC is the proposed development dataset.

The dataset will be used for:

- model training;
- hyperparameter selection;
- internal validation;
- final internal testing;
- uncertainty estimation;
- calibration evaluation;
- dashboard development.

## Proposed External Dataset

TCGA-BRCA is proposed as an optional external validation cohort.

External validation is a stretch objective and will not replace the
held-out METABRIC test partition. Its feasibility depends on identifying
a sufficiently complete and semantically compatible set of clinical
predictors in both datasets.

## Proposed Primary Endpoint

Overall survival from diagnosis.

- Time variable: To be confirmed during the raw-data audit
- Event variable: To be confirmed during the raw-data audit
- Event = 1: Death from any cause
- Event = 0: Censored at the final known follow-up
- Time unit: Months
- Time origin: Diagnosis, subject to source-data confirmation

## Proposed Feature Strategy

Two feature configurations may be maintained:

1. A METABRIC clinical feature set for primary model development.
2. A reduced harmonised clinical feature set for possible TCGA-BRCA
   external validation.

Genomic features are optional and will only be considered after the
clinical modelling and evaluation pipeline is complete.

## Current Decision Status

Proposed — awaiting acquisition and audit of the source data.

## Purpose

## Research Requirements

## Candidate Datasets

### METABRIC

### TCGA-BRCA

### Fallback Dataset

## Selection Criteria

## Comparison Matrix

## Risks and Limitations

## Selected Dataset

## Decision Rationale

## Decision Status
