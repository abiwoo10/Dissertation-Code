# Dataset Card: TCGA-BRCA

## Status

Candidate external validation dataset.

## Intended Use

Optional external evaluation of a model trained using a harmonised
clinical feature subset from METABRIC.

## Scope

TCGA-BRCA is not required for completion of the core project. External
validation will proceed only if:

- the METABRIC pipeline is complete;
- equivalent predictor definitions can be established;
- the overall-survival endpoint is suitable;
- missingness is acceptable;
- sufficient time remains.

## Access Requirement

Only openly accessible data will be used. Controlled-access files are
outside the project scope.

## Proposed Outcome

Overall survival, harmonised as closely as possible with the primary
METABRIC endpoint.

## Known Risks

- Different cohort characteristics
- Different follow-up distribution
- Different clinical coding
- Missing common predictors
- Different molecular platforms
- Smaller effective sample after harmonisation
- Reduced number of observed deaths
- Dataset shift
- Apparent model degradation caused by endpoint mismatch

## Decision Status

Optional / feasibility not yet confirmed.
