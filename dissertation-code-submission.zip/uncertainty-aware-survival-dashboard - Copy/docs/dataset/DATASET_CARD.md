# Dataset Card

## Dataset Name

## Version

## Source

## Original Study

## Intended Use

## Population

## Sample Size

## Inclusion Criteria

## Exclusion Criteria

## Survival Endpoint

## Time Origin

## Censoring Definition

## Predictor Groups

## Missing Data

## Known Biases

## Ethical and Legal Considerations

## Licence and Access Restrictions

## Suitability for This Project

## Prohibited or Unsupported Uses
