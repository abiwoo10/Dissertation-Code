# Dataset Card: METABRIC

## Status

Acquired and undergoing formal audit.

## Intended Use

Development and evaluation of individual breast cancer overall-survival
prediction models, including calibration and predictive-uncertainty
assessment.

## Intended Predictor Type

Clinical variables are required.

Genomic variables are optional and are outside the minimum viable scope.

## Proposed Outcome

Overall survival from diagnosis.

The exact source columns, event encoding, time origin, and time unit must
be verified from the acquired dataset.

## Access Requirement

Only publicly accessible data will be used.

## Data Storage Policy

Raw and processed patient-level data must not be committed to GitHub.
The repository will contain acquisition instructions, checksums,
schemas, validation code, and synthetic test fixtures only.

## Known Risks

- Missing clinical values
- Ambiguous variable definitions
- Data leakage from post-baseline variables
- Cohort-selection bias
- Treatment variables recorded after diagnosis
- Incomplete subgroup representation
- Mismatch between research variables and dashboard inputs
- Potential differences between downloadable METABRIC versions

## Initial Cohort Audit

- Total patients: 2,509
- Total tumour samples: 2,509
- Unique patient identifiers: 2,509
- Unique sample identifiers: 2,509
- Patients with complete overall-survival time and status: 1,981
- Observed deaths: 1,144
- Censored/living observations: 837
- Missing overall-survival records: 528
- Median recorded overall-survival/follow-up time: approximately 116.5 months
- Maximum recorded time: approximately 355.2 months

The dataset contains a sufficient preliminary number of observed events
for internal survival-model development. Final eligibility depends on
feature availability, missingness, leakage review, and endpoint validation.

## Decision Status

Proposed.
