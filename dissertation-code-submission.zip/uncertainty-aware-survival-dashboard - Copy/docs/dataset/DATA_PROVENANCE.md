# Data Provenance

## METABRIC Source Archive

- Dataset: Breast Cancer METABRIC
- Study identifier: `brca_metabric`
- Study name: Breast Cancer (METABRIC, Nature 2012 & Nat Commun 2016)
- Distribution format: cBioPortal study archive
- Local filename: `brca_metabric.tar.gz`
- Compressed size: approximately 486.7 MiB
- SHA-256: `6d4683477d6b37a2d7edbedc0df610f67bc456f99e5e1bef6219f37b633a55f7`
- Patient records: 2,509
- Sample records: 2,509
- Licence included in archive: ODC Open Database Licence
- Acquisition date: [INSERT DOWNLOAD DATE]

## Relevant Initial Files

- `data_clinical_patient.txt`
- `data_clinical_sample.txt`
- `meta_clinical_patient.txt`
- `meta_clinical_sample.txt`
- `meta_study.txt`
- `LICENSE`

## Storage Policy

The original archive and extracted patient-level data are stored locally
under `data/raw/` and must not be committed to GitHub.
