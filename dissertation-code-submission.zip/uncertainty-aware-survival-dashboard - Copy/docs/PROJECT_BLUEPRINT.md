## Dataset Strategy

The proposed primary dataset is METABRIC. Overall survival will be used
as the primary endpoint, subject to confirmation during the raw-data
audit.

METABRIC will be divided into training, validation, and held-out internal
test partitions.

TCGA-BRCA will be investigated as an optional external validation
cohort. External validation will use a reduced, harmonised clinical
feature set and will not replace internal testing.

Clinical predictors form the required project scope. Genomic predictors
are optional and will only be considered after the complete clinical
pipeline has been implemented and evaluated.
