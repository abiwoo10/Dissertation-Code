# ADR-004: Primary Dataset and Survival Endpoint

## Status

Provisionally Accepted

## Context

The system requires a public breast cancer dataset containing clinical
predictors, survival durations, censoring indicators, and sufficient
follow-up for individual survival-distribution modelling.

External validation is desirable but is not a mandatory dissertation
requirement.

## Decision

METABRIC will be used as the proposed primary development dataset.

Overall survival from diagnosis will be used as the proposed primary
endpoint, subject to verification of the source-data definitions.

The primary cohort will contain separate training, validation, and
held-out test partitions.

TCGA-BRCA will be evaluated as an optional external validation cohort.
A model externally evaluated on TCGA-BRCA will use only predictors that
can be semantically and technically harmonised across both datasets.

Clinical predictors are required. Genomic predictors are optional and
will not be introduced until the core clinical pipeline is complete.

## Consequences

### Positive

- METABRIC provides a sizeable breast cancer cohort with long-term
  clinical outcomes.
- Overall survival has a comparatively clear event definition.
- Internal and external evaluation answer different research questions.
- The core project remains achievable without external validation.
- The clinical-first strategy is computationally feasible.

### Negative

- Overall survival includes deaths unrelated to breast cancer.
- TCGA-BRCA may have different follow-up and event distributions.
- External validation may require a smaller predictor set.
- Some potentially useful genomic information will not be used in the
  initial system.
- Harmonisation may prove infeasible.

## Review Trigger

This decision must be reviewed after:

1. METABRIC acquisition and audit;
2. endpoint verification;
3. predictor and missingness analysis;
4. preliminary TCGA-BRCA feasibility analysis.
