metabric_feature_selection.md/
Documents the METABRIC feature-selection policy, including the clinical 
and extended predictor sets and variables excluded to prevent outcome 
leakage.

PROJECT_BLUEPRINT.md/
Summarises the project’s dataset strategy, including the use of METABRIC 
for development and internal evaluation and TCGA-BRCA as an optional 
external validation cohort.

RISK_REGISTER.md/
Records key dataset and project risks, their likelihood and impact, and 
the planned mitigation for each risk.