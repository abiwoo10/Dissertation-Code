from __future__ import annotations

import torch


# ---------------------------------------------------------------------------
# Soft Membership
# ---------------------------------------------------------------------------

# Calculate soft membership within the specified CDF bounds.
def soft_membership(
    values: torch.Tensor,
    lower_bound: float,
    upper_bound: float,
    gamma: float = 10_000.0,
) -> torch.Tensor:

    if gamma <= 0:
        raise ValueError("gamma must be positive.")

    if not 0.0 <= lower_bound < upper_bound <= 1.0:
        raise ValueError(
            "Bounds must satisfy 0 <= lower_bound < upper_bound <= 1."
        )

    # Calculate the soft membership values.
    return torch.sigmoid(
        gamma
        * (values - lower_bound)
        * (upper_bound - values)
    )


# ---------------------------------------------------------------------------
# Censored Soft Membership
# ---------------------------------------------------------------------------

# Calculate the soft contribution of censored observations to a CDF bin.
def censored_soft_membership(
    cdf_at_censoring: torch.Tensor,
    lower_bound: float,
    upper_bound: float,
    gamma: float = 10_000.0,
    epsilon: float = 1e-7,
) -> torch.Tensor:

    if gamma <= 0:
        raise ValueError("gamma must be positive.")

    if epsilon <= 0:
        raise ValueError("epsilon must be positive.")

    if not 0.0 <= lower_bound < upper_bound <= 1.0:
        raise ValueError(
            "Bounds must satisfy 0 <= lower_bound < upper_bound <= 1."
        )

    # Calculate the remaining CDF range after the censoring point.
    denominator = torch.clamp(
        1.0 - cdf_at_censoring,
        min=epsilon,
    )

    # Calculate the contribution when the censoring CDF is within the bin.
    within_bin_contribution = (
        (upper_bound - cdf_at_censoring)
        * soft_membership(
            cdf_at_censoring,
            lower_bound=lower_bound,
            upper_bound=upper_bound,
            gamma=gamma,
        )
    )

    # Calculate the contribution when the censoring CDF is below the bin.
    below_bin_contribution = (
        (upper_bound - lower_bound)
        * torch.sigmoid(
            gamma
            * (
                lower_bound
                - cdf_at_censoring
            )
        )
    )

    # Combine and scale the censored contributions.
    contribution = (
        within_bin_contribution
        + below_bin_contribution
    ) / denominator

    # Restrict the contribution to the valid probability range.
    return torch.clamp(
        contribution,
        min=0.0,
        max=1.0,
    )


# ---------------------------------------------------------------------------
# X-CAL Loss
# ---------------------------------------------------------------------------

# Calculate the censoring-aware X-CAL loss.
def xcal_loss(
    cdf_at_observed_time: torch.Tensor,
    event: torch.Tensor,
    number_of_bins: int = 10,
    gamma: float = 10_000.0,
) -> torch.Tensor:

    if cdf_at_observed_time.ndim != 1:
        raise ValueError(
            "cdf_at_observed_time must be one-dimensional."
        )

    if event.ndim != 1:
        raise ValueError(
            "event must be one-dimensional."
        )

    if cdf_at_observed_time.shape != event.shape:
        raise ValueError(
            "cdf_at_observed_time and event must have the same shape."
        )

    if cdf_at_observed_time.numel() == 0:
        raise ValueError(
            "cdf_at_observed_time must not be empty."
        )

    if number_of_bins < 2:
        raise ValueError(
            "number_of_bins must be at least 2."
        )

    if gamma <= 0:
        raise ValueError(
            "gamma must be positive."
        )

    if torch.any(
        (cdf_at_observed_time < 0.0)
        | (cdf_at_observed_time > 1.0)
    ):
        raise ValueError(
            "CDF values must be between 0 and 1."
        )

    if torch.any(
        (event != 0)
        & (event != 1)
    ):
        raise ValueError(
            "event must contain only zero and one values."
        )

    # Match the event tensor type and device to the CDF values.
    event = event.to(
        dtype=cdf_at_observed_time.dtype,
        device=cdf_at_observed_time.device,
    )

    # Create equally spaced CDF bin boundaries.
    bin_edges = torch.linspace(
        0.0,
        1.0,
        number_of_bins + 1,
        dtype=cdf_at_observed_time.dtype,
        device=cdf_at_observed_time.device,
    )

    # Initialise the expected bin proportion and calibration loss.
    expected_proportion = 1.0 / number_of_bins
    calibration_loss = torch.zeros(
        (),
        dtype=cdf_at_observed_time.dtype,
        device=cdf_at_observed_time.device,
    )

    # Calculate the calibration contribution for each CDF bin.
    for bin_index in range(number_of_bins):
        lower_bound = float(
            bin_edges[bin_index]
        )
        upper_bound = float(
            bin_edges[bin_index + 1]
        )

        # Calculate the contribution from observed events.
        event_contribution = soft_membership(
            cdf_at_observed_time,
            lower_bound=lower_bound,
            upper_bound=upper_bound,
            gamma=gamma,
        )

        # Calculate the contribution from censored observations.
        censored_contribution = censored_soft_membership(
            cdf_at_observed_time,
            lower_bound=lower_bound,
            upper_bound=upper_bound,
            gamma=gamma,
        )

        # Select the appropriate contribution using the event indicator.
        contribution = (
            event * event_contribution
            + (1.0 - event) * censored_contribution
        )

        # Calculate the observed contribution for the current bin.
        observed_proportion = contribution.mean()

        # Add the difference between the observed and expected proportions.
        calibration_loss = (
            calibration_loss
            + (
                observed_proportion
                - expected_proportion
            ) ** 2
        )

    return calibration_loss