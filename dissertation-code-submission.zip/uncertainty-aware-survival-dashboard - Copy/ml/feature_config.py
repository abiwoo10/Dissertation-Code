from __future__ import annotations


# ---------------------------------------------------------------------------
# Survival target configuration
# ---------------------------------------------------------------------------

# Columns containing the survival duration and event status.
DURATION_COLUMN = "OS_MONTHS"
EVENT_COLUMN = "OS_STATUS"


# ---------------------------------------------------------------------------
# Feature sets
# ---------------------------------------------------------------------------

# Clinical features used as model predictors.
CLINICAL_FEATURES = [
    "AGE_AT_DIAGNOSIS",
    "CELLULARITY",
    "LYMPH_NODES_EXAMINED_POSITIVE",
    "ER_STATUS",
    "HER2_STATUS",
    "PR_STATUS",
    "GRADE",
    "TUMOR_SIZE",
    "TUMOR_STAGE",
    "INFERRED_MENOPAUSAL_STATE",
    "HISTOLOGICAL_SUBTYPE",
]

# Add the additional predictors used by the extended feature set.
EXTENDED_FEATURES = CLINICAL_FEATURES + [
    "INTCLUST",
    "TMB_NONSYNONYMOUS",
]

# Numerical features within the clinical feature set.
CLINICAL_NUMERIC_FEATURES = [
    "AGE_AT_DIAGNOSIS",
    "LYMPH_NODES_EXAMINED_POSITIVE",
    "GRADE",
    "TUMOR_SIZE",
    "TUMOR_STAGE",
]

# Categorical features within the clinical feature set.
CLINICAL_CATEGORICAL_FEATURES = [
    "CELLULARITY",
    "ER_STATUS",
    "HER2_STATUS",
    "PR_STATUS",
    "INFERRED_MENOPAUSAL_STATE",
    "HISTOLOGICAL_SUBTYPE",
]

# Add the additional numerical feature used by the extended feature set.
EXTENDED_NUMERIC_FEATURES = CLINICAL_NUMERIC_FEATURES + [
    "TMB_NONSYNONYMOUS",
]

# Add the additional categorical feature used by the extended feature set.
EXTENDED_CATEGORICAL_FEATURES = CLINICAL_CATEGORICAL_FEATURES + [
    "INTCLUST",
]