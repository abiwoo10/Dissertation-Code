base_model.py/
Defines the common interface and shared functionality used by the 
survival prediction models.

calibration.py/
Provides functions for evaluating the calibration of predicted survival 
distributions.

cox_model.py/
Implements the Cox proportional hazards model used for the clinical and 
extended baseline survival models.

data_loading.py/
Loads the METABRIC dataset and prepares the source data for subsequent 
preprocessing and modelling.

ensemble_model.py/
Implements the MTLR ensemble model and combines predictions from 
multiple trained ensemble members to estimate survival and model 
disagreement.

evaluation.py/
Provides functions for evaluating survival model performance using the 
project's discrimination and calibration metrics.

evaluation_compatibility.py/
Provides compatibility functions used to prepare survival predictions 
and outcomes for evaluation.

feature_config.py/
Defines the clinical and extended feature sets used throughout 
preprocessing and model training.

kaplan_meier.py/
Provides functions for fitting and evaluating the Kaplan-Meier overall 
survival estimate.

mtlr_layer.py/
Defines the PyTorch layer used to produce the MTLR survival model outputs.

mtlr_model.py/
Implements the MTLR survival model, including model training, prediction, 
and model persistence.

mtlr_utils.py/
Provides supporting functions for MTLR time-bin construction, 
target encoding, and survival distribution calculations.

prediction.py/
Defines the common structure used to store survival predictions, 
survival curves, risk scores, and uncertainty outputs.

preprocessing.py/
Prepares the METABRIC data for modelling and manages the preprocessing 
transformations used by the clinical and extended feature sets.

prognosis.py/
Converts survival model outputs into patient-level prognosis summaries, 
including survival estimates and model disagreement information.

xcal.py/
Implements the X-CAL calibration loss and supporting soft-membership 
calculations used during MTLR training.