from __future__ import annotations

import numpy as np
import pandas as pd

import torch


# ---------------------------------------------------------------------------
# Time Bin Creation
# ---------------------------------------------------------------------------

# Build MTLR time-bin boundaries from the uncensored event times.
def build_time_bins(
    duration: pd.Series,
    event: pd.Series,
    number_of_bins: int = 20,
) -> np.ndarray:

    if len(duration) != len(event):
        raise ValueError(
            "duration and event must contain the same number of rows."
        )

    if duration.empty:
        raise ValueError("duration and event must not be empty.")

    if duration.isna().any() or event.isna().any():
        raise ValueError(
            "duration and event must not contain missing values."
        )

    if (duration < 0).any():
        raise ValueError(
            "duration must not contain negative values."
        )

    invalid_events = set(event.unique()) - {0, 1, False, True}

    if invalid_events:
        raise ValueError(
            f"event contains unsupported values: {sorted(invalid_events)}"
        )

    if number_of_bins < 2:
        raise ValueError(
            "number_of_bins must be at least 2."
        )

    # Select the survival durations for uncensored events.
    event_times = (
        duration.loc[event.astype(bool)]
        .astype(float)
        .to_numpy()
    )

    if event_times.size == 0:
        raise ValueError(
            "At least one uncensored event is required to build time bins."
        )

    # Create evenly spaced quantile positions for the requested bins.
    quantiles = np.linspace(
        0.0,
        1.0,
        number_of_bins + 1,
    )

    # Calculate the time boundaries from the event-time quantiles.
    boundaries = np.quantile(
        event_times,
        quantiles,
    )

    # Remove duplicate boundaries.
    boundaries = np.unique(
        boundaries.astype(float)
    )

    if boundaries.size < 2:
        raise ValueError(
            "Event times do not contain enough variation to build time bins."
        )

    return boundaries


# ---------------------------------------------------------------------------
# MTLR Target Encoding
# ---------------------------------------------------------------------------

# Encode observed and censored survival outcomes into MTLR target masks.
def encode_mtlr_targets(
    duration: pd.Series,
    event: pd.Series,
    time_bins: np.ndarray,
) -> np.ndarray:

    if len(duration) != len(event):
        raise ValueError(
            "duration and event must contain the same number of rows."
        )

    if duration.empty:
        raise ValueError("duration and event must not be empty.")

    if duration.isna().any() or event.isna().any():
        raise ValueError(
            "duration and event must not contain missing values."
        )

    if (duration < 0).any():
        raise ValueError(
            "duration must not contain negative values."
        )

    invalid_events = set(event.unique()) - {0, 1, False, True}

    if invalid_events:
        raise ValueError(
            f"event contains unsupported values: {sorted(invalid_events)}"
        )

    time_bins = np.asarray(time_bins, dtype=float)

    if time_bins.ndim != 1 or len(time_bins) < 1:
        raise ValueError(
            "time_bins must be a non-empty one-dimensional array."
        )

    if not np.all(np.diff(time_bins) > 0):
        raise ValueError(
            "time_bins must be strictly increasing."
        )

    # K boundaries produce K + 1 possible event-time intervals.
    interval_count = len(time_bins) + 1

    # Create the target mask for each patient and interval.
    encoded = np.zeros(
        (len(duration), interval_count),
        dtype=np.float32,
    )

    # Assign each patient to the intervals compatible with their outcome.
    for row_index, (time, observed_event) in enumerate(
        zip(
            duration.astype(float),
            event.astype(bool),
        )
    ):
        interval_index = int(
            np.searchsorted(
                time_bins,
                time,
                side="right",
            )
        )

        if observed_event:
            encoded[row_index, interval_index] = 1.0
        else:
            encoded[row_index, interval_index:] = 1.0

    return encoded


# ---------------------------------------------------------------------------
# MTLR Loss
# ---------------------------------------------------------------------------

# Calculate the censored MTLR negative log-likelihood.
def mtlr_negative_log_likelihood(
    interval_logits: torch.Tensor,
    target_mask: torch.Tensor,
    reduction: str = "mean",
) -> torch.Tensor:

    if interval_logits.ndim != 2:
        raise ValueError(
            "interval_logits must be a two-dimensional tensor."
        )

    if target_mask.shape != interval_logits.shape:
        raise ValueError(
            "target_mask must have the same shape as interval_logits."
        )

    if reduction not in {"mean", "sum", "none"}:
        raise ValueError(
            "reduction must be 'mean', 'sum', or 'none'."
        )

    # Match the target mask type and device to the interval logits.
    target_mask = target_mask.to(
        dtype=interval_logits.dtype,
        device=interval_logits.device,
    )

    if torch.any(
        (target_mask != 0)
        & (target_mask != 1)
    ):
        raise ValueError(
            "target_mask must contain only zero and one values."
        )

    if torch.any(target_mask.sum(dim=1) == 0):
        raise ValueError(
            "Every target row must contain at least one valid interval."
        )

    # Calculate the log normaliser across all intervals.
    log_normaliser = torch.logsumexp(
        interval_logits,
        dim=1,
    )

    # Exclude intervals that are not valid for each target.
    masked_logits = interval_logits.masked_fill(
        target_mask == 0,
        float("-inf"),
    )

    # Calculate the log probability across the valid intervals.
    log_valid_probability = torch.logsumexp(
        masked_logits,
        dim=1,
    ) - log_normaliser

    losses = -log_valid_probability

    # Apply the requested loss reduction.
    if reduction == "mean":
        return losses.mean()

    if reduction == "sum":
        return losses.sum()

    return losses


# ---------------------------------------------------------------------------
# Survival Probability Conversion
# ---------------------------------------------------------------------------

# Convert interval probability mass into survival probabilities.
def interval_probabilities_to_survival(
    interval_probabilities: torch.Tensor,
) -> torch.Tensor:

    if interval_probabilities.ndim != 2:
        raise ValueError(
            "interval_probabilities must be a two-dimensional tensor."
        )

    if torch.any(interval_probabilities < 0):
        raise ValueError(
            "interval_probabilities must not contain negative values."
        )

    # Calculate the total probability for each patient.
    row_sums = interval_probabilities.sum(dim=1)

    if not torch.allclose(
        row_sums,
        torch.ones_like(row_sums),
        atol=1e-5,
    ):
        raise ValueError(
            "Each probability row must sum to one."
        )

    # Calculate reverse cumulative probabilities across the intervals.
    reverse_cumulative = torch.flip(
        torch.cumsum(
            torch.flip(interval_probabilities, dims=[1]),
            dim=1,
        ),
        dims=[1],
    )

    # Remove the first value, which is always survival probability 1 before
    # the first event-time interval.
    return reverse_cumulative[:, 1:]


# ---------------------------------------------------------------------------
# CDF Calculation
# ---------------------------------------------------------------------------

# Calculate each patient's predicted CDF at their observed time.
def interval_probabilities_to_cdf_at_times(
    interval_probabilities: torch.Tensor,
    observed_times: torch.Tensor,
    time_bins: np.ndarray,
) -> torch.Tensor:

    if interval_probabilities.ndim != 2:
        raise ValueError(
            "interval_probabilities must be two-dimensional."
        )

    if observed_times.ndim != 1:
        raise ValueError(
            "observed_times must be one-dimensional."
        )

    if interval_probabilities.shape[0] != observed_times.shape[0]:
        raise ValueError(
            "interval_probabilities and observed_times must have "
            "the same number of patients."
        )

    if torch.any(observed_times < 0):
        raise ValueError(
            "observed_times must not contain negative values."
        )

    time_bins_array = np.asarray(
        time_bins,
        dtype=np.float32,
    )

    if (
        time_bins_array.ndim != 1
        or len(time_bins_array) < 1
    ):
        raise ValueError(
            "time_bins must be a non-empty one-dimensional array."
        )

    if not np.all(np.diff(time_bins_array) > 0):
        raise ValueError(
            "time_bins must be strictly increasing."
        )

    expected_interval_count = len(time_bins_array) + 1

    if interval_probabilities.shape[1] != expected_interval_count:
        raise ValueError(
            "interval_probabilities has an unexpected number "
            "of intervals."
        )

    if torch.any(interval_probabilities < 0):
        raise ValueError(
            "interval_probabilities must not contain negative values."
        )

    # Calculate the total probability for each patient.
    row_sums = interval_probabilities.sum(dim=1)

    if not torch.allclose(
        row_sums,
        torch.ones_like(row_sums),
        atol=1e-5,
    ):
        raise ValueError(
            "Each probability row must sum to one."
        )

    # Convert the time bins into a tensor matching the probabilities.
    bins_tensor = torch.tensor(
        time_bins_array,
        dtype=interval_probabilities.dtype,
        device=interval_probabilities.device,
    )

    # Match the observed time type and device to the probabilities.
    observed_times = observed_times.to(
        dtype=interval_probabilities.dtype,
        device=interval_probabilities.device,
    )

    # Find the interval containing each observed time.
    interval_indices = torch.bucketize(
        observed_times,
        bins_tensor,
        right=True,
    )

    # Calculate cumulative probability across the intervals.
    cumulative_probability = torch.cumsum(
        interval_probabilities,
        dim=1,
    )

    # Create an index for each patient.
    patient_indices = torch.arange(
        interval_probabilities.shape[0],
        device=interval_probabilities.device,
    )

    previous_interval_indices = torch.clamp(
        interval_indices - 1,
        min=0,
    )

    # Get the cumulative probability before the current interval.
    probability_before_interval = torch.where(
        interval_indices == 0,
        torch.zeros_like(observed_times),
        cumulative_probability[
            patient_indices,
            previous_interval_indices,
        ],
    )

    # Identify patients whose observed time is within a finite interval.
    finite_interval_mask = (
        interval_indices < len(time_bins_array)
    )

    lower_bound_indices = torch.clamp(
        interval_indices - 1,
        min=0,
    )

    # Get the lower boundary of each patient's current interval.
    lower_bounds = torch.where(
        interval_indices == 0,
        torch.zeros_like(observed_times),
        bins_tensor[lower_bound_indices],
    )

    upper_bound_indices = torch.clamp(
        interval_indices,
        max=len(time_bins_array) - 1,
    )

    # Get the upper boundary of each patient's current interval.
    upper_bounds = bins_tensor[
        upper_bound_indices
    ]

    # Calculate the width of each current interval.
    interval_widths = torch.clamp(
        upper_bounds - lower_bounds,
        min=torch.finfo(
            interval_probabilities.dtype
        ).eps,
    )

    # Calculate each observed time's position within its interval.
    fractions = torch.clamp(
        (
            observed_times
            - lower_bounds
        ) / interval_widths,
        min=0.0,
        max=1.0,
    )

    current_interval_indices = torch.clamp(
        interval_indices,
        max=interval_probabilities.shape[1] - 1,
    )

    # Get the probability mass assigned to each current interval.
    current_interval_mass = interval_probabilities[
        patient_indices,
        current_interval_indices,
    ]

    # Calculate the interpolated CDF at each observed time.
    interpolated_cdf = (
        probability_before_interval
        + fractions * current_interval_mass
    )

    # The final interval is open-ended, so no finite within-interval
    # interpolation is assumed beyond the last boundary.
    cdf = torch.where(
        finite_interval_mask,
        interpolated_cdf,
        probability_before_interval,
    )

    # Restrict the returned CDF values to the valid probability range.
    return torch.clamp(
        cdf,
        min=0.0,
        max=1.0,
    )