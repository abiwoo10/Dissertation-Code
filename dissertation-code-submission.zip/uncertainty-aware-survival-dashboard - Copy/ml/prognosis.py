from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd

from ml.prediction import SurvivalPrediction


# ---------------------------------------------------------------------------
# Patient Explanations
# ---------------------------------------------------------------------------

UNCERTAINTY_EXPLANATION = (
        "Model disagreement describes how much the independently "
        "trained ensemble members differ. Higher disagreement has been "
        "associated with larger prediction errors in the validation "
        "data, but it does not represent every source of uncertainty "
        "and is not a clinical confidence interval."
        )

PROGNOSIS_EXPLANATION = (
        "These survival probabilities are model estimates based on patients "
        "with similar recorded characteristics. They are intended to support "
        "prognosis communication and do not determine what will happen to an "
        "individual patient."
        )

uncertainty_explanation = UNCERTAINTY_EXPLANATION
explanation = PROGNOSIS_EXPLANATION


# ---------------------------------------------------------------------------
# Prognosis Data Containers
# ---------------------------------------------------------------------------

# Store the thresholds used to classify model disagreement.
@dataclass(frozen=True)
class UncertaintyThresholds:

    lower_threshold: float
    higher_threshold: float

    def __post_init__(self) -> None:
        if self.lower_threshold < 0:
            raise ValueError(
                "lower_threshold must not be negative."
            )

        if self.higher_threshold < self.lower_threshold:
            raise ValueError(
                "higher_threshold must be greater than or equal to "
                "lower_threshold."
            )


# Store the patient survival prediction and uncertainty summary.
@dataclass(frozen=True)
class PatientPrognosis:

    patient_index: object
    model_name: str

    one_year_survival: float
    three_year_survival: float
    five_year_survival: float

    median_survival_months: float | None
    survival_curve: pd.Series

    uncertainty: float | None

    one_year_uncertainty: float | None
    three_year_uncertainty: float | None
    five_year_uncertainty: float | None

    model_disagreement_label: str | None
    uncertainty_explanation: str | None

    explanation: str

    # Convert the one-year survival probability to a percentage.
    def one_year_percentage(self) -> float:
        return self.one_year_survival * 100.0

    # Convert the three-year survival probability to a percentage.
    def three_year_percentage(self) -> float:
        return self.three_year_survival * 100.0

    # Convert the five-year survival probability to a percentage.
    def five_year_percentage(self) -> float:
        return self.five_year_survival * 100.0

    # Convert the median survival estimate from months to years.
    def median_survival_years(self) -> float | None:
        if self.median_survival_months is None:
            return None

        return self.median_survival_months / 12.0


# ---------------------------------------------------------------------------
# Median Survival
# ---------------------------------------------------------------------------

# Estimate when the survival curve reaches 50%.
def estimate_median_survival(
    survival_curve: pd.Series,
) -> float | None:

    if survival_curve.empty:
        raise ValueError("survival_curve must not be empty.")

    # Convert the survival-curve times and probabilities to arrays.
    times = np.asarray(
        survival_curve.index,
        dtype=float,
    )

    probabilities = survival_curve.to_numpy(
        dtype=float,
    )

    if np.any(times < 0):
        raise ValueError(
            "survival-curve times must not be negative."
        )

    if np.any(
        (probabilities < 0.0)
        | (probabilities > 1.0)
    ):
        raise ValueError(
            "survival probabilities must be between 0 and 1."
        )

    # Sort the survival curve by time.
    order = np.argsort(times)
    times = times[order]
    probabilities = probabilities[order]

    if np.any(
        probabilities[:-1]
        < probabilities[1:]
    ):
        raise ValueError(
            "survival probabilities must not increase over time."
        )

    # Find the first survival probability at or below 50%.
    below_half = np.flatnonzero(
        probabilities <= 0.5
    )

    if below_half.size == 0:
        return None

    crossing_index = int(below_half[0])

    if crossing_index == 0:
        return float(times[0])

    # Get the time points and probabilities surrounding the 50% crossing.
    earlier_time = times[crossing_index - 1]
    later_time = times[crossing_index]

    earlier_probability = probabilities[crossing_index - 1]
    later_probability = probabilities[crossing_index]

    if earlier_probability == later_probability:
        return float(later_time)

    # Calculate the interpolation position of the 50% crossing.
    fraction = (
        (earlier_probability - 0.5)
        / (earlier_probability - later_probability)
    )

    # Interpolate the median survival time.
    return float(
        earlier_time
        + fraction * (later_time - earlier_time)
    )


# ---------------------------------------------------------------------------
# Uncertainty Thresholds
# ---------------------------------------------------------------------------

# Calculate model-disagreement thresholds from the prediction uncertainty.
def calculate_uncertainty_thresholds(
    prediction: SurvivalPrediction,
) -> UncertaintyThresholds:

    if prediction.uncertainty is None:
        raise ValueError(
            "Prediction does not contain uncertainty estimates."
        )

    # Convert the uncertainty estimates to an array.
    uncertainty = prediction.uncertainty.to_numpy(
        dtype=float,
    )

    if uncertainty.size < 3:
        raise ValueError(
            "At least three uncertainty estimates are required."
        )

    if np.isnan(uncertainty).any():
        raise ValueError(
            "Uncertainty estimates must not contain missing values."
        )

    if np.any(uncertainty < 0):
        raise ValueError(
            "Uncertainty estimates must not be negative."
        )

    # Calculate the lower and higher uncertainty thresholds.
    lower_threshold, higher_threshold = np.quantile(
        uncertainty,
        [1.0 / 3.0, 2.0 / 3.0],
    )

    return UncertaintyThresholds(
        lower_threshold=float(lower_threshold),
        higher_threshold=float(higher_threshold),
    )


# Classify an uncertainty estimate using the disagreement thresholds.
def classify_model_disagreement(
    uncertainty: float,
    thresholds: UncertaintyThresholds,
) -> str:

    if uncertainty < 0:
        raise ValueError(
            "uncertainty must not be negative."
        )

    if uncertainty <= thresholds.lower_threshold:
        return "Lower model disagreement"

    if uncertainty <= thresholds.higher_threshold:
        return "Moderate model disagreement"

    return "Higher model disagreement"


# ---------------------------------------------------------------------------
# Horizon Uncertainty
# ---------------------------------------------------------------------------

# Calculate model disagreement at a selected prediction time.
def extract_horizon_uncertainty(
    prediction: SurvivalPrediction,
    patient_index: object,
    time: float,
) -> float | None:

    if (
        prediction.lower_confidence is None
        or prediction.upper_confidence is None
    ):
        return None

    if patient_index not in prediction.lower_confidence.index:
        raise KeyError(
            f"Patient index not found in lower uncertainty curve: "
            f"{patient_index!r}"
        )

    if patient_index not in prediction.upper_confidence.index:
        raise KeyError(
            f"Patient index not found in upper uncertainty curve: "
            f"{patient_index!r}"
        )

    if time not in prediction.lower_confidence.columns:
        raise ValueError(
            f"Lower uncertainty curve does not contain {time} months."
        )

    if time not in prediction.upper_confidence.columns:
        raise ValueError(
            f"Upper uncertainty curve does not contain {time} months."
        )

    # Get the lower and upper disagreement values at the selected time.
    lower = float(
        prediction.lower_confidence.loc[
            patient_index,
            time,
        ]
    )

    upper = float(
        prediction.upper_confidence.loc[
            patient_index,
            time,
        ]
    )

    # Calculate half the distance between the lower and upper values.
    return max(
        0.0,
        (upper - lower) / 2.0,
    )


# ---------------------------------------------------------------------------
# Patient Prognosis
# ---------------------------------------------------------------------------

# Create a patient prognosis from an individual survival prediction.
def create_patient_prognosis(
    prediction: SurvivalPrediction,
    patient_index: object,
    uncertainty_thresholds: UncertaintyThresholds | None = None,
) -> PatientPrognosis:

    if patient_index not in prediction.risk_score.index:
        raise KeyError(
            f"Patient index not found in prediction: {patient_index!r}"
        )

    # Extract the patient's survival curve.
    curve = prediction.survival_curve.loc[
        patient_index
    ].copy()

    # Convert the survival-curve index to months.
    curve.index = pd.Index(
        [float(time) for time in curve.index],
        name="months",
    )

    # Calculate the patient's median survival estimate.
    median_survival = estimate_median_survival(
        curve
    )

    overall_uncertainty = None
    disagreement_label = None
    uncertainty_explanation = None

    # Extract and classify the overall uncertainty when available.
    if prediction.uncertainty is not None:
        overall_uncertainty = float(
            prediction.uncertainty.loc[
                patient_index
            ]
        )

        if uncertainty_thresholds is not None:
            disagreement_label = (
                classify_model_disagreement(
                    uncertainty=overall_uncertainty,
                    thresholds=uncertainty_thresholds,
                )
            )

        uncertainty_explanation = UNCERTAINTY_EXPLANATION

    explanation = PROGNOSIS_EXPLANATION

    # Return the complete patient prognosis summary.
    return PatientPrognosis(
        patient_index=patient_index,
        model_name=prediction.model_name,
        one_year_survival=float(
            prediction.one_year_survival.loc[
                patient_index
            ]
        ),
        three_year_survival=float(
            prediction.three_year_survival.loc[
                patient_index
            ]
        ),
        five_year_survival=float(
            prediction.five_year_survival.loc[
                patient_index
            ]
        ),
        median_survival_months=median_survival,
        survival_curve=curve,
        uncertainty=overall_uncertainty,
        one_year_uncertainty=extract_horizon_uncertainty(
            prediction,
            patient_index,
            12.0,
        ),
        three_year_uncertainty=extract_horizon_uncertainty(
            prediction,
            patient_index,
            36.0,
        ),
        five_year_uncertainty=extract_horizon_uncertainty(
            prediction,
            patient_index,
            60.0,
        ),
        model_disagreement_label=disagreement_label,
        uncertainty_explanation=uncertainty_explanation,
        explanation=explanation,
    )