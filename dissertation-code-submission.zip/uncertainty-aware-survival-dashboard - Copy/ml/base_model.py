from __future__ import annotations

from abc import ABC, abstractmethod
from pathlib import Path

import pandas as pd

from ml.prediction import SurvivalPrediction


# ---------------------------------------------------------------------------
# Base Survival Model
# ---------------------------------------------------------------------------

# Defines the common interface that all survival models must follow,
# allowing models to be used consistently throughout the project.
class BaseSurvivalModel(ABC):

    # Train the survival model using patient features, observed survival
    # durations and event indicators.
    @abstractmethod
    def fit(
        self,
        X: pd.DataFrame,
        duration: pd.Series,
        event: pd.Series,
    ) -> None:
        ...

    # Generate relative risk scores, where higher values represent
    # greater predicted risk.
    @abstractmethod
    def predict_risk(
        self,
        X: pd.DataFrame,
    ) -> pd.Series:
        ...

    # Generate survival probabilities across the requested time points,
    # together with any uncertainty information provided by the model.
    @abstractmethod
    def predict_survival(
        self,
        X: pd.DataFrame,
        time_points: list[float],
    ) -> SurvivalPrediction:
        ...

    # Save the trained survival model to the specified location.
    @abstractmethod
    def save(
        self,
        path: Path,
    ) -> None:
        ...

    # Load a previously trained survival model from the specified location.
    @classmethod
    @abstractmethod
    def load(
        cls,
        path: Path,
    ) -> "BaseSurvivalModel":
        ...