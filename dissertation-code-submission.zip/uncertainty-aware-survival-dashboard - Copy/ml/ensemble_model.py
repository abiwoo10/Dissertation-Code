from __future__ import annotations

from pathlib import Path
import pickle

import numpy as np
import pandas as pd

from ml.base_model import BaseSurvivalModel
from ml.mtlr_model import MTLRModel
from ml.prediction import SurvivalPrediction


# ---------------------------------------------------------------------------
# MTLR Ensemble Model
# ---------------------------------------------------------------------------

# Ensemble containing multiple fitted MTLR models.
class MTLREnsembleModel(BaseSurvivalModel):

    # Initialise the ensemble and check that all member models are compatible.
    def __init__(
        self,
        members: list[MTLRModel],
    ) -> None:
        if len(members) < 2:
            raise ValueError(
                "An ensemble must contain at least two models."
            )

        if not all(
            isinstance(member, MTLRModel)
            for member in members
        ):
            raise TypeError(
                "Every ensemble member must be an MTLRModel."
            )

        if not all(
            member.is_fitted
            for member in members
        ):
            raise ValueError(
                "Every ensemble member must be fitted."
            )

        # Use the first member as the reference feature schema.
        reference_feature_names = members[0].feature_names

        if any(
            member.feature_names != reference_feature_names
            for member in members[1:]
        ):
            raise ValueError(
                "All ensemble members must use identical feature names."
            )

        # Use the first member as the reference time-bin structure.
        reference_time_bins = members[0].time_bins

        if reference_time_bins is None:
            raise ValueError(
                "Ensemble members must contain fitted time bins."
            )

        # Check that every ensemble member uses the same fitted time bins.
        for member in members[1:]:
            if member.time_bins is None:
                raise ValueError(
                    "Ensemble members must contain fitted time bins."
                )

            if not np.array_equal(
                member.time_bins,
                reference_time_bins,
            ):
                raise ValueError(
                    "All ensemble members must use identical time bins."
                )

        self.members = members
        self.feature_names = reference_feature_names.copy()
        self.time_bins = reference_time_bins.copy()
        self.is_fitted = True

    # Prevent ensemble members from being trained through the ensemble class.
    def fit(
        self,
        X: pd.DataFrame,
        duration: pd.Series,
        event: pd.Series,
    ) -> None:
        raise RuntimeError(
            "MTLREnsembleModel does not train members through fit(). "
            "Train member models independently before constructing the ensemble."
        )

    # Calculate the mean risk score across all ensemble members.
    def predict_risk(
            self,
            X: pd.DataFrame,
    ) -> pd.Series:

        if X.empty:
            raise ValueError("X must not be empty.")

        if X.columns.tolist() != self.feature_names:
            raise ValueError(
                "X columns must match the ensemble feature names."
            )

        # Generate risk scores from each ensemble member.
        member_risks = [
            member.predict_risk(X)
            for member in self.members
        ]

        # Combine member risk scores into a single matrix.
        risk_matrix = np.column_stack(
            [
                risk.to_numpy(dtype=float)
                for risk in member_risks
            ]
        )

        return pd.Series(
            risk_matrix.mean(axis=1),
            index=X.index,
            name="risk_score",
        )

    # Aggregate member survival predictions and calculate model disagreement.
    def predict_survival(
            self,
            X: pd.DataFrame,
            time_points: list[float],
    ) -> SurvivalPrediction:

        if X.empty:
            raise ValueError("X must not be empty.")

        if X.columns.tolist() != self.feature_names:
            raise ValueError(
                "X columns must match the ensemble feature names."
            )

        # Generate survival predictions from each ensemble member.
        member_predictions = [
            member.predict_survival(
                X=X,
                time_points=time_points,
            )
            for member in self.members
        ]

        # Stack the member survival curves for aggregation.
        curve_arrays = np.stack(
            [
                prediction.survival_curve[
                    [float(time) for time in time_points]
                ].to_numpy(dtype=float)
                for prediction in member_predictions
            ],
            axis=0,
        )

        # Calculate the mean survival curve across ensemble members.
        mean_curve_values = curve_arrays.mean(
            axis=0
        )

        # Calculate disagreement between ensemble members at each time point.
        standard_deviation_values = curve_arrays.std(
            axis=0,
            ddof=0,
        )

        ordered_times = sorted(
            float(time)
            for time in time_points
        )

        mean_curve = pd.DataFrame(
            mean_curve_values,
            index=X.index,
            columns=[
                float(time)
                for time in time_points
            ],
        )

        ordered_values = mean_curve[
            ordered_times
        ].to_numpy(dtype=float)

        # Restrict survival probabilities to the valid probability range.
        ordered_values = np.clip(
            ordered_values,
            0.0,
            1.0,
        )

        # Prevent survival probabilities from increasing over time.
        ordered_values = np.minimum.accumulate(
            ordered_values,
            axis=1,
        )

        mean_curve.loc[
            :,
            ordered_times,
        ] = ordered_values

        # Calculate the average model disagreement for each patient.
        uncertainty = pd.Series(
            standard_deviation_values.mean(axis=1),
            index=X.index,
            name="uncertainty",
        )

        # Create the lower disagreement curve.
        lower_curve = pd.DataFrame(
            np.clip(
                mean_curve_values
                - standard_deviation_values,
                0.0,
                1.0,
            ),
            index=X.index,
            columns=[
                float(time)
                for time in time_points
            ],
        )

        # Create the upper disagreement curve.
        upper_curve = pd.DataFrame(
            np.clip(
                mean_curve_values
                + standard_deviation_values,
                0.0,
                1.0,
            ),
            index=X.index,
            columns=[
                float(time)
                for time in time_points
            ],
        )

        if not time_points:
            raise ValueError(
                "At least one prediction time must be supplied."
            )

        required_times = {
            12.0,
            36.0,
            60.0,
        }

        provided_times = {
            float(time)
            for time in time_points
        }

        # Check that one, three and five year prediction times are present.
        if not required_times.issubset(provided_times):
            raise ValueError(
                "time_points must include 12, 36, and 60 months."
            )

        # Return the aggregated prediction and disagreement values.
        return SurvivalPrediction(
            one_year_survival=mean_curve[12.0],
            three_year_survival=mean_curve[36.0],
            five_year_survival=mean_curve[60.0],
            survival_curve=mean_curve,
            risk_score=self.predict_risk(X),
            uncertainty=uncertainty,
            lower_confidence=lower_curve,
            upper_confidence=upper_curve,
            model_name="MTLR X-CAL Deep Ensemble",
            prediction_times=[
                float(time)
                for time in time_points
            ],
        )

    # Save the fitted ensemble and its member models.
    def save(
            self,
            path: Path,
    ) -> None:

        if not self.is_fitted:
            raise RuntimeError(
                "Cannot save an unfitted ensemble."
            )

        # Create the destination directory if required.
        path.parent.mkdir(
            parents=True,
            exist_ok=True,
        )

        with path.open("wb") as output_file:
            pickle.dump(self, output_file)

    # Load a previously saved MTLR ensemble.
    @classmethod
    def load(
            cls,
            path: Path,
    ) -> "MTLREnsembleModel":

        if not path.exists():
            raise FileNotFoundError(
                f"MTLR ensemble not found: {path}"
            )

        with path.open("rb") as input_file:
            ensemble = pickle.load(input_file)

        # Check that the loaded object is an MTLR ensemble.
        if not isinstance(ensemble, cls):
            raise TypeError(
                "Loaded object is not an MTLREnsembleModel."
            )

        return ensemble