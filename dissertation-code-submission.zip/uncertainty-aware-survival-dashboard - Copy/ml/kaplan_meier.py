from __future__ import annotations

from dataclasses import dataclass

import pandas as pd
from lifelines import KaplanMeierFitter


# ---------------------------------------------------------------------------
# Kaplan-Meier Summary
# ---------------------------------------------------------------------------

# Store summary statistics from a fitted Kaplan-Meier estimator.
@dataclass(frozen=True)
class KaplanMeierSummary:

    patient_count: int
    event_count: int
    censored_count: int
    median_survival_months: float | None
    survival_probabilities: dict[float, float]


# ---------------------------------------------------------------------------
# Kaplan-Meier Estimator
# ---------------------------------------------------------------------------

# Fit a Kaplan-Meier estimator using the survival durations and event indicators.
def fit_kaplan_meier(
    duration: pd.Series,
    event: pd.Series,
    label: str = "METABRIC cohort",
) -> KaplanMeierFitter:

    # Check that the duration and event data contain the same number of rows.
    if len(duration) != len(event):
        raise ValueError(
            "duration and event must contain the same number of rows."
        )

    if duration.empty:
        raise ValueError("duration and event must not be empty.")

    # Check for missing duration or event values.
    if duration.isna().any() or event.isna().any():
        raise ValueError(
            "duration and event must not contain missing values."
        )

    # Check for negative survival durations.
    if (duration < 0).any():
        raise ValueError(
            "duration must not contain negative values."
        )

    # Find any event values outside the supported binary values.
    invalid_events = set(event.unique()) - {0, 1, False, True}

    if invalid_events:
        raise ValueError(
            f"event contains unsupported values: {sorted(invalid_events)}"
        )

    # Create and fit the Kaplan-Meier estimator.
    estimator = KaplanMeierFitter(label=label)

    estimator.fit(
        durations=duration.astype(float),
        event_observed=event.astype(bool),
    )

    return estimator


# ---------------------------------------------------------------------------
# Kaplan-Meier Summary
# ---------------------------------------------------------------------------

# Create a summary of the fitted Kaplan-Meier estimator.
def summarise_kaplan_meier(
    estimator: KaplanMeierFitter,
    duration: pd.Series,
    event: pd.Series,
    time_points: list[float],
) -> KaplanMeierSummary:

    if not time_points:
        raise ValueError("time_points must not be empty.")

    # Check for negative prediction time points.
    if any(time < 0 for time in time_points):
        raise ValueError(
            "time_points must not contain negative values."
        )

    # Calculate survival probabilities at the requested time points.
    probabilities = estimator.survival_function_at_times(
        time_points
    )

    # Return the cohort counts, median survival and survival probabilities.
    return KaplanMeierSummary(
        patient_count=len(duration),
        event_count=int(event.sum()),
        censored_count=int((event == 0).sum()),
        median_survival_months=float(
            estimator.median_survival_time_
        ),
        survival_probabilities={
            float(time): float(probabilities.loc[time])
            for time in time_points
        },
    )