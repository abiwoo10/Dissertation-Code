from __future__ import annotations

import numpy as np
import pandas as pd
from scipy.stats import chisquare

from ml.prediction import SurvivalPrediction


# ---------------------------------------------------------------------------
# Uncensored D-Calibration
# ---------------------------------------------------------------------------

# Calculate D-calibration using uncensored observations only.
# Censored patients are excluded from this version of the calculation.
def calculate_uncensored_d_calibration(
    prediction: SurvivalPrediction,
    duration: pd.Series,
    event: pd.Series,
    number_of_bins: int = 10,
) -> dict[str, object]:

    # Validate that predictions and observed patient outcomes are aligned.
    if prediction.patient_count() != len(duration):
        raise ValueError(
            "Prediction count does not match the number of patients."
        )

    if len(duration) != len(event):
        raise ValueError(
            "duration and event must have the same length."
        )

    if number_of_bins < 2:
        raise ValueError(
            "number_of_bins must be at least 2."
        )

    if duration.isna().any() or event.isna().any():
        raise ValueError(
            "duration and event must not contain missing values."
        )

    # Ensure survival curve time points are numerical and in chronological
    # order before interpolation.
    curve = prediction.survival_curve.copy()
    curve.columns = [
        float(column)
        for column in curve.columns
    ]
    curve = curve.reindex(
        sorted(curve.columns),
        axis=1,
    )

    curve_times = np.asarray(
        curve.columns,
        dtype=float,
    )

    uncensored_probabilities: list[float] = []

    # Calculate each uncensored patient's predicted survival probability
    # at their observed event time.
    for patient_position, patient_index in enumerate(curve.index):
        if not bool(event.iloc[patient_position]):
            continue

        observed_time = float(
            duration.iloc[patient_position]
        )

        patient_curve = curve.loc[
            patient_index
        ].to_numpy(dtype=float)

        # Interpolate between available survival-curve time points when the
        # observed event does not occur exactly at a modelled time point.
        probability = float(
            np.interp(
                observed_time,
                curve_times,
                patient_curve,
                left=1.0,
                right=patient_curve[-1],
            )
        )

        uncensored_probabilities.append(
            float(np.clip(probability, 0.0, 1.0))
        )

    if not uncensored_probabilities:
        raise ValueError(
            "At least one uncensored event is required."
        )

    # Divide the probability range into equal-width bins for comparison
    # against the uniform distribution expected from a calibrated model.
    bin_edges = np.linspace(
        0.0,
        1.0,
        number_of_bins + 1,
    )

    observed_counts, _ = np.histogram(
        uncensored_probabilities,
        bins=bin_edges,
    )

    expected_count = (
        len(uncensored_probabilities)
        / number_of_bins
    )

    expected_counts = np.full(
        number_of_bins,
        expected_count,
        dtype=float,
    )

    # Compare observed and expected bin counts using a chi-square test.
    statistic, p_value = chisquare(
        f_obs=observed_counts,
        f_exp=expected_counts,
    )

    return {
        "number_of_bins": number_of_bins,
        "uncensored_count": len(
            uncensored_probabilities
        ),
        "observed_counts": (
            observed_counts.astype(int).tolist()
        ),
        "expected_counts": expected_counts.tolist(),
        "chi_square_statistic": float(statistic),
        "p_value": float(p_value),
        "passes_at_0_05": bool(p_value >= 0.05),
    }


# ---------------------------------------------------------------------------
# Censoring-Adjusted D-Calibration
# ---------------------------------------------------------------------------

# Calculate D-calibration while accounting for censored observations.
# Observed events contribute fully to one probability bin, while censored
# observations contribute fractionally across the range in which their
# unknown event-time CDF could occur.
def calculate_censoring_adjusted_d_calibration(
    prediction: SurvivalPrediction,
    duration: pd.Series,
    event: pd.Series,
    number_of_bins: int = 10,
    epsilon: float = 1e-7,
) -> dict[str, object]:

    # Validate the prediction dimensions and calibration parameters before
    # performing the calculation.
    if prediction.patient_count() != len(duration):
        raise ValueError(
            "Prediction count does not match the number of patients."
        )

    if len(duration) != len(event):
        raise ValueError(
            "duration and event must have the same length."
        )

    if number_of_bins < 2:
        raise ValueError(
            "number_of_bins must be at least 2."
        )

    if epsilon <= 0:
        raise ValueError(
            "epsilon must be positive."
        )

    if duration.isna().any() or event.isna().any():
        raise ValueError(
            "duration and event must not contain missing values."
        )

    invalid_events = set(event.unique()) - {
        0,
        1,
        False,
        True,
    }

    if invalid_events:
        raise ValueError(
            f"event contains unsupported values: "
            f"{sorted(invalid_events)}"
        )

    # Ensure survival curve time points are numerical and ordered before
    # interpolating patient predictions.
    curve = prediction.survival_curve.copy()

    curve.columns = [
        float(column)
        for column in curve.columns
    ]

    curve = curve.reindex(
        sorted(curve.columns),
        axis=1,
    )

    curve_times = np.asarray(
        curve.columns,
        dtype=float,
    )

    if len(curve_times) < 2:
        raise ValueError(
            "The survival curve must contain at least two time points."
        )

    # Create equal-width probability bins covering the complete CDF range.
    bin_edges = np.linspace(
        0.0,
        1.0,
        number_of_bins + 1,
    )

    observed_counts = np.zeros(
        number_of_bins,
        dtype=float,
    )

    event_count = 0
    censored_count = 0

    # Calculate the calibration contribution made by each patient.
    for patient_position, patient_index in enumerate(
        curve.index
    ):
        observed_time = float(
            duration.iloc[patient_position]
        )

        patient_curve = curve.loc[
            patient_index
        ].to_numpy(dtype=float)

        # Estimate survival probability at the patient's observed event or
        # censoring time using interpolation.
        survival_at_observed_time = float(
            np.interp(
                observed_time,
                curve_times,
                patient_curve,
                left=1.0,
                right=patient_curve[-1],
            )
        )

        survival_at_observed_time = float(
            np.clip(
                survival_at_observed_time,
                0.0,
                1.0,
            )
        )

        # Convert survival probability S(t) into cumulative event
        # probability F(t) = 1 - S(t).
        cdf_at_observed_time = (
            1.0 - survival_at_observed_time
        )

        # An observed event has a known event time and therefore contributes
        # fully to the corresponding probability bin.
        if bool(event.iloc[patient_position]):
            event_count += 1

            bin_index = int(
                np.searchsorted(
                    bin_edges,
                    cdf_at_observed_time,
                    side="right",
                )
                - 1
            )

            # Keep boundary values such as a CDF of exactly 1 within the
            # valid range of bin indices.
            bin_index = min(
                max(bin_index, 0),
                number_of_bins - 1,
            )

            observed_counts[bin_index] += 1.0
            continue

        censored_count += 1

        # For censored patients, the true event-time CDF can occur anywhere
        # between the CDF at censoring and 1.
        remaining_width = (
            1.0 - cdf_at_observed_time
        )

        # Assign extremely small remaining intervals to the final bin to
        # avoid unstable division by values close to zero.
        if remaining_width <= epsilon:
            observed_counts[-1] += 1.0
            continue

        # Distribute the censored patient's contribution across each
        # compatible probability bin according to the proportional overlap.
        for bin_index in range(number_of_bins):
            lower_bound = bin_edges[bin_index]
            upper_bound = bin_edges[bin_index + 1]

            overlap_lower = max(
                lower_bound,
                cdf_at_observed_time,
            )

            overlap_upper = min(
                upper_bound,
                1.0,
            )

            overlap = max(
                0.0,
                overlap_upper - overlap_lower,
            )

            observed_counts[bin_index] += (
                overlap / remaining_width
            )

    patient_count = len(duration)

    # Correct tiny floating-point accumulation differences before calling
    # scipy.stats.chisquare.
    total_contribution = observed_counts.sum()

    if total_contribution <= 0:
        raise ValueError(
            "No calibration contributions were produced."
        )

    observed_counts *= (
        patient_count / total_contribution
    )

    # Under perfect calibration, patient contributions should be distributed
    # uniformly across all probability bins.
    expected_count = (
        patient_count / number_of_bins
    )

    expected_counts = np.full(
        number_of_bins,
        expected_count,
        dtype=float,
    )

    # Compare the observed calibration distribution against the expected
    # uniform distribution.
    statistic, p_value = chisquare(
        f_obs=observed_counts,
        f_exp=expected_counts,
    )

    return {
        "number_of_bins": number_of_bins,
        "patient_count": patient_count,
        "event_count": event_count,
        "censored_count": censored_count,
        "observed_counts": observed_counts.tolist(),
        "expected_counts": expected_counts.tolist(),
        "chi_square_statistic": float(statistic),
        "p_value": float(p_value),
        "passes_at_0_05": bool(
            p_value >= 0.05
        ),
    }