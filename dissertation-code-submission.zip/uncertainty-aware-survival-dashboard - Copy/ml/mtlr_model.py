from __future__ import annotations

import copy
import pickle
from pathlib import Path

import numpy as np
import pandas as pd
import torch

from ml.base_model import BaseSurvivalModel
from ml.mtlr_layer import MTLRLayer
from ml.mtlr_utils import (
    build_time_bins,
    encode_mtlr_targets,
    interval_probabilities_to_cdf_at_times,
    interval_probabilities_to_survival,
    mtlr_negative_log_likelihood,
)
from ml.prediction import SurvivalPrediction
from ml.xcal import xcal_loss


# ---------------------------------------------------------------------------
# MTLR Model
# ---------------------------------------------------------------------------

# PyTorch implementation of the MTLR survival model.
class MTLRModel(BaseSurvivalModel):

    # Initialise the model and training parameters.
    def __init__(
            self,
            number_of_bins: int = 20,
            learning_rate: float = 1e-2,
            epochs: int = 200,
            weight_decay: float = 1e-4,
            random_state: int = 42,
            patience: int = 30,
            minimum_improvement: float = 1e-4,
            calibration_weight: float = 0.0,
            xcal_bins: int = 10,
            xcal_gamma: float = 10_000.0,
    ) -> None:
        if number_of_bins < 2:
            raise ValueError(
                "number_of_bins must be at least 2."
            )

        if learning_rate <= 0:
            raise ValueError(
                "learning_rate must be positive."
            )

        if epochs < 1:
            raise ValueError(
                "epochs must be at least 1."
            )

        if weight_decay < 0:
            raise ValueError(
                "weight_decay must not be negative."
            )

        if patience < 1:
            raise ValueError(
                "patience must be at least 1."
            )

        if minimum_improvement < 0:
            raise ValueError(
                "minimum_improvement must not be negative."
            )

        if calibration_weight < 0:
            raise ValueError(
                "calibration_weight must not be negative."
            )

        if xcal_bins < 2:
            raise ValueError(
                "xcal_bins must be at least 2."
            )

        if xcal_gamma <= 0:
            raise ValueError(
                "xcal_gamma must be positive."
            )

        self.number_of_bins = number_of_bins
        self.learning_rate = learning_rate
        self.epochs = epochs
        self.weight_decay = weight_decay
        self.random_state = random_state
        self.patience = patience
        self.minimum_improvement = minimum_improvement

        self.calibration_weight = calibration_weight
        self.xcal_bins = xcal_bins
        self.xcal_gamma = xcal_gamma

        self.network: MTLRLayer | None = None
        self.time_bins: np.ndarray | None = None
        self.feature_names: list[str] = []

        self.is_fitted = False

        # Store training loss values for each epoch.
        self.training_losses: list[float] = []
        self.training_nll_losses: list[float] = []
        self.training_xcal_losses: list[float] = []

        # Store validation loss values for each epoch.
        self.validation_losses: list[float] = []
        self.validation_nll_losses: list[float] = []
        self.validation_xcal_losses: list[float] = []

        self.best_epoch: int | None = None
        self.stopped_early = False

    # Fit the MTLR model using the training data and optional validation data.
    def fit(
            self,
            X: pd.DataFrame,
            duration: pd.Series,
            event: pd.Series,
            X_validation: pd.DataFrame | None = None,
            duration_validation: pd.Series | None = None,
            event_validation: pd.Series | None = None,
    ) -> None:

        if X.empty:
            raise ValueError("X must not be empty.")

        if not (
                len(X)
                == len(duration)
                == len(event)
        ):
            raise ValueError(
                "X, duration, and event must contain the same number "
                "of rows."
            )

        if X.isna().any().any():
            raise ValueError(
                "X must not contain missing values."
            )

        # Check whether complete validation data has been supplied.
        validation_values = (
            X_validation,
            duration_validation,
            event_validation,
        )

        validation_supplied = all(
            value is not None
            for value in validation_values
        )

        validation_partially_supplied = any(
            value is not None
            for value in validation_values
        ) and not validation_supplied

        if validation_partially_supplied:
            raise ValueError(
                "X_validation, duration_validation, and event_validation "
                "must either all be supplied or all be omitted."
            )

        # Validate the supplied validation data.
        if validation_supplied:
            assert X_validation is not None
            assert duration_validation is not None
            assert event_validation is not None

            if X_validation.empty:
                raise ValueError(
                    "X_validation must not be empty."
                )

            if not (
                    len(X_validation)
                    == len(duration_validation)
                    == len(event_validation)
            ):
                raise ValueError(
                    "Validation inputs must contain the same number of rows."
                )

            if X_validation.isna().any().any():
                raise ValueError(
                    "X_validation must not contain missing values."
                )

            if X_validation.columns.tolist() != X.columns.tolist():
                raise ValueError(
                    "Validation columns must match training columns."
                )

        # Set the random seeds used during model training.
        torch.manual_seed(self.random_state)
        np.random.seed(self.random_state)

        # Build the survival time bins from the training outcomes.
        self.time_bins = build_time_bins(
            duration=duration,
            event=event,
            number_of_bins=self.number_of_bins,
        )

        # Encode the training outcomes into MTLR target masks.
        training_targets = encode_mtlr_targets(
            duration=duration,
            event=event,
            time_bins=self.time_bins,
        )

        # Convert the training data into PyTorch tensors.
        training_features_tensor = torch.tensor(
            X.to_numpy(dtype=np.float32),
            dtype=torch.float32,
        )

        training_target_tensor = torch.tensor(
            training_targets,
            dtype=torch.float32,
        )

        training_duration_tensor = torch.tensor(
            duration.to_numpy(dtype=np.float32),
            dtype=torch.float32,
        )

        training_event_tensor = torch.tensor(
            event.to_numpy(dtype=np.float32),
            dtype=torch.float32,
        )

        validation_features_tensor = None
        validation_target_tensor = None
        validation_duration_tensor = None
        validation_event_tensor = None

        # Encode and convert the validation data when supplied.
        if validation_supplied:
            assert X_validation is not None
            assert duration_validation is not None
            assert event_validation is not None

            validation_targets = encode_mtlr_targets(
                duration=duration_validation,
                event=event_validation,
                time_bins=self.time_bins,
            )

            validation_features_tensor = torch.tensor(
                X_validation.to_numpy(dtype=np.float32),
                dtype=torch.float32,
            )

            validation_target_tensor = torch.tensor(
                validation_targets,
                dtype=torch.float32,
            )

            validation_duration_tensor = torch.tensor(
                duration_validation.to_numpy(dtype=np.float32),
                dtype=torch.float32,
            )

            validation_event_tensor = torch.tensor(
                event_validation.to_numpy(dtype=np.float32),
                dtype=torch.float32,
            )

        self.feature_names = X.columns.tolist()

        # Create the MTLR output layer.
        self.network = MTLRLayer(
            input_features=X.shape[1],
            interval_count=training_targets.shape[1],
        )

        # Create the optimiser used during training.
        optimiser = torch.optim.Adam(
            self.network.parameters(),
            lr=self.learning_rate,
            weight_decay=self.weight_decay,
        )

        # Reset stored training and validation results.
        self.training_losses = []
        self.training_nll_losses = []
        self.training_xcal_losses = []

        self.validation_losses = []
        self.validation_nll_losses = []
        self.validation_xcal_losses = []

        self.best_epoch = None
        self.stopped_early = False

        best_validation_loss = float("inf")
        best_network_state = None
        epochs_without_improvement = 0

        # Train the model for the configured number of epochs.
        for epoch in range(self.epochs):
            self.network.train()
            optimiser.zero_grad()

            training_logits = self.network(
                training_features_tensor
            )

            # Calculate the training negative log-likelihood.
            training_nll = mtlr_negative_log_likelihood(
                interval_logits=training_logits,
                target_mask=training_target_tensor,
            )

            training_probabilities = torch.softmax(
                training_logits,
                dim=1,
            )

            # Calculate the training CDF values at the observed times.
            training_cdf = interval_probabilities_to_cdf_at_times(
                interval_probabilities=training_probabilities,
                observed_times=training_duration_tensor,
                time_bins=self.time_bins,
            )

            # Calculate the training X-CAL loss.
            training_calibration_loss = xcal_loss(
                cdf_at_observed_time=training_cdf,
                event=training_event_tensor,
                number_of_bins=self.xcal_bins,
                gamma=self.xcal_gamma,
            )

            # Combine the NLL and weighted calibration losses.
            training_loss = (
                    training_nll
                    + self.calibration_weight
                    * training_calibration_loss
            )

            training_loss.backward()
            optimiser.step()

            # Store the training loss values for the current epoch.
            self.training_losses.append(
                float(training_loss.detach().item())
            )

            self.training_nll_losses.append(
                float(training_nll.detach().item())
            )

            self.training_xcal_losses.append(
                float(training_calibration_loss.detach().item())
            )

            if not validation_supplied:
                continue

            assert validation_features_tensor is not None
            assert validation_target_tensor is not None

            self.network.eval()

            # Calculate validation losses without updating model weights.
            with torch.no_grad():
                validation_logits = self.network(
                    validation_features_tensor
                )

                validation_nll = mtlr_negative_log_likelihood(
                    interval_logits=validation_logits,
                    target_mask=validation_target_tensor,
                )

                assert validation_duration_tensor is not None
                assert validation_event_tensor is not None

                validation_probabilities = torch.softmax(
                    validation_logits,
                    dim=1,
                )

                validation_cdf = interval_probabilities_to_cdf_at_times(
                    interval_probabilities=validation_probabilities,
                    observed_times=validation_duration_tensor,
                    time_bins=self.time_bins,
                )

                validation_calibration_loss = xcal_loss(
                    cdf_at_observed_time=validation_cdf,
                    event=validation_event_tensor,
                    number_of_bins=self.xcal_bins,
                    gamma=self.xcal_gamma,
                )

                validation_loss = (
                        validation_nll
                        + self.calibration_weight
                        * validation_calibration_loss
                )

            validation_loss_value = float(
                validation_loss.item()
            )

            # Store the validation loss values for the current epoch.
            self.validation_losses.append(
                validation_loss_value
            )

            self.validation_nll_losses.append(
                float(validation_nll.item())
            )

            self.validation_xcal_losses.append(
                float(validation_calibration_loss.item())
            )

            improvement = (
                    best_validation_loss
                    - validation_loss_value
            )

            # Store the network state when validation loss improves.
            if improvement > self.minimum_improvement:
                best_validation_loss = validation_loss_value
                best_network_state = copy.deepcopy(
                    self.network.state_dict()
                )
                self.best_epoch = epoch + 1
                epochs_without_improvement = 0
            else:
                epochs_without_improvement += 1

            # Stop training after the configured number of epochs
            # without sufficient improvement.
            if epochs_without_improvement >= self.patience:
                self.stopped_early = True
                break

        # Restore the network state from the best validation epoch.
        if validation_supplied and best_network_state is not None:
            self.network.load_state_dict(
                best_network_state
            )

        if self.best_epoch is None:
            self.best_epoch = len(self.training_losses)

        self.is_fitted = True

    # Generate relative risk scores from the expected event times.
    def predict_risk(
            self,
            X: pd.DataFrame,
    ) -> pd.Series:

        if not self.is_fitted or self.network is None:
            raise RuntimeError(
                "Model must be fitted before prediction."
            )

        if X.empty:
            raise ValueError("X must not be empty.")

        if X.columns.tolist() != self.feature_names:
            raise ValueError(
                "X columns must match the columns used during training."
            )

        # Convert the patient features into a PyTorch tensor.
        features_tensor = torch.tensor(
            X.to_numpy(dtype=np.float32),
            dtype=torch.float32,
        )

        self.network.eval()

        # Generate interval probabilities from the fitted model.
        with torch.no_grad():
            probabilities = (
                self.network.predict_interval_probabilities(
                    features_tensor
                )
            )

        assert self.time_bins is not None

        # Calculate representative times for each survival interval.
        interval_representatives = np.concatenate(
            [
                np.array([self.time_bins[0] / 2.0]),
                (
                        self.time_bins[:-1]
                        + self.time_bins[1:]
                ) / 2.0,
                np.array(
                    [
                        self.time_bins[-1]
                        + (
                                self.time_bins[-1]
                                - self.time_bins[-2]
                        ) / 2.0
                    ]
                ),
            ]
        )

        representative_tensor = torch.tensor(
            interval_representatives,
            dtype=probabilities.dtype,
        )

        # Calculate the expected event time from the interval probabilities.
        expected_time = (
                probabilities
                * representative_tensor
        ).sum(dim=1)

        # Convert expected event times into relative risk scores.
        risk_score = -expected_time.cpu().numpy()

        return pd.Series(
            risk_score,
            index=X.index,
            name="risk_score",
        )

    # Generate individual survival curves at the requested time points.
    def predict_survival(
            self,
            X: pd.DataFrame,
            time_points: list[float],
    ) -> SurvivalPrediction:

        if not self.is_fitted or self.network is None:
            raise RuntimeError(
                "Model must be fitted before prediction."
            )

        if not time_points:
            raise ValueError(
                "At least one prediction time must be supplied."
            )

        if any(time < 0 for time in time_points):
            raise ValueError(
                "Prediction times must not contain negative values."
            )

        if X.columns.tolist() != self.feature_names:
            raise ValueError(
                "X columns must match the columns used during training."
            )

        # Convert the patient features into a PyTorch tensor.
        features_tensor = torch.tensor(
            X.to_numpy(dtype=np.float32),
            dtype=torch.float32,
        )

        self.network.eval()

        # Generate interval and survival probabilities.
        with torch.no_grad():
            interval_probabilities = (
                self.network.predict_interval_probabilities(
                    features_tensor
                )
            )

            survival_probabilities = (
                interval_probabilities_to_survival(
                    interval_probabilities
                )
            )

        assert self.time_bins is not None

        survival_at_bins = survival_probabilities.cpu().numpy()

        survival_curve = pd.DataFrame(
            index=X.index,
        )

        # Calculate survival probabilities at each requested time point.
        for time in time_points:
            if time < self.time_bins[0]:
                values = np.ones(len(X), dtype=float)
            elif time >= self.time_bins[-1]:
                values = survival_at_bins[:, -1]
            else:
                upper_index = int(
                    np.searchsorted(
                        self.time_bins,
                        time,
                        side="right",
                    )
                )

                lower_index = upper_index - 1

                lower_time = self.time_bins[lower_index]
                upper_time = self.time_bins[upper_index]

                lower_survival = survival_at_bins[:, lower_index]
                upper_survival = survival_at_bins[:, upper_index]

                # Calculate the interpolation position between time bins.
                fraction = (
                        (time - lower_time)
                        / (upper_time - lower_time)
                )

                # Interpolate the survival probability between time bins.
                values = (
                        lower_survival
                        + fraction
                        * (
                                upper_survival
                                - lower_survival
                        )
                )

            survival_curve[float(time)] = values

        # Protect against tiny floating-point errors and enforce a valid,
        # monotonically non-increasing survival curve.
        ordered_times = sorted(
            survival_curve.columns,
        )

        ordered_values = survival_curve[
            ordered_times
        ].to_numpy(dtype=float)

        ordered_values = np.clip(
            ordered_values,
            0.0,
            1.0,
        )

        ordered_values = np.minimum.accumulate(
            ordered_values,
            axis=1,
        )

        survival_curve.loc[:, ordered_times] = ordered_values

        required_times = {12.0, 36.0, 60.0}

        missing_required_times = (
                required_times
                - set(float(time) for time in time_points)
        )

        # Check that one, three and five year prediction times are present.
        if missing_required_times:
            raise ValueError(
                "time_points must include 12, 36, and 60 months."
            )

        # Return the survival predictions in the shared prediction format.
        return SurvivalPrediction(
            one_year_survival=survival_curve[12.0],
            three_year_survival=survival_curve[36.0],
            five_year_survival=survival_curve[60.0],
            survival_curve=survival_curve,
            risk_score=self.predict_risk(X),
            uncertainty=None,
            model_name="Multi-Task Logistic Regression",
            prediction_times=[
                float(time)
                for time in time_points
            ],
        )

    # Save the fitted MTLR model.
    def save(
            self,
            path: Path,
    ) -> None:

        if not self.is_fitted:
            raise RuntimeError(
                "Cannot save an unfitted model."
            )

        # Create the destination directory if required.
        path.parent.mkdir(
            parents=True,
            exist_ok=True,
        )

        with path.open("wb") as output_file:
            pickle.dump(self, output_file)

    # Load a previously fitted MTLR model.
    @classmethod
    def load(
            cls,
            path: Path,
    ) -> "MTLRModel":

        if not path.exists():
            raise FileNotFoundError(
                f"MTLR model not found: {path}"
            )

        with path.open("rb") as input_file:
            model = pickle.load(input_file)

        # Check that the loaded object is an MTLR model.
        if not isinstance(model, cls):
            raise TypeError(
                "Loaded object is not an MTLRModel."
            )

        return model