from __future__ import annotations

import numpy as np
import scipy.integrate


# ---------------------------------------------------------------------------
# PyCox and SciPy Compatibility
# ---------------------------------------------------------------------------

# Provide the scipy.integrate.simps function expected by PyCox
# when it is not available in the installed SciPy version.
def ensure_pycox_scipy_compatibility() -> None:

    # Return without making changes if simps is already available.
    if hasattr(scipy.integrate, "simps"):
        return

    # Create a wrapper around scipy.integrate.simpson using the
    # arguments expected by scipy.integrate.simps.
    def simps_compatibility_wrapper(
        y: np.ndarray,
        x: np.ndarray | None = None,
        dx: float = 1.0,
        axis: int = -1,
        even: str | None = None,
    ) -> float:
        del even

        return float(
            scipy.integrate.simpson(
                y,
                x=x,
                dx=dx,
                axis=axis,
            )
        )

    # Add the compatibility wrapper as scipy.integrate.simps.
    scipy.integrate.simps = simps_compatibility_wrapper