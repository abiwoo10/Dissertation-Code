from __future__ import annotations

from pathlib import Path
import pickle

import pandas as pd
from lifelines import CoxPHFitter

from ml.base_model import BaseSurvivalModel
from ml.prediction import SurvivalPrediction


# ---------------------------------------------------------------------------
# Cox Proportional Hazards Model
# ---------------------------------------------------------------------------

# Cox proportional hazards survival model.
class CoxModel(BaseSurvivalModel):

    # Initialise the Cox model with the specified penalizer.
    def __init__(
            self,
            penalizer: float = 0.1,
    ) -> None:
        if penalizer < 0:
            raise ValueError("penalizer must not be negative.")

        self.penalizer = penalizer
        self.model = CoxPHFitter(
            penalizer=penalizer,
        )
        self.is_fitted = False

    # Fit the Cox model using the feature matrix, survival durations
    # and event indicators.
    def fit(
            self,
            X: pd.DataFrame,
            duration: pd.Series,
            event: pd.Series,
    ) -> None:

        if len(X) != len(duration) or len(X) != len(event):
            raise ValueError(
                "X, duration and event must contain the same number of rows."
            )

        # Combine the patient features with the duration and event columns
        # required by the Cox model.
        training_data = X.copy()

        training_data["duration"] = duration.values
        training_data["event"] = event.values.astype(bool)

        self.model.fit(
            training_data,
            duration_col="duration",
            event_col="event",
        )

        self.is_fitted = True

    # Generate relative risk scores for the supplied patients.
    def predict_risk(
            self,
            X: pd.DataFrame,
    ) -> pd.Series:

        if not self.is_fitted:
            raise RuntimeError(
                "Model must be fitted before prediction."
            )

        if X.empty:
            raise ValueError(
                "X must not be empty."
            )

        # Generate partial hazard values from the fitted Cox model.
        scores = self.model.predict_partial_hazard(X)

        return pd.Series(
            scores.values.flatten(),
            index=X.index,
            name="risk_score",
        )

    # Generate survival probabilities across the supplied time points.
    def predict_survival(
            self,
            X: pd.DataFrame,
            time_points: list[float],
    ) -> SurvivalPrediction:

        if not self.is_fitted:
            raise RuntimeError(
                "Model must be fitted before prediction."
            )

        if not time_points:
            raise ValueError(
                "At least one prediction time must be supplied."
            )

        # Ensure the required one, three and five year prediction
        # horizons are available.
        required_horizons = {12.0, 36.0, 60.0}

        if not required_horizons.issubset(time_points):
            raise ValueError(
                "time_points must include 12, 36 and 60 months."
            )

        risk_scores = self.predict_risk(X)

        # Generate a survival function for each patient.
        survival_functions = self.model.predict_survival_function(X)

        survival_curve = pd.DataFrame(index=X.index)

        # Interpolate the survival functions at each requested time point.
        for time in time_points:
            survival_curve[time] = (
                survival_functions
                .reindex(
                    survival_functions.index.union([time])
                )
                .sort_index()
                .interpolate(method="index")
                .loc[time]
                .values
            )

        # Store the survival estimates and complete survival curves
        # in the shared prediction format.
        return SurvivalPrediction(
            one_year_survival=survival_curve[12.0],
            three_year_survival=survival_curve[36.0],
            five_year_survival=survival_curve[60.0],
            survival_curve=survival_curve,
            risk_score=risk_scores,
            uncertainty=None,
            model_name="Cox Proportional Hazards",
            prediction_times=time_points,
        )

    # Save the fitted Cox model to the specified path.
    def save(
            self,
            path: Path,
    ) -> None:

        if not self.is_fitted:
            raise RuntimeError(
                "Cannot save an unfitted model."
            )

        # Create the destination directory if it does not already exist.
        path.parent.mkdir(
            parents=True,
            exist_ok=True,
        )

        with path.open("wb") as file:
            pickle.dump(self, file)

    # Load a previously saved Cox model.
    @classmethod
    def load(
            cls,
            path: Path,
    ) -> "CoxModel":

        with path.open("rb") as file:
            model = pickle.load(file)

        # Check that the loaded object is the expected model type.
        if not isinstance(model, cls):
            raise TypeError(
                "Loaded object is not a CoxModel."
            )

        return model