from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd
from lifelines.utils import concordance_index
from pycox.evaluation import EvalSurv

from ml.evaluation_compatibility import (
    ensure_pycox_scipy_compatibility,
)
from ml.prediction import SurvivalPrediction


# ---------------------------------------------------------------------------
# Evaluation Results
# ---------------------------------------------------------------------------

# Store evaluation metrics for a survival prediction model.
@dataclass(frozen=True)
class EvaluationResult:

    model_name: str

    concordance_index: float | None = None

    integrated_brier_score: float | None = None

    time_dependent_auc: float | None = None

    calibration_error: float | None = None

    prediction_count: int = 0

    notes: str = ""


# ---------------------------------------------------------------------------
# Concordance Index
# ---------------------------------------------------------------------------

# Calculate Harrell's concordance index from survival durations,
# event indicators and predicted risk scores.
def calculate_concordance_index(
    duration: pd.Series,
    event: pd.Series,
    risk_score: pd.Series,
) -> float:

    if not (
        len(duration)
        == len(event)
        == len(risk_score)
    ):
        raise ValueError(
            "duration, event, and risk_score must have the same length."
        )

    if duration.isna().any():
        raise ValueError("duration contains missing values.")

    if event.isna().any():
        raise ValueError("event contains missing values.")

    if risk_score.isna().any():
        raise ValueError("risk_score contains missing values.")

    if (duration < 0).any():
        raise ValueError(
            "duration must not contain negative values."
        )

    # Negate the risk scores before passing them to lifelines.
    return float(
        concordance_index(
            event_times=duration.astype(float),
            predicted_scores=-risk_score.astype(float),
            event_observed=event.astype(bool),
        )
    )


# ---------------------------------------------------------------------------
# Integrated Brier Score
# ---------------------------------------------------------------------------

# Calculate the censoring-adjusted Integrated Brier Score.
def calculate_integrated_brier_score(
    prediction: SurvivalPrediction,
    duration: pd.Series,
    event: pd.Series,
    evaluation_times: list[float] | np.ndarray,
) -> float:

    if prediction.patient_count() != len(duration):
        raise ValueError(
            "Prediction count does not match the number of patients."
        )

    if len(duration) != len(event):
        raise ValueError(
            "duration and event must have the same length."
        )

    if duration.isna().any() or event.isna().any():
        raise ValueError(
            "duration and event must not contain missing values."
        )

    # Convert the supplied evaluation times into a NumPy array.
    times = np.asarray(
        evaluation_times,
        dtype=float,
    )

    if times.ndim != 1 or len(times) < 2:
        raise ValueError(
            "evaluation_times must contain at least two time points."
        )

    if not np.all(np.diff(times) > 0):
        raise ValueError(
            "evaluation_times must be strictly increasing."
        )

    if np.any(times < 0):
        raise ValueError(
            "evaluation_times must not contain negative values."
        )

    # Copy and order the survival curve time points.
    curve = prediction.survival_curve.copy()

    curve.columns = [
        float(column)
        for column in curve.columns
    ]

    curve = curve.reindex(
        sorted(curve.columns),
        axis=1,
    )

    # Check that every requested evaluation time exists in the curve.
    missing_times = [
        time
        for time in times
        if time not in curve.columns
    ]

    if missing_times:
        raise ValueError(
            "prediction.survival_curve does not contain every "
            f"evaluation time: {missing_times}"
        )

    # PyCox expects rows to represent time and columns to represent patients.
    pycox_survival = (
        curve.loc[:, times]
        .transpose()
    )

    pycox_survival.index = times

    # Apply the compatibility setup before creating the PyCox evaluator.
    ensure_pycox_scipy_compatibility()

    # Create the survival evaluator using Kaplan-Meier censoring estimates.
    evaluator = EvalSurv(
        pycox_survival,
        duration.astype(float).to_numpy(),
        event.astype(int).to_numpy(),
        censor_surv="km",
    )

    # Calculate the Integrated Brier Score across the evaluation times.
    score = evaluator.integrated_brier_score(
        times
    )

    return float(score)


# ---------------------------------------------------------------------------
# Survival Model Evaluator
# ---------------------------------------------------------------------------

# Evaluate survival predictions and return the calculated metrics.
class SurvivalModelEvaluator:

    def evaluate(
            self,
            prediction: SurvivalPrediction,
            duration: pd.Series,
            event: pd.Series,
            evaluation_times: list[float] | np.ndarray | None = None,
        ) -> EvaluationResult:

        if len(duration) != len(event):
            raise ValueError(
                "duration and event must have the same length."
            )

        if prediction.patient_count() != len(duration):
            raise ValueError(
                "Prediction count does not match the number of patients."
            )

        # Calculate the concordance index.
        c_index = calculate_concordance_index(
            duration=duration,
            event=event,
            risk_score=prediction.risk_score,
        )

        integrated_brier_score = None

        # Calculate the Integrated Brier Score when evaluation times are supplied.
        if evaluation_times is not None:
            integrated_brier_score = (
                calculate_integrated_brier_score(
                    prediction=prediction,
                    duration=duration,
                    event=event,
                    evaluation_times=evaluation_times,
                )
            )

        # Return the available evaluation metrics.
        return EvaluationResult(
            model_name=prediction.model_name,
            concordance_index=c_index,
            integrated_brier_score=integrated_brier_score,
            prediction_count=prediction.patient_count(),
        )