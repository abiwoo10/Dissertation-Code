from __future__ import annotations

import torch
from torch import nn


# ---------------------------------------------------------------------------
# MTLR Output Layer
# ---------------------------------------------------------------------------

# Linear MTLR output layer for the survival-time intervals.
class MTLRLayer(nn.Module):

    # Initialise the MTLR layer using the input feature and interval counts.
    def __init__(
            self,
            input_features: int,
            interval_count: int,
    ) -> None:
        super().__init__()

        if input_features < 1:
            raise ValueError(
                "input_features must be at least 1."
            )

        if interval_count < 2:
            raise ValueError(
                "interval_count must be at least 2."
            )

        self.input_features = input_features
        self.interval_count = interval_count

        # Create the linear layer used to generate the interval logits.
        self.linear = nn.Linear(
            input_features,
            interval_count - 1,
        )

    # Generate unnormalised logits for each survival interval.
    def forward(
        self,
        features: torch.Tensor,
    ) -> torch.Tensor:

        if features.ndim != 2:
            raise ValueError(
                "features must be a two-dimensional tensor."
            )

        if features.shape[1] != self.input_features:
            raise ValueError(
                "features has an unexpected number of columns."
            )

        # Generate the base logits from the input features.
        base_logits = self.linear(features)

        # Append the fixed reference logit for the final interval.
        reference_logit = torch.zeros(
            (features.shape[0], 1),
            dtype=features.dtype,
            device=features.device,
        )

        base_logits = torch.cat(
            [base_logits, reference_logit],
            dim=1,
        )

        # Reverse cumulative sums impose the ordered MTLR structure.
        interval_logits = torch.flip(
            torch.cumsum(
                torch.flip(base_logits, dims=[1]),
                dim=1,
            ),
            dims=[1],
        )

        return interval_logits

    # Calculate the normalised probability for each survival interval.
    def predict_interval_probabilities(
        self,
        features: torch.Tensor,
    ) -> torch.Tensor:

        logits = self.forward(features)

        return torch.softmax(
            logits,
            dim=1,
        )