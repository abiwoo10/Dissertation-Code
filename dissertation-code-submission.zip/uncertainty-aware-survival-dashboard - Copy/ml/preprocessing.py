from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import joblib
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

from ml.data_loading import (
    DEFAULT_ARCHIVE,
    prepare_raw_model_data,
)
from ml.feature_config import (
    CLINICAL_CATEGORICAL_FEATURES,
    CLINICAL_NUMERIC_FEATURES,
    EXTENDED_CATEGORICAL_FEATURES,
    EXTENDED_NUMERIC_FEATURES,
)


# ---------------------------------------------------------------------------
# Data Container
# ---------------------------------------------------------------------------

# Store the raw train, validation and test partitions.
@dataclass(frozen=True)
class DatasetSplit:

    X_train: pd.DataFrame
    X_validation: pd.DataFrame
    X_test: pd.DataFrame

    duration_train: pd.Series
    duration_validation: pd.Series
    duration_test: pd.Series

    event_train: pd.Series
    event_validation: pd.Series
    event_test: pd.Series


# Store the transformed dataset partitions and fitted transformer.
@dataclass(frozen=True)
class TransformedDatasetSplit:

    X_train: pd.DataFrame
    X_validation: pd.DataFrame
    X_test: pd.DataFrame

    duration_train: pd.Series
    duration_validation: pd.Series
    duration_test: pd.Series

    event_train: pd.Series
    event_validation: pd.Series
    event_test: pd.Series

    transformer: ColumnTransformer


# ---------------------------------------------------------------------------
# Dataset Splitting
# ---------------------------------------------------------------------------

# Split the model data into train, validation and test partitions.
def split_model_data(
    X: pd.DataFrame,
    duration: pd.Series,
    event: pd.Series,
    test_size: float = 0.20,
    validation_size: float = 0.20,
    random_state: int = 42,
) -> DatasetSplit:

    if not (len(X) == len(duration) == len(event)):
        raise ValueError(
            "X, duration, and event must contain the same number of rows."
        )

    if not 0 < test_size < 1:
        raise ValueError("test_size must be between 0 and 1.")

    if not 0 < validation_size < 1:
        raise ValueError("validation_size must be between 0 and 1.")

    if test_size + validation_size >= 1:
        raise ValueError(
            "test_size and validation_size must sum to less than 1."
        )

    # Split the full dataset into test and remaining partitions.
    (
        X_train_validation,
        X_test,
        duration_train_validation,
        duration_test,
        event_train_validation,
        event_test,
    ) = train_test_split(
        X,
        duration,
        event,
        test_size=test_size,
        random_state=random_state,
        stratify=event,
    )

    # Calculate the validation proportion from the remaining data.
    validation_fraction_of_remaining = (
        validation_size / (1 - test_size)
    )

    # Split the remaining data into train and validation partitions.
    (
        X_train,
        X_validation,
        duration_train,
        duration_validation,
        event_train,
        event_validation,
    ) = train_test_split(
        X_train_validation,
        duration_train_validation,
        event_train_validation,
        test_size=validation_fraction_of_remaining,
        random_state=random_state,
        stratify=event_train_validation,
    )

    # Return each partition with reset indices.
    return DatasetSplit(
        X_train=X_train.reset_index(drop=True),
        X_validation=X_validation.reset_index(drop=True),
        X_test=X_test.reset_index(drop=True),
        duration_train=duration_train.reset_index(drop=True),
        duration_validation=duration_validation.reset_index(drop=True),
        duration_test=duration_test.reset_index(drop=True),
        event_train=event_train.reset_index(drop=True),
        event_validation=event_validation.reset_index(drop=True),
        event_test=event_test.reset_index(drop=True),
    )


# ---------------------------------------------------------------------------
# Feature Transformer
# ---------------------------------------------------------------------------

# Build the preprocessing transformer for the selected feature set.
def build_feature_transformer(
    model_type: str = "clinical",
) -> ColumnTransformer:

    # Select the numerical and categorical features for the model type.
    if model_type == "clinical":
        numeric_features = CLINICAL_NUMERIC_FEATURES
        categorical_features = CLINICAL_CATEGORICAL_FEATURES
    elif model_type == "extended":
        numeric_features = EXTENDED_NUMERIC_FEATURES
        categorical_features = EXTENDED_CATEGORICAL_FEATURES
    else:
        raise ValueError(
            "model_type must be either 'clinical' or 'extended'."
        )

    # Create the numerical preprocessing pipeline.
    numeric_pipeline = Pipeline(
        steps=[
            (
                "imputer",
                SimpleImputer(strategy="median"),
            ),
            (
                "scaler",
                StandardScaler(),
            ),
        ]
    )

    # Create the categorical preprocessing pipeline.
    categorical_pipeline = Pipeline(
        steps=[
            (
                "imputer",
                SimpleImputer(strategy="most_frequent"),
            ),
            (
                "encoder",
                OneHotEncoder(
                    handle_unknown="ignore",
                    drop="first",
                    sparse_output=False,
                ),
            ),
        ]
    )

    # Combine the numerical and categorical preprocessing pipelines.
    return ColumnTransformer(
        transformers=[
            (
                "numeric",
                numeric_pipeline,
                numeric_features,
            ),
            (
                "categorical",
                categorical_pipeline,
                categorical_features,
            ),
        ],
        remainder="drop",
        verbose_feature_names_out=False,
    )


# ---------------------------------------------------------------------------
# Dataset Transformation
# ---------------------------------------------------------------------------

# Fit the preprocessing transformer and transform each dataset partition.
def transform_dataset_split(
    dataset_split: DatasetSplit,
    model_type: str = "clinical",
) -> TransformedDatasetSplit:

    transformer = build_feature_transformer(model_type)

    # Fit the transformer using the training features.
    transformed_train = transformer.fit_transform(
        dataset_split.X_train
    )

    # Transform the validation and test features.
    transformed_validation = transformer.transform(
        dataset_split.X_validation
    )

    transformed_test = transformer.transform(
        dataset_split.X_test
    )

    # Get the feature names produced by the fitted transformer.
    feature_names = transformer.get_feature_names_out()

    # Convert the transformed arrays back into DataFrames.
    X_train = pd.DataFrame(
        transformed_train,
        columns=feature_names,
        index=dataset_split.X_train.index,
    )

    X_validation = pd.DataFrame(
        transformed_validation,
        columns=feature_names,
        index=dataset_split.X_validation.index,
    )

    X_test = pd.DataFrame(
        transformed_test,
        columns=feature_names,
        index=dataset_split.X_test.index,
    )

    return TransformedDatasetSplit(
        X_train=X_train,
        X_validation=X_validation,
        X_test=X_test,
        duration_train=dataset_split.duration_train.copy(),
        duration_validation=dataset_split.duration_validation.copy(),
        duration_test=dataset_split.duration_test.copy(),
        event_train=dataset_split.event_train.copy(),
        event_validation=dataset_split.event_validation.copy(),
        event_test=dataset_split.event_test.copy(),
        transformer=transformer,
    )


# ---------------------------------------------------------------------------
# Dataset Preparation
# ---------------------------------------------------------------------------

# Prepare the METABRIC dataset for model training and evaluation.
def prepare_model_dataset(
    archive_path: Path = DEFAULT_ARCHIVE,
    model_type: str = "clinical",
    test_size: float = 0.20,
    validation_size: float = 0.20,
    random_state: int = 42,
) -> TransformedDatasetSplit:

    # Load the raw features and survival targets.
    X, duration, event = prepare_raw_model_data(
        archive_path=archive_path,
        model_type=model_type,
    )

    # Split the raw data into train, validation and test partitions.
    raw_split = split_model_data(
        X=X,
        duration=duration,
        event=event,
        test_size=test_size,
        validation_size=validation_size,
        random_state=random_state,
    )

    # Transform each dataset partition.
    return transform_dataset_split(
        dataset_split=raw_split,
        model_type=model_type,
    )


# ---------------------------------------------------------------------------
# Feature Transformer Storage
# ---------------------------------------------------------------------------

# Save a fitted feature transformer.
def save_feature_transformer(
    transformer: ColumnTransformer,
    path: Path,
) -> None:

    if not hasattr(
        transformer,
        "transformers_",
    ):
        raise ValueError(
            "Cannot save an unfitted feature transformer."
        )

    # Create the destination directory if required.
    path.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    joblib.dump(
        transformer,
        path,
    )


# Load a previously fitted feature transformer.
def load_feature_transformer(
    path: Path,
) -> ColumnTransformer:

    if not path.exists():
        raise FileNotFoundError(
            f"Feature transformer not found: {path}"
        )

    transformer = joblib.load(
        path
    )

    # Check that the loaded object is a ColumnTransformer.
    if not isinstance(
        transformer,
        ColumnTransformer,
    ):
        raise TypeError(
            "Loaded object is not a ColumnTransformer."
        )

    # Check that the loaded transformer has been fitted.
    if not hasattr(
        transformer,
        "transformers_",
    ):
        raise ValueError(
            "Loaded feature transformer is not fitted."
        )

    return transformer


# ---------------------------------------------------------------------------
# Raw Feature Transformation
# ---------------------------------------------------------------------------

# Transform raw patient features using a fitted feature transformer.
def transform_raw_features(
    X: pd.DataFrame,
    transformer: ColumnTransformer,
) -> pd.DataFrame:

    if X.empty:
        raise ValueError(
            "Raw feature data must not be empty."
        )

    if not hasattr(
            transformer,
            "transformers_",
    ):
        raise ValueError(
            "Feature transformer must be fitted before transformation."
        )

    # Transform the raw feature values.
    transformed = transformer.transform(
        X
    )

    # Get the transformed feature names.
    feature_names = (
        transformer.get_feature_names_out()
    )

    # Return the transformed features as a DataFrame.
    return pd.DataFrame(
        transformed,
        columns=feature_names,
        index=X.index,
    )