from __future__ import annotations

from dataclasses import dataclass, field

import pandas as pd


# ---------------------------------------------------------------------------
# Survival Prediction
# ---------------------------------------------------------------------------

# Store the complete survival prediction for one or more patients.
@dataclass(frozen=True)
class SurvivalPrediction:

    # ------------------------------------------------------------------
    # Survival probabilities
    # ------------------------------------------------------------------

    one_year_survival: pd.Series

    three_year_survival: pd.Series

    five_year_survival: pd.Series

    # ------------------------------------------------------------------
    # Full survival curve
    # ------------------------------------------------------------------

    survival_curve: pd.DataFrame

    # ------------------------------------------------------------------
    # Relative risk score
    # ------------------------------------------------------------------

    risk_score: pd.Series

    # ------------------------------------------------------------------
    # Optional uncertainty estimates
    # ------------------------------------------------------------------

    uncertainty: pd.Series | None = None

    # ------------------------------------------------------------------
    # Optional confidence intervals
    # ------------------------------------------------------------------

    lower_confidence: pd.DataFrame | None = None

    upper_confidence: pd.DataFrame | None = None

    # ------------------------------------------------------------------
    # Metadata
    # ------------------------------------------------------------------

    model_name: str = ""

    prediction_times: list[float] = field(default_factory=list)

    # Return the number of patients included in the prediction.
    def patient_count(self) -> int:

        return len(self.risk_score)

    # Check whether uncertainty estimates are available.
    def has_uncertainty(self) -> bool:

        return self.uncertainty is not None

    # Check whether confidence intervals are available.
    def has_confidence_intervals(self) -> bool:

        return (
            self.lower_confidence is not None
            and self.upper_confidence is not None
        )