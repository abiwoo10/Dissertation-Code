from __future__ import annotations

import io
import tarfile
from pathlib import Path

import pandas as pd

from ml.feature_config import (
    CLINICAL_FEATURES,
    DURATION_COLUMN,
    EVENT_COLUMN,
    EXTENDED_FEATURES,
)


# ---------------------------------------------------------------------------
# Project paths and source filenames
# ---------------------------------------------------------------------------

PROJECT_ROOT = Path(__file__).resolve().parents[1]

# Default location of the raw METABRIC archive.
DEFAULT_ARCHIVE = (
    PROJECT_ROOT
    / "data"
    / "raw"
    / "brca_metabric.tar.gz"
)

PATIENT_TABLE_FILENAME = "data_clinical_patient.txt"
SAMPLE_TABLE_FILENAME = "data_clinical_sample.txt"


# ---------------------------------------------------------------------------
# Archive-reading helpers
# ---------------------------------------------------------------------------

# Find a single file within the archive using its filename.
def find_archive_member(
    archive: tarfile.TarFile,
    expected_filename: str,
) -> tarfile.TarInfo:

    matches = [
        member
        for member in archive.getmembers()
        if member.isfile()
        and Path(member.name).name.lower() == expected_filename.lower()
    ]

    if not matches:
        raise FileNotFoundError(
            f"Could not find {expected_filename!r} inside the archive."
        )

    if len(matches) > 1:
        locations = [member.name for member in matches]

        raise ValueError(
            f"Multiple files named {expected_filename!r} were found: "
            f"{locations}"
        )

    return matches[0]


# Read a tab-separated cBioPortal table from the METABRIC archive.
def read_cbioportal_table(
    archive: tarfile.TarFile,
    filename: str,
) -> pd.DataFrame:

    member = find_archive_member(archive, filename)
    extracted_file = archive.extractfile(member)

    if extracted_file is None:
        raise OSError(f"Unable to read {member.name!r} from the archive.")

    # Decode the extracted table before loading it into a DataFrame.
    text = extracted_file.read().decode("utf-8-sig")

    return pd.read_csv(
        io.StringIO(text),
        sep="\t",
        comment="#",
        low_memory=False,
    )


# ---------------------------------------------------------------------------
# Public loading function
# ---------------------------------------------------------------------------

# Load the patient-level and sample-level METABRIC clinical tables.
def load_metabric_clinical_tables(
    archive_path: Path = DEFAULT_ARCHIVE,
) -> tuple[pd.DataFrame, pd.DataFrame]:

    archive_path = archive_path.resolve()

    if not archive_path.exists():
        raise FileNotFoundError(
            f"METABRIC archive not found: {archive_path}"
        )

    if not archive_path.is_file():
        raise ValueError(
            f"METABRIC archive path is not a file: {archive_path}"
        )

    # Extract the required patient and sample tables from the archive.
    with tarfile.open(archive_path, mode="r:*") as archive:
        patient_df = read_cbioportal_table(
            archive,
            PATIENT_TABLE_FILENAME,
        )

        sample_df = read_cbioportal_table(
            archive,
            SAMPLE_TABLE_FILENAME,
        )

    return patient_df, sample_df


# Merge the patient-level and sample-level tables using PATIENT_ID.
def merge_clinical_tables(
    patient_df: pd.DataFrame,
    sample_df: pd.DataFrame,
) -> pd.DataFrame:

    merge_column = "PATIENT_ID"

    # Check that the patient identifier exists in both tables.
    if merge_column not in patient_df.columns:
        raise KeyError(
            f"Patient table is missing required column: {merge_column}"
        )

    if merge_column not in sample_df.columns:
        raise KeyError(
            f"Sample table is missing required column: {merge_column}"
        )

    # Check for missing patient identifiers.
    if patient_df[merge_column].isna().any():
        raise ValueError("Patient table contains missing PATIENT_ID values.")

    if sample_df[merge_column].isna().any():
        raise ValueError("Sample table contains missing PATIENT_ID values.")

    duplicate_patient_ids = patient_df[merge_column].duplicated()
    duplicate_sample_patient_ids = sample_df[merge_column].duplicated()

    # Check for duplicate patient identifiers in the patient table.
    if duplicate_patient_ids.any():
        duplicates = (
            patient_df.loc[duplicate_patient_ids, merge_column]
            .astype(str)
            .unique()
            .tolist()
        )

        raise ValueError(
            f"Patient table contains duplicate PATIENT_ID values: {duplicates}"
        )

    # Check for duplicate patient identifiers in the sample table.
    if duplicate_sample_patient_ids.any():
        duplicates = (
            sample_df.loc[duplicate_sample_patient_ids, merge_column]
            .astype(str)
            .unique()
            .tolist()
        )

        raise ValueError(
            "Sample table contains duplicate PATIENT_ID values: "
            f"{duplicates}"
        )

    patient_ids = set(patient_df[merge_column].astype(str))
    sample_patient_ids = set(sample_df[merge_column].astype(str))

    missing_from_sample = sorted(patient_ids - sample_patient_ids)
    missing_from_patient = sorted(sample_patient_ids - patient_ids)

    # Check that both tables contain the same patients before merging.
    if missing_from_sample or missing_from_patient:
        raise ValueError(
            "Patient IDs do not match between the clinical tables. "
            f"Missing from sample table: {missing_from_sample}; "
            f"missing from patient table: {missing_from_patient}."
        )

    # Perform a one-to-one merge of the clinical tables.
    merged_df = patient_df.merge(
        sample_df,
        on=merge_column,
        how="inner",
        validate="one_to_one",
        suffixes=("_PATIENT", "_SAMPLE"),
    )

    if len(merged_df) != len(patient_df):
        raise ValueError(
            "Clinical table merge changed the expected patient count: "
            f"{len(patient_df)} patient rows became {len(merged_df)} "
            "merged rows."
        )

    return merged_df


# Create numeric survival duration and event columns.
def create_survival_target(
    clinical_df: pd.DataFrame,
) -> pd.DataFrame:

    required_columns = [DURATION_COLUMN, EVENT_COLUMN]

    missing_columns = [
        column
        for column in required_columns
        if column not in clinical_df.columns
    ]

    if missing_columns:
        raise KeyError(
            f"Missing required survival columns: {missing_columns}"
        )

    result = clinical_df.copy()

    # Convert survival duration values to numeric values.
    result["duration"] = pd.to_numeric(
        result[DURATION_COLUMN],
        errors="coerce",
    )

    # Standardise survival status values before mapping them to binary events.
    normalised_status = (
        result[EVENT_COLUMN]
        .astype("string")
        .str.strip()
        .str.upper()
    )

    status_mapping = {
        "0:LIVING": 0,
        "LIVING": 0,
        "0": 0,
        "1:DECEASED": 1,
        "DECEASED": 1,
        "1": 1,
    }

    result["event"] = normalised_status.map(status_mapping)

    # Find any survival statuses that could not be mapped.
    unsupported_statuses = sorted(
        normalised_status[
            normalised_status.notna()
            & result["event"].isna()
        ]
        .drop_duplicates()
        .tolist()
    )

    if unsupported_statuses:
        raise ValueError(
            "Unsupported OS_STATUS values were found: "
            f"{unsupported_statuses}"
        )

    # Remove rows without usable survival duration or event values.
    result = result.dropna(
        subset=["duration", "event"]
    ).copy()

    result["event"] = result["event"].astype(int)

    if (result["duration"] < 0).any():
        raise ValueError(
            "Negative overall-survival durations were found."
        )

    return result


# Select the predictor and survival target columns for the requested model.
def select_model_data(
    clinical_df: pd.DataFrame,
    model_type: str = "clinical",
) -> tuple[pd.DataFrame, pd.Series, pd.Series]:

    # Select either the clinical or extended feature set.
    if model_type == "clinical":
        selected_features = CLINICAL_FEATURES
    elif model_type == "extended":
        selected_features = EXTENDED_FEATURES
    else:
        raise ValueError(
            "model_type must be either 'clinical' or 'extended'."
        )

    required_columns = selected_features + ["duration", "event"]

    missing_columns = [
        column
        for column in required_columns
        if column not in clinical_df.columns
    ]

    if missing_columns:
        raise KeyError(
            f"Missing required modelling columns: {missing_columns}"
        )

    # Separate the selected predictors from the survival targets.
    X = clinical_df[selected_features].copy()
    duration = clinical_df["duration"].copy()
    event = clinical_df["event"].copy()

    return X, duration, event


# Load and prepare the raw data required for model training.
def prepare_raw_model_data(
    archive_path: Path = DEFAULT_ARCHIVE,
    model_type: str = "clinical",
) -> tuple[pd.DataFrame, pd.Series, pd.Series]:

    # Load the patient and sample clinical tables.
    patient_df, sample_df = load_metabric_clinical_tables(
        archive_path
    )

    # Merge both tables into one patient-level dataset.
    merged_df = merge_clinical_tables(
        patient_df,
        sample_df,
    )

    # Create the survival duration and event target columns.
    survival_df = create_survival_target(
        merged_df
    )

    # Return the selected predictors and survival targets.
    return select_model_data(
        survival_df,
        model_type=model_type,
    )