# Breast Cancer Survival Prognosis System

## Project overview

This project is a machine learning system for generating patient-specific 
breast cancer survival prognoses. It combines survival modelling, model 
calibration, ensemble-based uncertainty estimation, a prediction API, and 
an interactive frontend for presenting survival estimates in an accessible 
form.

The repository contains the complete workflow used to preprocess the data, 
train and evaluate survival models, generate research visualisations and 
reports, serve predictions through the backend API, and display 
patient-specific prognosis results through the frontend application.

## Key features

Patient-specific survival prognosis generation

1-year, 3-year, and 5-year survival estimates

Predicted survival curves and median survival estimates

Model disagreement and uncertainty information

Cox proportional hazards and MTLR survival models

MTLR calibration using X-CAL

Deep ensemble prognosis generation

Model evaluation and comparison utilities

Data preprocessing and validation

Research visualisations and result summaries

FastAPI prediction backend

React and TypeScript frontend

Automated backend and frontend tests

## Repository structure

api/
Contains the FastAPI backend used to expose health and patient prognosis 
endpoints.

data/
Contains the datasets and generated data reports used throughout the 
project.

docs/
Contains project documentation, dataset documentation, and supporting 
reference material.

frontend/
Contains the React and TypeScript web application used to enter patient 
information and display prognosis results.

ml/
Contains the core machine learning implementation, including preprocessing, 
survival models, calibration, ensembles, evaluation, and prognosis generation.

models/
Contains trained model artefacts, ensemble members, preprocessing 
artefacts, and model metadata.

scripts/
Contains executable scripts for preprocessing, model training, tuning, 
evaluation, comparison, auditing, and prognosis generation.

tests/
Contains the automated test suite for the backend and machine learning 
components.

visualisation/
Contains scripts used to generate model evaluation, calibration, survival, 
convergence, uncertainty, and example prognosis visualisations.

## Installation

Create and activate a Python virtual environment, then install the project 
dependencies using the dependency configuration provided with the repository.

The frontend dependencies should be installed separately from within the 
frontend directory using npm.

## Running the backend

Start the FastAPI application from the project root using the API entry 
point in api/main.py.

The backend loads the trained prognosis model and exposes endpoints used 
by the frontend to check service availability and request patient-specific 
predictions.

## Running the frontend

Navigate to the frontend directory, install the required npm dependencies, 
and start the Vite development server.

The frontend communicates with the prediction API using the API base URL 
configured through the frontend environment settings.

## Training models

The scripts directory contains the commands used to train the Cox and MTLR 
model variants, including baseline, extended, calibrated, and ensemble 
configurations.

Supporting scripts are also provided for hyperparameter tuning, 
calibration, preprocessing, model comparison, and evaluation.

## Running tests

Backend and machine learning tests are located in the tests directory and 
can be run using pytest.

Frontend tests are located alongside the relevant frontend components and 
services and can be run using Vitest.

## Directory overview

Each major directory contains its own README.md file with short 
descriptions of the files contained within that part of the project.

These directory-level README files provide a quick reference for 
navigating the codebase and understanding the responsibility of 
individual modules, scripts, components, models, and supporting files.